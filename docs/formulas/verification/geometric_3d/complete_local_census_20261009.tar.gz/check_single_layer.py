"""Check that the candidate core rule commutes with the archived even reset maps.
Both inputs and the actual lower-layer output can therefore use the same rule.
The only changes to the archived core reference are explicit B-B/A-A arrow
alignment, including when an actual reset psi occupies a geometric face slot.
"""
from audit_references import F,OLD,ROOT
from itertools import product
from rotations import rotate_edges
from reset_tracks import module
import json


def run():
    checks=0
    for bits in product(range(2),repeat=4):
      for lengths in product(range(4),repeat=4):
       active=[b^(r%2) for b,r in zip(bits,lengths)]
       for k in (sum(active)%2,2+sum(active)%2):
        for t in range(2):
         gamma={f:(2*j,2*j+1) for j,f in enumerate(F)}
         n=8;tracks={}
         for f,r in zip(F,lengths):
          tracks[f]=[(n+2*j,n+2*j+1) for j in range(r)];n+=2*r
         central=list(range(n,n+k));n+=k
         outside=[gamma[f][0 if j<2 else 1] for j,f in enumerate(F) if active[j]]
         if len(outside)%2:outside.append(n);n+=1
         exterior=list(zip(outside[::2],outside[1::2]))
         reduced=[gamma[f] for j,f in enumerate(F) if not active[j]]
         reduced += [e for f in F for e in tracks[f]]+exterior
         inc=lambda f: gamma[f][int(f in F[:2])]
         seq=[inc(f) for f in OLD[:2] if active[F.index(f)]]+central+[inc(f) for f in OLD[2:] if active[F.index(f)]]
         reduced+=list(zip(seq[::2],seq[1::2]))
         current=list(reduced);actual=dict();caps=[]
         for j,(f,b,r) in enumerate(zip(F,bits,lengths)):
          mod=module(b,r,t if j==0 else 0)
          mapping={0:gamma[f][0],1:gamma[f][1]}
          mapping.update({2+2*i+c:tracks[f][i][c] for i in range(r) for c in range(2)})
          for u,v,q in mod['reduced_to_separate_gates']:
           current=rotate_edges(current,mapping[u],mapping[v],q)
          q=(-1)**(t if j==0 else 0)
          for i in range(0,r-r%2,2):
           a,bb=tracks[f][i];c,d=tracks[f][i+1]
           caps.extend([(a,c) if q==1 else (c,a),(d,bb) if q==1 else (bb,d)])
          if r%2:
           a,bb=tracks[f][-1]
           if b:
            ga,gb=gamma[f]
            caps.extend([(ga,a) if q==1 else (a,ga),(bb,gb) if q==1 else (gb,bb)])
           else:
            caps.append(gamma[f]);actual[f]=tracks[f][-1][int(j<2)]
          elif b:actual[f]=inc(f)
          else:caps.append(gamma[f])
         # Transport each exterior bond together with its active channel.
         old_to_new={gamma[f][0 if j<2 else 1]:tracks[f][-1][0 if j<2 else 1]
                     for j,f in enumerate(F) if lengths[j]%2 and not bits[j]}
         exterior=[tuple(old_to_new.get(x,x) for x in e) for e in exterior]
         seq=[actual[f] for f in OLD[:2] if f in actual]+central+[actual[f] for f in OLD[2:] if f in actual]
         expected=caps+exterior+list(zip(seq[::2],seq[1::2]))
         assert set(current)==set(expected)
         assert sorted(x for e in current for x in e)==list(range(n))
         checks+=1
    result=dict(status='Candidate single-layer reference; archived reset cancellation/transfer gates unchanged.',
                full_single_layer_states=checks,initial_and_output_rule_identical=True,
                central_psi_order_unchanged=True,geometric_slot_arrows_aligned_to_legacy_gamma=True,
                mismatches=0)
    (ROOT/'single_layer_checks.json').write_text(json.dumps(result,indent=2)+'\n')
    return result

if __name__=='__main__':print(json.dumps(run(),indent=2))

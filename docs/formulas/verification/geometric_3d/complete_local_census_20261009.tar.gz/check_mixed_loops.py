"""Private local lemma: implement a mixed transition loop using a psi pivot.
Pure-gamma loops are deliberately left untouched for the legacy projection
schedule. This does not certify patch scheduling or the legacy schedule itself.
"""
from audit_references import *
from rotations import rotate_edges


def compile_mixed(row,initial,final):
    modes=row['modes'];n=len(modes)
    count=loops(initial,final,n)
    current=list(initial)+[(n,n+1)]
    desired=list(final)
    old_allowed={e for e in initial if all(modes[i]['kind']=='ordinary' for i in e)}
    new_allowed={e for e in final if all(modes[i]['kind']=='ordinary' for i in e)}
    gamma_allowed=old_allowed|new_allowed
    psi={m['id'] for m in modes if m['kind']!='ordinary'}
    point_parity=0;gates=[];mixed=0
    def gate(p,q,sign):
        nonlocal current
        assert p in psi or q in psi
        current=rotate_edges(current,p,q,sign)
        assert all(e in gamma_allowed for e in current
                   if all(i<n and modes[i]['kind']=='ordinary' for i in e))
        gates.append((p,q,sign))
    for loop in count['loops']:
        vertices={e['from'] for e in loop['edges']}
        choices=vertices&psi
        if not choices:continue
        mixed+=1;pivot=min(choices)
        target={i:j for a,b in final if a in vertices for i,j in ((a,b),(b,a))}
        target_edges={e for e in final if e[0] in vertices}
        remaining=set(vertices)
        while len(remaining)>2:
            partner=next(b if a==pivot else a for a,b in current if pivot in (a,b))
            other=target[partner]
            assert other!=pivot
            chosen=None
            wanted=next(e for e in target_edges if frozenset(e)==frozenset((partner,other)))
            for sign in (1,-1):
                trial=rotate_edges(current,pivot,other,sign)
                if wanted in trial:chosen=sign;break
            assert chosen is not None
            gate(pivot,other,chosen)
            remaining.difference_update((partner,other))
        last=next(e for e in target_edges if pivot in e)
        if last not in current:
            gate(pivot,n,1);gate(pivot,n,1)
            point_parity^=1
        assert target_edges.issubset(set(current))
    for loop in count['loops']:
        vertices={e['from'] for e in loop['edges']}
        if not vertices&psi:
            assert {e for e in initial if e[0] in vertices}.issubset(set(current))
    assert ((n+1,n) if point_parity else (n,n+1)) in current
    expected=sum(l['parity_change'] for l in count['loops']
                 if any(e['from'] in psi for e in l['edges']))%2
    assert point_parity==expected
    return mixed,len(gates)

if __name__=='__main__':
    graphs=components=gates=0
    for bg in ('zero','w','s','both'):
        for seed in range(256):
            raw,_,_=prepare(generate(4,bg,110000+seed))
            row,start,end=corrected_P(raw)
            x,y=compile_mixed(row,start,end)
            graphs+=1;components+=x;gates+=y
    result=dict(status='Local mixed-loop lemma only; full legacy path and patch schedule remain separate obligations.',
                graphs=graphs,mixed_components=components,psi_involving_gates=gates,
                pure_gamma_components_untouched=True,
                intermediate_gamma_dimers_are_only_existing_or_target_dimers=True,
                mismatches=0)
    (ROOT/'mixed_loop_checks.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

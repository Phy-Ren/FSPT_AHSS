"""Private audit of archived versus legacy single-layer dimer conventions.
No manuscript edits and no archived source edits. Endpoint checks do not certify
that a proposed circuit preserves the legacy intermediate projection schedule.
"""
from pathlib import Path
from itertools import product, combinations
import sys, json
ROOT = Path(__file__).parent
SRC = ROOT/'manuscript/verification/pip_stacking/source'
sys.path.insert(0, str(SRC))
from unfold3 import build
from data3 import generate, prepare, output, restrict
from kasteleyn import loops, word_parity
from reference3 import target
from gauge import dA2
from cup import op, dc
from prior_obstruction.model import Input, build as build_F

F=((1,2,3),(0,1,3),(0,2,3),(0,1,2))
OLD=(F[1],F[0],F[3],F[2])


def core(active,k,legacy=False):
    seq=[('gamma',f) for f in ((F[1],F[0]) if legacy else F[:2]) if active[f]]
    seq += [('psi',i) for i in range(k)]
    seq += [('gamma',f) for f in ((F[3],F[2]) if legacy else F[2:]) if active[f]]
    assert len(seq)%2 == 0
    return list(zip(seq[::2],seq[1::2]))


def B3(m,cell=(0,1,2,3)):
    i,j,k,l=cell
    return (m[i,j,l]*m[j,k,l]+m[i,j,k]*m[i,k,l])%2


def corrected_P(raw):
    row=build(*raw)
    modes=row['modes']
    def flip_edges(edges,edge_set):
        return [tuple(e)[::-1] if frozenset(e) in edge_set else tuple(e) for e in edges]
    flips=set()
    for c in row['input_cores']:
        for a,b in c['dimers']:
            if (modes[a]['kind']==modes[b]['kind']=='ordinary'
                and modes[a]['side']==modes[b]['side']):
                flips.add(frozenset((a,b)))
    initial=flip_edges(row['dimers']['in'],flips)
    # Exchange survivors transfer to ordinary output carriers. The output sign
    # is fixed by those carriers, not by whether the survivor was an old gamma.
    survivors={x['survivor'][0]:modes[x['survivor'][0]]['side']
               for x in row['face_steps'] if x['survivor']}
    flips={frozenset((a,b)) for a,b in row['output_core']
           if a in survivors and b in survivors and survivors[a]==survivors[b]}
    final=flip_edges(row['dimers']['out'],flips)
    return row,initial,final


def corrected_F(data):
    row=build_F(Input(1,data['n1'],data['n2'],data['omega2'],data['s1']))
    changed={}
    for side in ('in','out'):
        flips=set()
        for d in row['arrow_log'][side]:
            a,b=d['actual_dimer']
            ma,mb=row['modes'][a],row['modes'][b]
            if ma['kind']==mb['kind']=='ordinary' and ma['port_type']==mb['port_type']:
                flips.add(frozenset((a,b)))
        changed[side]=[tuple(e)[::-1] if frozenset(e) in flips else tuple(e)
                       for e in row['dimers'][side]]
    return row, changed


def run():
    stats=dict(single_layer_closed_states=0, single_layer_arrow_disagreements=0,
               reduced_core_checks=0, retained_central_psi_dimers=0,
               pure_gamma_P_pairs=0, pure_gamma_P_raw_disagreements=0,
               candidate_P_graphs=0,candidate_F_graphs=0,candidate_FP_checks=0)
    for vals in product(range(2),repeat=4):
        active=dict(zip(F,vals))
        for k in range(9):
            if (sum(vals)+k)%2: continue
            a=core(active,k);b=core(active,k,True)
            assert {frozenset(e) for e in a}=={frozenset(e) for e in b}
            pa=[e for e in a if any(m[0]=='psi' for m in e)]
            pb=[e for e in b if any(m[0]=='psi' for m in e)]
            assert pa==pb
            flipped=sum(e not in b for e in a)
            assert flipped%2==B3(active)
            stats['reduced_core_checks']+=1
            stats['retained_central_psi_dimers']+=len(pa)
            if k==0:
                stats['single_layer_closed_states']+=1
                stats['single_layer_arrow_disagreements']+=int(a!=b)
    edges={e:0 for e in combinations(range(4),2)}
    zfaces={f:0 for f in F}
    closed=[dict(zip(F,v)) for v in product(range(2),repeat=4) if sum(v)%2==0]
    counterexample=None
    for u,v,tbits in product(closed,closed,product(range(2),repeat=3)):
        tvals=(0,)+tbits
        s={e:tvals[e[0]]^tvals[e[1]] for e in edges}
        raw=(edges,edges,u,v,zfaces,s)
        row,initial,final=corrected_P(raw)
        math=(edges,edges,edges,edges,u,v,zfaces,s)
        result=loops(initial,final,len(row['modes']))['parity_change']
        expected=target(*math)
        assert result==expected
        old=row['count']['parity_change']
        stats['pure_gamma_P_pairs']+=1
        stats['pure_gamma_P_raw_disagreements']+=int(old!=expected)
        if old!=expected and counterexample is None:
            counterexample=dict(upper={''.join(map(str,f)):q for f,q in u.items()},
                                lower={''.join(map(str,f)):q for f,q in v.items()},
                                antiunitary_vertex_bits=list(tvals),archived_raw=old,
                                candidate_raw=result,canonical=expected)
    def p_count(data):
        raw,math,_=prepare(data)
        row,initial,final=corrected_P(raw)
        parity=loops(initial,final,len(row['modes']))['parity_change']
        assert parity==word_parity(initial)^word_parity(final)
        a,h,b,hp,m,v,w,s=math
        M={f:(m[f]+v[f]+a[f[:2]]*b[f[1:]])%2 for f in m}
        shift=B3(m)^B3(v)^B3(M)
        assert parity==target(*math)^dA2(a,h,b,hp,m,v,s)^shift
        stats['candidate_P_graphs']+=1
        return parity
    def f_count(data):
        row,changed=corrected_F(data)
        old=loops(row['dimers']['in'],row['dimers']['out'],row['mode_count'])['parity_change']
        new=loops(changed['in'],changed['out'],row['mode_count'])['parity_change']
        m={tuple(map(int,f)):q for f,q in row['frames']['shifted_majorana'].items()}
        assert old^new==sum(B3(m,cell) for cell in combinations(range(5),4))%2
        stats['candidate_F_graphs']+=1
        return new
    for bg in ('zero','w','s','both'):
        for seed in range(64):
            p_count(generate(4,bg,91000+seed))
        for seed in range(32):
            data=generate(5,bg,93000+seed)
            dE=0
            for cell in combinations(range(5),4):
                dE ^= p_count({k:restrict(v,cell) for k,v in data.items()})
            n,m=output(data)
            out=dict(n1=n,n2=m,omega2=data['omega2'],s1=data['s1'])
            lower=dict(n1=data['n1prime'],n2=data['n2prime'],omega2=data['omega2'],s1=data['s1'])
            assert dE==f_count(data)^f_count(lower)^f_count(out)
            stats['candidate_FP_checks']+=1
    return dict(status='Private endpoint audit; no revised physical schedule certified.',
                **stats,counterexample=counterexample,
                preserved='Reduced-core central-psi partners and arrows; mode identities; unordered core pairings.',
                limitations=['Archive pure-gamma arrows conflict with legacy arrows.',
                             'Reduced-coordinate reorientation is a candidate, not an adopted convention.',
                             'Unreduced reset-psi compatibility is checked separately; all legacy intermediate steps remain to be established.'])

if __name__=='__main__':
    result=run()
    (ROOT/'reference_audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

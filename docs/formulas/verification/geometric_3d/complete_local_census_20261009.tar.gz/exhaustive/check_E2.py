"""Count the actual induced-channel inventory including signed reset references."""
from itertools import product
from pathlib import Path
import json
n=0
for upper01,upper12,lower12,s,u,v in product(range(4),range(4),range(4),range(2),range(2),range(2)):
    # Common-frame literal sheet lengths; face-native 12 values retain chirality.
    native_u=(-1)**s*upper12;native_v=(-1)**s*lower12
    new_channels=upper01*lower12
    separate=s*(abs(native_u//2)+abs(native_v//2))
    joint=s*abs((native_u+native_v)//2)
    actual=(u+v+new_channels+separate+joint)%2
    expected=(u+v+(upper01%2)*(native_v%2)+s*(native_u%2)*(native_v%2))%2
    assert actual==expected
    n+=1
out=dict(all_local_mod_four_inputs=n,mismatches=0,
         omega2='The common projective sign cancels between the two seam matrices; no independent omega term in E2.')
Path(__file__).with_name('E2_full.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))

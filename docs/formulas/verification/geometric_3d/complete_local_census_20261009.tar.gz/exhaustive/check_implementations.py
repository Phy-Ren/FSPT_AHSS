"""Check all literal arrows against the Python geometric builders, not only parity."""
from pathlib import Path
from itertools import combinations
import sys,json,subprocess
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from audit_references import *
from check_compact import compact


def decode(mask,nv,two):
    pos=0
    def bit():
        nonlocal pos
        x=mask>>pos&1;pos+=1;return x
    t=[0]+[bit() for _ in range(nv-1)]
    s={f:t[f[0]]^t[f[1]] for f in combinations(range(nv),2)}
    w={(0,i,j):bit() for i,j in combinations(range(1,nv),2)}
    for i,j,k in combinations(range(1,nv),3):w[i,j,k]=w[0,i,j]^w[0,i,k]^w[0,j,k]
    W={f:w[f]^(s[f[:2]]*s[f[1:]]) for f in w}
    layers=[]
    for _ in range(2 if two else 1):
        a=[0]+[bit() for _ in range(nv-1)]
        r=[0]+[a[i]+2*bit() for i in range(1,nv)]
        x=[0]
        for i in range(1,nv):x.append(x[-1]+(r[i]-r[i-1])%4)
        folded={f:x[f[1]]-x[f[0]] for f in s}
        native={f:(-1)**t[f[0]]*v for f,v in folded.items()}
        m={(0,i,j):bit() for i,j in combinations(range(1,nv),2)}
        for i,j,k in combinations(range(1,nv),3):m[i,j,k]=m[0,i,j]^m[0,i,k]^m[0,j,k]^(W[0,i,j]*(folded[j,k]%2))
        original={f:v^(s[f[:2]]*((native[f[1:]]//2)%2)) for f,v in m.items()}
        layers.append((native,original))
    assert pos==24
    data=dict(n1=layers[0][0],n2=layers[0][1],omega2=w,s1=s)
    if two:data.update(n1prime=layers[1][0],n2prime=layers[1][1])
    return data


def run():
    masks=[0,(1<<24)-1]+[(i*0x9e3779+0x42)&((1<<24)-1) for i in range(4096)]
    checks={};negative_controls=0
    for move,nv in [('P',4),('F',5)]:
        result=subprocess.run([str(ROOT/'exhaustive/scan'),move,'unused','--dump'],input='\n'.join(map(str,masks))+'\n',text=True,capture_output=True,check=True)
        count=0
        for line in result.stdout.splitlines():
            row=json.loads(line);data=decode(row['mask'],nv,move=='P')
            if move=='P':
                raw,math,_=prepare(data)
                py,initial,final=corrected_P(raw)
                signs={m['id']:data['s1'][0,m['face'][0]]*((m['column']-1+(m['side']=='B'))%2)
                       for m in py['modes'] if m['kind']=='cross_exchange' and m['face'][0]!=0}
                def rephase(edges):
                    return [(b,a) if signs.get(a,0)^signs.get(b,0) else (a,b) for a,b in edges]
                expected=[rephase(initial),rephase(final)]
                assert row['parity']==compact(*math)
            else:
                py,edges=corrected_F(data);expected=[edges['in'],edges['out']]
            assert row['mode_count']==py['mode_count']
            for actual,wanted in zip(row['dimers'],expected):
                assert set(map(tuple,actual))==set(map(tuple,wanted)),(move,row['mask'])
            if row['mode_count'] and count<128:
                wrong=list(expected[1]);wrong[0]=wrong[0][::-1]
                assert loops(expected[0],wrong,row['mode_count'])['parity_change']!=row['parity']
                negative_controls+=1
            count+=1
        checks[move+'_literal_matching_checks']=count
    out=dict(**checks,reversed_arrow_negative_controls=negative_controls,mismatches=0)
    (ROOT/'exhaustive/implementation_checks.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))

if __name__=='__main__':run()

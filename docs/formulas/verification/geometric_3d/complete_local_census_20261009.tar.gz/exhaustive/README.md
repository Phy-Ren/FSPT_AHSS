# Complete local directed-matching census

The original six-case gamma projection scheme is an existing input, not a new
construction to be redesigned. This audit verifies the new psi pairing reference,
its compatibility with that fixed ordinary reference, and the complete lower
binary parity laws with omega2 and s1.

## Scope and completeness

P has 24 independent binary variables: 3 s1 bits, 3 omega2 bits, 6 integer
sheet coordinates modulo four (12 bits), and 6 independent shifted chain bits.
F also has 24: 4 s1 bits, 6 omega2 bits, 4 integer sheet coordinates modulo
four (8 bits), and 6 independent shifted chain bits. The lower constraints
reconstruct all other simplex values. See the variable JSON files for the
literal coordinates. All 2^24 inputs are checked for each move.

`scan.cpp` builds the actual geometric A/B matchings directly, in the original
ordinary geometric order. It does not call the archived builder and does not
use a target formula to choose modes or edges. It includes the three exchange
routes with their actual column sign, original input residual identities,
actual output survivors, nonstandard F-cell symmetry signs, reflection-pair
references, ordinary vacua, and common exterior completions.

For every graph the code checks complete unique pairing, calculates directed
transition-loop parity, and independently calculates the paired-word inversion
parity. Only then is the result compared with an external formula truth table.
The traversal mask is an affine permutation with odd multiplier modulo 2^24,
so every input occurs exactly once in a full run.

`make_oracles.py` exports the compact E3 and the existing canonical O4 plus the
explicit dB3 as Boolean polynomials. The zeta transform evaluates their complete
truth tables. Neither the graph builder nor the graph parity counter reads a
formula coefficient. `check_implementations.py` additionally compares all actual
arrows and mode IDs against the separate Python geometric implementations.

The reduction of arbitrary integer copies to this finite parity census follows
from the paired-word block inversion calculation. Its operations depend on LR,
binomial(L,2), alternating-column sums, and products of these quantities, hence
only on copy lengths modulo four. This is a parity statement in the fixed signed
reference; four physical chiral sheets are not being identified with vacuum.
Systematic +4/+12 copy tests supplement this argument.

The exact 38-variable identity checks dE3 = Delta O4 on the actual output. It is
not a claim to have simulated 2^38 distinct combined networks. The complete
local physical counts plus that exact identity cover the combined consistency
condition without that redundant simulation.

## Reproduce from the bundle root

    PYTHONDONTWRITEBYTECODE=1 python exhaustive/make_oracles.py
    g++ -O3 -march=native -std=c++17 -fopenmp -Wall -Wextra exhaustive/scan.cpp -o exhaustive/scan
    PYTHONDONTWRITEBYTECODE=1 python exhaustive/check_implementations.py
    ./exhaustive/scan P exhaustive/P_compact.anf > exhaustive/P_full.json
    ./exhaustive/scan F exhaustive/F_compact.anf > exhaustive/F_full.json
    ./exhaustive/scan P unused --periodic > exhaustive/P_periodicity.json
    ./exhaustive/scan F unused --periodic > exhaustive/F_periodicity.json
    python exhaustive/check_E2.py
    PYTHONDONTWRITEBYTECODE=1 python check_compact.py
    PYTHONDONTWRITEBYTECODE=1 python check_single_layer.py
    PYTHONDONTWRITEBYTECODE=1 python check_mixed_loops.py

The scanner uses four OpenMP threads. The unsigned value 4294967295 in
`first_mismatch` is its no-mismatch sentinel; `formula_mismatches` is zero.

## Results

- P: 16,777,216 actual graphs, including 4,096 zero-sheet cases; zero formula
  mismatches and zero loop/word-count disagreements.
- F: 16,777,216 actual graphs, including 65,536 zero-sheet cases; zero formula
  mismatches and zero loop/word-count disagreements.
- E2: all 512 local modulo-four inventory inputs; zero mismatches.
- Separate-channel single-layer/reset compatibility: 16,384 configurations;
  zero mismatches (record in the parent directory).
- Independent full matching comparisons: 4,098 P plus 4,098 F inputs, matching
  mode identities and every arrow, with 254 reversed-arrow negative controls.
- Integer-copy extensions: 49,152 P plus 32,768 F checks; zero mismatches.
- Exact 24-variable representative identity and exact 38-variable paired
  source/product identity; zero residual monomials.

The compiled enumeration is stronger than the preliminary random-sample checks.
It supersedes the preliminary audit's request to recertify the old gamma
projection cases: those cases are retained as the fixed existing module.
This does not assert a newly derived bosonic phase or a microscopic chiral-parent
Hamiltonian beyond the resolved construction supplied in the archived notes.
The candidate reference has not been made canonical or pushed to the manuscript.

"""Export independent Boolean-polynomial comparators for exhaustive graph checks."""
from pathlib import Path
import sys,json,struct
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from check_compact import compact
from audit_references import B3
from certify import free
from cup import op,dc
from reference3 import plus
from prior_obstruction.algebra import manuscript_bits

def dump(name,poly,names):
    assert all(m < 1<<24 for m in poly.terms)
    dest=ROOT/'exhaustive'
    (dest/(name+'.anf')).write_text('\n'.join(str(m) for m in sorted(poly.terms))+'\n')
    (dest/(name+'_variables.json')).write_text(json.dumps(names[:24],indent=2)+'\n')
    print(name,len(poly.terms),'monomials',len(names[:24]),'variables')
a,h,b,k,m,v,w,s,t,names=free(4)
hn={f:h[f]+t[f[0]]*a[f]for f in a}
kn={f:k[f]+t[f[0]]*b[f]for f in b}
dump('P_compact',compact(a,hn,b,kn,m,v,w,s),names)
a,h,b,k,m,v,w,s,t,names=free(5)
hn={f:h[f]+t[f[0]]*a[f]for f in a}
native=plus(m,op(s,1,hn,1,0,5))
source=manuscript_bits(a,hn,native,w,s,1)+dc(op(m,2,m,2,1,5),3,5)[0,1,2,3,4]
dump('F_compact',source,names)

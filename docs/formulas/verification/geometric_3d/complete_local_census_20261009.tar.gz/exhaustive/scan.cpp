// Independent literal graph builder: no cochain expression places any edge.
// ANF formula data are read only by the external comparison loop.
#include <array>
#include <vector>
#include <iostream>
#include <fstream>
#include <stdexcept>
#include <cstdint>
#include <chrono>
#include <atomic>
#include <algorithm>
#include <string>
#include <omp.h>
using namespace std;
constexpr int MAX=512, NV=5;
using Face=array<int,3>;
using Cell=array<int,4>;
constexpr array<Face,4> PF={Face{1,2,3},Face{0,1,3},Face{0,2,3},Face{0,1,2}};
struct Graph {
 int n=0; int p[2][MAX]; unsigned char dir[2][MAX];
 int node(){if(n>=MAX)throw runtime_error("mode bound");p[0][n]=p[1][n]=-1;return n++;}
 void edge(int state,int u,int v,bool reverse=false){
  if(reverse)swap(u,v);
  if(u==v || u<0 || v<0 || u>=n || v>=n || p[state][u]!=-1 || p[state][v]!=-1)throw runtime_error("duplicate or invalid endpoint");
  p[state][u]=v;p[state][v]=u;dir[state][u]=1;dir[state][v]=0;
 }
 void pairs(int state,const vector<int>& word){
  if(word.size()%2)throw runtime_error("odd core");
  for(size_t j=0;j<word.size();j+=2)edge(state,word[j],word[j+1]);
 }
 int parity()const{
  bool seen[MAX]={};int answer=0;
  for(int i=0;i<n;i++){
   if(p[0][i]<0 || p[1][i]<0)throw runtime_error("unpaired mode");
   if(seen[i])continue;
   int u=i,c=0,opposed=0,steps=0;
   do{seen[u]=true;opposed^=!dir[c][u];u=p[c][u];c^=1;if(++steps>n+1)throw runtime_error("loop error");}while(u!=i);
   if(c)throw runtime_error("odd alternating loop");
   answer^=1^opposed;
  }
  return answer;
 }
 int word_parity()const{
  int out=0;
  for(int state=0;state<2;state++){
   uint64_t seen[(MAX+63)/64]={};
   auto append=[&](int u){
    int w=u/64,b=u%64;
    if(b!=63)out^=__builtin_popcountll(seen[w]>>(b+1))&1;
    for(int j=w+1;j<(n+63)/64;j++)out^=__builtin_popcountll(seen[j])&1;
    seen[w]|=uint64_t(1)<<b;
   };
   for(int u=0;u<n;u++)if(u<p[state][u]){
    int v=p[state][u];if(dir[state][u]){append(u);append(v);}else{append(v);append(u);}
   }
  }
  return out;
 }
};
struct Data {
 int nv;int t[NV]={},w[NV][NV][NV]={},W[NV][NV][NV]={};
 int N[2][NV][NV]={},m[2][NV][NV][NV]={};
 bool anyw=false,anys=false;
 explicit Data(uint32_t mask,int vertices,bool two):nv(vertices){
  int at=0;auto bit=[&](){return (mask>>(at++))&1;};
  for(int i=1;i<nv;i++){t[i]=bit();anys|=t[i];}
  for(int i=1;i<nv;i++)for(int j=i+1;j<nv;j++){w[0][i][j]=bit();anyw|=w[0][i][j];}
  for(int i=1;i<nv;i++)for(int j=i+1;j<nv;j++)for(int k=j+1;k<nv;k++)w[i][j][k]=w[0][i][j]^w[0][i][k]^w[0][j][k];
  for(int i=0;i<nv;i++)for(int j=i+1;j<nv;j++)for(int k=j+1;k<nv;k++)W[i][j][k]=w[i][j][k]^((t[i]^t[j])&(t[j]^t[k]));
  for(int g=0;g<(two?2:1);g++){
   int a[NV]={},r[NV]={},x[NV]={};
   for(int i=1;i<nv;i++)a[i]=bit();
   for(int i=1;i<nv;i++)r[i]=a[i]+2*bit();
   for(int i=1;i<nv;i++)x[i]=x[i-1]+((r[i]-r[i-1]+4)%4);
   for(int i=0;i<nv;i++)for(int j=i+1;j<nv;j++)N[g][i][j]=x[j]-x[i];
   for(int i=1;i<nv;i++)for(int j=i+1;j<nv;j++)m[g][0][i][j]=bit();
   for(int i=1;i<nv;i++)for(int j=i+1;j<nv;j++)for(int k=j+1;k<nv;k++)m[g][i][j][k]=m[g][0][i][j]^m[g][0][i][k]^m[g][0][j][k]^(W[0][i][j]*(N[g][j][k]&1));
  }
  if(at!=24)throw runtime_error("input dimension");
 }
 void shift(int layer,int edge,int copies){
  for(int i=0;i<nv;i++)for(int j=i+1;j<nv;j++)if(i<=edge && edge<j)N[layer][i][j]+=copies;
 }
 int M(int g,Face f)const{return m[g][f[0]][f[1]][f[2]];}
 int L(int g,int i,int j)const{return N[g][i][j];}
};
Graph buildP(const Data& d){
 Graph g;int ordinary[2][4];vector<int> residual[2];
 for(int layer=0;layer<2;layer++){
  for(int f=0;f<4;f++)ordinary[layer][f]=d.M(layer,PF[f])?g.node():-1;
  for(int i=0;i<d.W[0][1][2]*d.L(layer,2,3);i++)residual[layer].push_back(g.node());
  vector<int> core;
  for(int f:{1,0})if(ordinary[layer][f]>=0)core.push_back(ordinary[layer][f]);
  core.insert(core.end(),residual[layer].begin(),residual[layer].end());
  for(int f:{3,2})if(ordinary[layer][f]>=0)core.push_back(ordinary[layer][f]);
  g.pairs(0,core);
 }
 vector<int> cross[4];int width[4];
 for(int f=0;f<4;f++){
  auto v=PF[f];width[f]=d.L(1,v[1],v[2]);
  for(int i=0;i<d.L(0,v[0],v[1])*width[f];i++)cross[f].push_back(g.node());
 }
 auto at=[&](int f,int a,int b){return cross[f][a*width[f]+b];};
 for(int a=0;a<d.L(0,1,2);a++)for(int b=0;b<d.L(1,2,3);b++)g.edge(0,at(0,a,b),at(2,a,b),bool(d.t[1] && ((b+1)&1)));
 for(int a=0;a<d.L(0,0,1);a++){
  for(int b=0;b<d.L(1,2,3);b++)g.edge(0,at(1,a,b),at(2,d.L(0,1,2)+a,b));
  for(int b=0;b<d.L(1,1,2);b++)g.edge(0,at(1,a,d.L(1,2,3)+b),at(3,a,b));
 }
 int survivor[4];
 for(int f=0;f<4;f++){
  vector<int> seq;for(int layer=0;layer<2;layer++)if(ordinary[layer][f]>=0)seq.push_back(ordinary[layer][f]);
  seq.insert(seq.end(),cross[f].begin(),cross[f].end());
  for(size_t j=0;j+1<seq.size();j+=2)g.edge(1,seq[j],seq[j+1],(f<2)^(f==0?d.t[1]:0));
  survivor[f]=(seq.size()%2)?seq.back():-1;
 }
 vector<int> core;
 for(int f:{1,0})if(survivor[f]>=0)core.push_back(survivor[f]);
 for(int layer=0;layer<2;layer++)core.insert(core.end(),residual[layer].begin(),residual[layer].end());
 for(int f:{3,2})if(survivor[f]>=0)core.push_back(survivor[f]);
 g.pairs(1,core);return g;
}
Face omit(Cell c,int j){Face f;int a=0;for(int i=0;i<4;i++)if(i!=j)f[a++]=c[i];return f;}
Graph buildF(const Data& d){
 Graph g;int id[NV][NV][NV];vector<Face> faces;
 for(int i=0;i<5;i++)for(int j=i+1;j<5;j++)for(int k=j+1;k<5;k++){
  id[i][j][k]=g.node();g.node();faces.push_back({i,j,k});
 }
 auto gid=[&](Face f){return id[f[0]][f[1]][f[2]];};
 vector<int> residual[5]; // 1234,0134,0123,0124,0234
 vector<int> first,second;
 int x=d.L(0,3,4),y=d.L(0,2,3);
 for(int i=0;i<d.W[0][1][2]*(x+y);i++)first.push_back(g.node());
 for(int i=0;i<d.W[0][2][3]*x;i++)second.push_back(g.node());
 residual[3]=first;residual[4]=second;
 if(d.W[0][1][2])residual[2]=vector<int>(first.begin()+x,first.end());
 vector<vector<int>> rows;
 if(d.W[0][1][2])rows.push_back(vector<int>(first.begin(),first.begin()+x));
 if(d.W[0][2][3])rows.push_back(second);
 vector<pair<int,int>> caps[2];int needed=d.W[1][2][3]+d.W[0][1][3];
 if(int(rows.size())!=needed){
  if(rows.size()==2 && needed==0){for(int i=0;i<x;i++)caps[0].push_back({rows[0][i],rows[1][i]});rows.clear();}
  else if(rows.empty() && needed==2){
   rows.resize(2);for(int r=0;r<2;r++)for(int i=0;i<x;i++)rows[r].push_back(g.node());
   for(int i=0;i<x;i++)caps[1].push_back({rows[0][i],rows[1][i]});
  }else throw runtime_error("reflection route balance");
 }
 for(int r=0;r<int(rows.size());r++){
  auto& dest=residual[r<d.W[1][2][3]?0:1];dest.insert(dest.end(),rows[r].begin(),rows[r].end());
 }
 int exterior=(g.n%2)?g.node():-1;
 const array<Cell,5> cells={Cell{1,2,3,4},Cell{0,1,3,4},Cell{0,1,2,3},Cell{0,1,2,4},Cell{0,2,3,4}};
 for(int state=0;state<2;state++){
  int incidence[NV][NV][NV]={},position[NV][NV][NV]={};
  for(int ci=(state?3:0);ci<(state?5:3);ci++){
   Cell cell=cells[ci];vector<int> core,polarity;
   for(int j=0;j<4;j++){auto f=omit(cell,j);incidence[f[0]][f[1]][f[2]]++;position[f[0]][f[1]][f[2]]=j;}
   for(int j:{2,0}){auto f=omit(cell,j);if(d.M(0,f)){core.push_back(gid(f)+1);polarity.push_back(1);}}
   for(int mode:residual[ci]){core.push_back(mode);polarity.push_back(1);}
   for(int j:{3,1}){auto f=omit(cell,j);if(d.M(0,f)){core.push_back(gid(f));polarity.push_back(0);}}
   if(core.size()%2)throw runtime_error("odd F core");
   for(size_t j=0;j<core.size();j+=2){
    int flip=0;
    if(cell[0]==1){int special=gid(omit(cell,0))+1;flip=d.w[0][1][2]*int(core[j]==special || core[j+1]==special);flip^=d.t[1]*(1^polarity[j]^polarity[j+1]);}
    g.edge(state,core[j],core[j+1],flip);
   }
  }
  for(auto [a,b]:caps[state])g.edge(state,a,b);
  vector<int> boundary;
  for(auto f:faces){
   int inc=incidence[f[0]][f[1]][f[2]],a=gid(f);
   if(!d.M(0,f) || !inc)g.edge(state,a,a+1);
   else if(inc==1)boundary.push_back(a+position[f[0]][f[1]][f[2]]%2);
   else if(inc!=2)throw runtime_error("face incidence");
  }
  if(exterior>=0)boundary.push_back(exterior);
  sort(boundary.begin(),boundary.end());g.pairs(state,boundary);
 }
 return g;
}
vector<unsigned char> truth(const string& file){
 vector<unsigned char> out(1u<<24,0);ifstream in(file);uint32_t mask;
 if(!in)throw runtime_error("missing comparator");
 while(in>>mask){if(mask>=out.size())throw runtime_error("ANF range");out[mask]^=1;}
 for(uint32_t bit=1;bit<out.size();bit<<=1){
  #pragma omp parallel for schedule(static)
  for(uint32_t block=0;block<out.size();block+=2*bit)for(uint32_t j=0;j<bit;j++)out[block+bit+j]^=out[block+j];
 }
 return out;
}
void dump(uint32_t mask,const Graph& g){
 cout<<"{\"mask\":"<<mask<<",\"mode_count\":"<<g.n<<",\"parity\":"<<g.parity()<<",\"dimers\":[";
 for(int s=0;s<2;s++){
  if(s)cout<<",";
  cout<<"[";bool first=true;
  for(int a=0;a<g.n;a++)if(a<g.p[s][a]){
   int b=g.p[s][a],u=g.dir[s][a]?a:b,v=g.dir[s][a]?b:a;
   if(!first)cout<<",";
   first=false;cout<<"["<<u<<","<<v<<"]";
  }cout<<"]";
 }cout<<"]}\n";
}
int main(int argc,char**argv){
 try{
  if(argc<3)throw runtime_error("usage: scan P|F comparator.anf [limit|--dump]");
  omp_set_num_threads(4);bool product=string(argv[1])=="P";
  if(argc>3 && string(argv[3])=="--dump"){
   uint32_t mask;while(cin>>mask){Data d(mask,product?4:5,product);auto g=product?buildP(d):buildF(d);dump(mask,g);}return 0;
  }
  if(argc>3 && string(argv[3])=="--periodic"){
   uint64_t tests=0;int maximum=0;
   for(uint32_t i=0;i<4096;i++){
    uint32_t mask=(i*0x9e3779u+0x42u)&((1u<<24)-1);
    Data base(mask,product?4:5,product);Graph original=product?buildP(base):buildF(base);int parity=original.parity();
    for(int layer=0;layer<(product?2:1);layer++)for(int edge=0;edge<(product?3:4);edge++)for(int copies:{4,12}){
     Data d=base;d.shift(layer,edge,copies);Graph g=product?buildP(d):buildF(d);
     if(g.parity()!=parity || g.word_parity()!=parity)throw runtime_error("four-copy parity test failed");
     maximum=max(maximum,g.n);tests++;
    }
   }
   cout<<"{\"move\":\""<<(product?"P":"F")<<"\",\"systematic_four_copy_checks\":"<<tests<<",\"max_modes\":"<<maximum<<",\"mismatches\":0}\n";
   return 0;
  }
  auto start=chrono::steady_clock::now();auto expected=truth(argv[2]);
  uint32_t limit=argc>3?stoul(argv[3]):(1u<<24);
  uint64_t mismatch=0,word_mismatch=0,odd=0,pure_gamma=0,background[4]={},background_odd[4]={};int max_modes=0;atomic<uint32_t> first{UINT32_MAX};
  #pragma omp parallel for reduction(+:mismatch,word_mismatch,odd,pure_gamma,background[:4],background_odd[:4]) reduction(max:max_modes) schedule(static)
  for(uint32_t i=0;i<limit;i++){
   uint32_t mask=(i*0x9e3779u+0x42u)&((1u<<24)-1);
   Data d(mask,product?4:5,product);Graph g=product?buildP(d):buildF(d);int count=g.parity();
   pure_gamma+=d.L(0,0,d.nv-1)==0 && (!product || d.L(1,0,d.nv-1)==0);
   int b=int(d.anyw)+2*int(d.anys);background[b]++;background_odd[b]+=count;odd+=count;max_modes=max(max_modes,g.n);
   if(count!=g.word_parity())word_mismatch++;
   if(count!=expected[mask]){mismatch++;uint32_t old=UINT32_MAX;first.compare_exchange_strong(old,mask);}
  }
  auto seconds=chrono::duration<double>(chrono::steady_clock::now()-start).count();
  cout<<"{\"move\":\""<<(product?"P":"F")<<"\",\"free_bits\":24,\"literal_graphs\":"<<limit<<",\"formula_mismatches\":"<<mismatch
      <<",\"pure_gamma_inputs\":"<<pure_gamma<<",\"word_parity_mismatches\":"<<word_mismatch<<",\"odd_cases\":"<<odd<<",\"max_modes\":"<<max_modes<<",\"seconds\":"<<seconds<<",\"first_mismatch\":"<<first.load()<<",\"background_cases\":[";
  for(int b=0;b<4;b++){if(b)cout<<",";cout<<background[b];}cout<<"],\"background_odd\":[";
  for(int b=0;b<4;b++){if(b)cout<<",";cout<<background_odd[b];}cout<<"]}\n";
  return (mismatch||word_mismatch)?1:0;
 }catch(const exception& e){cerr<<e.what()<<"\n";return 2;}
}

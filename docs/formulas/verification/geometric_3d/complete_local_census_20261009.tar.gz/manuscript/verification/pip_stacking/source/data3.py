"""Native manuscript inputs and independent local restrictions."""
from itertools import combinations
import random

def restrict(d,vertices):
    V=set(vertices)
    return {tuple(vertices.index(i) for i in f):v for f,v in d.items() if set(f)<=V}

def generate(nv=5,background='both',seed=0):
    r=random.Random(seed)
    t=[0]+[r.randrange(2) if background in ('s','both') else 0 for _ in range(nv-1)]
    s={f:t[f[0]]^t[f[1]] for f in combinations(range(nv),2)}
    e={f:r.randrange(2) if background in ('w','both') else 0 for f in s}
    omega={f:sum(e[g] for g in combinations(f,2))%2 for f in combinations(range(nv),3)}
    W={f:omega[f]^(s[f[:2]]*s[f[1:]]) for f in omega}
    def one():
        x=[0]
        for _ in range(nv-1):x.append(x[-1]+r.randrange(4))
        folded={f:x[f[1]]-x[f[0]] for f in s}
        n={f:(-1)**t[f[0]]*q for f,q in folded.items()}
        m={(0,i,j):r.randrange(2) for i,j in combinations(range(1,nv),2)}
        for i,j,k in combinations(range(1,nv),3):
            m[i,j,k]=(W[0,i,j]*folded[j,k]+m[0,j,k]+m[0,i,k]+m[0,i,j])%2
        native={f:m[f]^(s[f[:2]]*((n[f[1:]]//2)%2)) for f in m}
        return n,native
    n,m=one();np,mp=one()
    return {'n1':n,'n2':m,'n1prime':np,'n2prime':mp,'omega2':omega,'s1':s}

def output(data):
    n,m,np,mp,s=(data[q] for q in ('n1','n2','n1prime','n2prime','s1'))
    N={f:n[f]+np[f] for f in n}
    M={f:(m[f]+mp[f]+n[f[:2]]*np[f[1:]]+s[f[:2]]*n[f[1:]]*np[f[1:]])%2 for f in m}
    return N,M

def prepare(data):
    s=data['s1'];omega=data['omega2'];t={0:0,1:s[0,1],2:s[0,2],3:s[0,3]}
    def one(n,m):
        h={f:(q//2)%2 for f,q in n.items()}
        a={f:q%2 for f,q in n.items()}
        shifted={f:m[f]^(s[f[:2]]*h[f[1:]]) for f in m}
        folded={f:(-1)**t[f[0]]*q for f,q in n.items()}
        pad=max([0]+[max(0,(-q+4*(f[1]-f[0])-1)//(4*(f[1]-f[0]))) for f,q in folded.items()])
        lengths={f:q+4*pad*(f[1]-f[0]) for f,q in folded.items()}
        return lengths,a,h,shifted,pad
    n,a,h,m,pad=one(data['n1'],data['n2'])
    k,b,hp,v,padp=one(data['n1prime'],data['n2prime'])
    return (n,k,m,v,omega,s),(a,h,b,hp,m,v,omega,s),(pad,padp)

def dump(data):return {k:{''.join(map(str,f)):v for f,v in sorted(d.items())}for k,d in data.items()}
def load(data):return {k:{tuple(map(int,f)):v for f,v in d.items()}for k,d in data.items()}

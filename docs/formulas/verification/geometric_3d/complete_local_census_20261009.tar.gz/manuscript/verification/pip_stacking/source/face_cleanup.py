"""Actual two-ended triangle cleanup after both incident cores have been sewn.
No test output. The original upper gamma pair is the final carrier. Each lower
or exchange channel remains in its displayed reference dimer. External partners
are placeholders for unchanged bonds in the adjacent cores.
"""
from rotations import rotate_edges
from kasteleyn import loops

def build(upper_bit,lower_bit,columns,antiunitary_species):
    """columns contains each exchange mode's 1-indexed physical column number."""
    u,v,t=upper_bit,lower_bit,antiunitary_species
    if any(z not in (0,1)for z in (u,v,t)):raise ValueError('Expected bits')
    channels=[{'kind':'upper_gamma','ids':[0,1],'transport':[0,1],'reference_sign':1},
              {'kind':'lower_gamma','ids':[2,3],'transport':[0,1],'reference_sign':1}]
    for j,b in enumerate(columns):
        if b<1:raise ValueError('Columns start at one')
        channels.append({'kind':'exchange_psi','index':j+1,'column':b,
                         'ids':[4+2*j,5+2*j],'transport':[(b-1)%2]*2,'reference_sign':(-1)**t})
    active=([0]if u else[])+([1]if v else[])+list(range(2,len(channels)))
    survivor=active[-1]if len(active)%2 else None
    pairs=list(zip(active[::2],active[1::2]))
    # For an odd list the trailing singleton is not included by zip.
    n=2*len(channels);outside=[n,n+1]if survivor is not None else[]
    initial=[];gates=[]
    for i,bit in ((0,u),(1,v)):
        if not bit:initial.append(tuple(channels[i]['ids']))
    for i,j in pairs:
        x,y=channels[i],channels[j];xa,xb=x['ids'];ya,yb=y['ids'];kx=x['transport'];ky=y['transport']
        a=(-1)**(t*(1^kx[0]^ky[0]));b=(-1)**(t*(1^kx[1]^ky[1]))
        initial +=[(xa,ya)if a==1 else(ya,xa),(yb,xb)if b==1 else(xb,yb)]
        gates.append([xb,ya,-a*x['reference_sign']])
    theta=None
    if survivor is not None:
        x=channels[survivor];xa,xb=x['ids'];k=x['transport']
        theta=[(-1)**(t*k[0]),(-1)**(t*(k[1]^1))]
        initial +=[(xa,n)if theta[0]==1 else(n,xa),(xb,n+1)if theta[1]==1 else(n+1,xb)]
        if survivor!=0:gates +=[[xa,0,theta[0]],[xb,1,theta[1]]]
    actual=initial
    for a,b,q in gates:actual=rotate_edges(actual,a,b,q)
    target=[]
    for j,c in enumerate(channels):
        a,b=c['ids'];q=c['reference_sign']
        if j==0 and survivor is not None:target +=[(a,n),(b,n+1)]
        else:target.append((a,b)if q==1 else(b,a))
    if set(actual)!=set(target):raise AssertionError(('Face cleanup does not empty the lower carrier',u,v,columns,t))
    count=loops(initial,target,n+len(outside))
    if count['parity_change']:raise AssertionError('Cleanup cannot shift E3')
    return dict(channels=channels,active_channel_order=active,
                parked_channel_pairs=pairs,actual_survivor_channel=survivor,
                output_bit=len(active)%2,normalized_survivor_signs=theta,
                external_partner_ids=outside,dimers={'in':initial,'out':target},
                quarter_turn_gates=gates,mode_count=n+len(outside),count=count,
                lower_gamma_vacuum=[2,3],all_exchange_reference_pairs_retained=True)

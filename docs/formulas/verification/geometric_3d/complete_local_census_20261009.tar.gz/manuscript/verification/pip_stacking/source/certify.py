#!/usr/bin/env python3
"""Exact certificates AFTER the physical matching/permutation count.
These are not an enumeration of 2^38 separately constructed Hamiltonians.
"""
from itertools import combinations
from pathlib import Path
import json,time
from binary_poly import Poly
from graph_count import counted
from reference3 import target
from gauge import dA2,C3
from cup import op,dc
from prior_obstruction.algebra import counted_bits,manuscript_bits
Z=Poly.coerce(0)
def free(nv):
 names=[]
 def var(name):
  p=Poly.var(len(names));names.append(name);return p
 t=[Z]+[var('s0'+str(i))for i in range(1,nv)]
 s={(i,j):t[i]+t[j]for i,j in combinations(range(nv),2)}
 w={(0,i,j):var('omega0'+str(i)+str(j))for i,j in combinations(range(1,nv),2)}
 for i,j,k in combinations(range(1,nv),3):w[i,j,k]=w[0,i,j]+w[0,i,k]+w[0,j,k]
 W={f:w[f]+s[f[:2]]*s[f[1:]]for f in w}
 def one(prefix):
  a={(0,i):var(prefix+'a0'+str(i))for i in range(1,nv)}
  h={(0,i):var(prefix+'h0'+str(i))for i in range(1,nv)}
  for i,j in combinations(range(1,nv),2):
   a[i,j]=a[0,i]+a[0,j]
   h[i,j]=h[0,i]+h[0,j]+a[0,i]+a[0,i]*a[0,j]
  m={(0,i,j):var(prefix+'m0'+str(i)+str(j))for i,j in combinations(range(1,nv),2)}
  for i,j,k in combinations(range(1,nv),3):m[i,j,k]=W[0,i,j]*a[j,k]+m[0,i,j]+m[0,i,k]+m[0,j,k]
  return a,h,m
 a,h,m=one('upper_');b,k,v=one('lower_')
 return a,h,b,k,m,v,w,s,t,names

def run():
 start=time.monotonic()
 a,h,b,k,m,v,w,s,t,names4=free(4)
 hn={f:h[f]+t[f[0]]*a[f]for f in a};kn={f:k[f]+t[f[0]]*b[f]for f in b}
 obtained=counted(a,h,b,k,m,v,w,s)
 repo=target(a,hn,b,kn,m,v,w,s)
 gauge=dA2(a,hn,b,kn,m,v,s)
 match=obtained+repo+gauge
 assert not match
 a,h,b,k,m,v,w,s,t,names5=free(5)
 dE=Z
 for f in combinations(range(5),4):
  hf={e:h[e]+t[f[0]]*a[e]for e in h};kf={e:k[e]+t[f[0]]*b[e]for e in k}
  dE+=counted(a,hf,b,kf,m,v,w,s,f)
 hn={f:h[f]+t[f[0]]*a[f]for f in a};kn={f:k[f]+t[f[0]]*b[f]for f in b}
 total_a={f:a[f]+b[f]for f in a}
 total_h={f:hn[f]+kn[f]+a[f]*b[f]for f in a}
 total_m={f:m[f]+v[f]+a[f[:2]]*b[f[1:]]for f in m}
 def source(A,H,M):
  native={f:M[f]+s[f[:2]]*H[f[1:]]for f in M}
  physical=counted_bits(A,H,native,w,s,1)
  assert physical==manuscript_bits(A,H,native,w,s,1)
  return physical
 rhs=source(total_a,total_h,total_m)+source(a,hn,m)+source(b,kn,v)
 assert not dE+rhs
 # Nonclosed single-state B3 and a genuinely closed single-state C3.
 Bs=[op(M,2,M,2,1,5)for M in (total_m,m,v)]
 Cs=[C3(A,H,M,w,s,5)for A,H,M in ((total_a,total_h,total_m),(a,hn,m),(b,kn,v))]
 for C in Cs:assert not dc(C,3,5)[0,1,2,3,4]
 DeltaB={f:sum(B[f]for B in Bs)%2 for f in Bs[0]}
 DeltaC={f:sum(C[f]for C in Cs)%2 for f in Cs[0]}
 dDB=dc(DeltaB,3,5)[0,1,2,3,4]
 dDC=dc(DeltaC,3,5)[0,1,2,3,4]
 DdB=sum((dc(B,3,5)[0,1,2,3,4]for B in Bs),Z)
 assert not (dE+dDB+dDC)+(rhs+DdB)
 assert dDB # Omitting the paired product change must actually fail.
 result={
  'scope':'Exact cochain identities for the separately derived packet count; microscopic parent not asserted.',
  'local_representative':{'free_bits':len(names4),'formal_assignments':str(1<<len(names4)),
     'physical_count_monomials':len(obtained.terms),'reference_monomials':len(repo.terms),
     'pair_boundary_monomials':len(gauge.terms),'residual_monomials':len(match.terms)},
  'physical_F_P_compatibility':{'free_bits':len(names5),'formal_assignments':str(1<<len(names5)),
     'dE_monomials':len(dE.terms),'Delta_O4_monomials':len(rhs.terms),'residual_monomials':len((dE+rhs).terms)},
  'gauge_checks':{'closed_single_state_C3':True,'paired_B3_and_C3_invariance':True,
      'unpaired_B3_failure_monomials':len(dDB.terms)},
  'variables_local':names4,'variables_compatibility':names5,
  'seconds':round(time.monotonic()-start,3)}
 return result
if __name__=='__main__':
 result=run();dest=Path(__file__).resolve().parents[1]/'results/exact_certificate.json'
 dest.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

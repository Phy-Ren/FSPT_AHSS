"""Parity from complete *directed* perfect matchings. No cochains are used.

Repeated geometric edges of the two colors are kept separately. In particular,
oppositely directed dimers on the same pair of modes form a parity-odd two-edge
transition loop, rather than a common dimer to discard.
"""
from __future__ import annotations


def _matching(dimers, count):
    partners = {};forward=set()
    for edge in dimers:
        if len(edge)!=2:
            raise ValueError('A dimer must contain two IDs')
        u,v=edge
        if u==v or u in partners or v in partners:
            raise ValueError('Each real mode must have exactly one partner per state')
        partners[u]=v;partners[v]=u;forward.add((u,v))
    if set(partners)!=set(range(count)):
        raise ValueError('The matching does not cover the common Hilbert space')
    return partners,forward


def loops(dimers_in, dimers_out, count=None):
    """Return the parity bit and every alternating transition loop."""
    if count is None: count=2*len(dimers_in)
    if count%2 or count!=2*len(dimers_in) or count!=2*len(dimers_out):
        raise ValueError('Both matchings must be perfect on the same even set')
    matches=[_matching(dimers_in,count),_matching(dimers_out,count)]
    remaining=set(range(count));answer=[];parity=0
    while remaining:
        start=min(remaining);node=start;color=0;opposite=0;path=[]
        while True:
            partner,forward=matches[color]
            nxt=partner[node];against=int((node,nxt) not in forward)
            path.append({'from':node,'to':nxt,'state':'in' if color==0 else 'out',
                         'against_arrow':against})
            opposite+=against;remaining.discard(node)
            node=nxt;color^=1
            if node==start:
                if color!=0:raise AssertionError('An alternating loop must have even length')
                break
            if len(path)>count:raise AssertionError('Malformed transition graph')
        change=(1+opposite)%2;parity^=change
        answer.append({'length':len(path),'opposite_arrows':opposite,
                       'kasteleyn':bool(opposite%2),'parity_change':change,'edges':path})
    return {'parity_change':parity,'loops':answer}


def word_parity(dimers):
    """Independent integer bit-set inversion count of the paired operator word."""
    word=[i for edge in dimers for i in edge]
    if sorted(word)!=list(range(len(word))) or len(word)%2:
        raise ValueError('Not a full ordering of the common Majoranas')
    seen=0;parity=0
    for value in reversed(word):
        parity^=(seen & ((1<<value)-1)).bit_count()%2
        seen|=1<<value
    return parity


def matrix(dimers):
    """Return the real skew matrix of H=(i/4) chi^T A chi, with unit gap."""
    import numpy as np
    count=2*len(dimers);_matching(dimers,count)
    a=np.zeros((count,count),dtype=int)
    for i,j in dimers:a[i,j]=1;a[j,i]=-1
    return a


def pfaffian_sign(a):
    """Independent pivoted skew Gaussian elimination. No dimer-word shortcut."""
    import numpy as np
    a=np.array(a,dtype=float,copy=True)
    n=len(a)
    if a.shape!=(n,n) or n%2 or not np.array_equal(a,-a.T):
        raise ValueError('Expected a real skew matrix of even dimension')
    sign=1
    for k in range(0,n-1,2):
        j=k+1+int(np.argmax(np.abs(a[k,k+1:])))
        if abs(a[k,j])<1e-12:raise ValueError('Singular Hamiltonian')
        if j!=k+1:
            a[[k+1,j],:]=a[[j,k+1],:];a[:,[k+1,j]]=a[:,[j,k+1]];sign=-sign
        pivot=a[k,k+1];sign*=1 if pivot>0 else -1
        u=a[k,k+2:].copy();v=a[k+1,k+2:].copy()
        a[k+2:,k+2:]+=(np.outer(v,u)-np.outer(u,v))/pivot
    return sign

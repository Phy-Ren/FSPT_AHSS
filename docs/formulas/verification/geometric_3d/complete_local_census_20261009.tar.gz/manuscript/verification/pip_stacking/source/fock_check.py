"""Independent finite Fock-space test of the displayed, norm-one core circuits.
This test applies operators to state vectors; it does not infer success from
matching parity or from an SO determinant alone. NumPy is optional elsewhere.
"""
import numpy as np

def majorana(vector,k):
    dim=len(vector);indices=np.arange(dim,dtype=np.int64);j=k//2
    lower=indices&((1<<j)-1)
    signs=np.array([(-1)**int(i).bit_count() for i in lower],dtype=complex)
    if k%2:signs*=1j*(1-2*((indices>>j)&1))
    result=np.empty_like(vector);result[indices^(1<<j)]=signs*vector
    return result

def product(vector,u,v):return majorana(majorana(vector,v),u)

def verify(record,seed=0):
    c=record['core_unitary'];n=c['total_mode_count'];dim=1<<(n//2)
    if dim>1<<16:raise ValueError('Fock test deliberately capped at 16 complex modes')
    rng=np.random.default_rng(seed);state=rng.normal(size=dim)+1j*rng.normal(size=dim)
    state/=np.linalg.norm(state)
    for u,v in c['start']:
        state=(state-1j*product(state,u,v))/2
        norm=np.linalg.norm(state)
        if norm<1e-12:raise AssertionError('Unexpected zero initial-state preparation')
        state/=norm
    initial_error=max([0]+[float(np.linalg.norm(-1j*product(state,u,v)-state))for u,v in c['start']])
    for u,v,q in c['gates']:state=(state-q*product(state,u,v))/np.sqrt(2)
    final_error=max([0]+[float(np.linalg.norm(-1j*product(state,u,v)-state))for u,v in c['end']])
    norm_error=abs(float(np.linalg.norm(state))-1)
    if max(initial_error,final_error,norm_error)>1e-10:raise AssertionError((initial_error,final_error,norm_error))
    return dict(real_modes=n,fock_dimension=dim,quarter_turns=len(c['gates']),
                initial_stabilizer_error=initial_error,final_stabilizer_error=final_error,
                norm_error=norm_error)
if __name__=='__main__':
    import json
    from pathlib import Path
    root=Path(__file__).resolve().parents[1];out={}
    for path in sorted((root/'cases').glob('*.json')):
        r=json.loads(path.read_text())
        if 'core_unitary'in r:out[path.stem]=verify(r)
    (root/'results'/'fock_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))

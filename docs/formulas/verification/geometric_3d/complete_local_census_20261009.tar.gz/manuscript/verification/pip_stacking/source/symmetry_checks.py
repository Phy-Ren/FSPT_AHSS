"""Exact sign checks for the declared complete-face frame and actual gates."""
from itertools import product
import json
from pathlib import Path

def run():
 count=0;types=((0,1),(0,0),(1,1))
 for t,g,w,x,y in product(range(2),range(2),range(2),types,types):
  # Both channels have the same face species; projective signs cancel in a bridge.
  def signs(tt):
   qx=(-1)**(tt*(1^x[0]^x[1]));qy=(-1)**(tt*(1^y[0]^y[1]))
   a=(-1)**(tt*(1^x[0]^y[0]));b=(-1)**(tt*(1^x[1]^y[1]))
   return qx,qy,a,b
  qx,qy,a,b=signs(t);Qx,Qy,A,B=signs(t^g)
  assert Qx==qx*(-1)**(g*(1^x[0]^x[1]))
  assert Qy==qy*(-1)**(g*(1^y[0]^y[1]))
  assert A==a*(-1)**(g^w^w^(g*x[0])^(g*y[0]))
  assert B==b*(-1)**(g^w^w^(g*x[1])^(g*y[1]))
  # The cleanup generator is real: no i-conjugation term belongs in its exponent.
  assert -A*Qx==(-a*qx)*(-1)**(g*(x[1]^y[0]))
  count+=1
 transfers=0
 for t,g,k in product(range(2),range(2),types):
  for C in (0,1):
   theta=(-1)**(t*(k[C]^C));new=(-1)**((t^g)*(k[C]^C))
   assert new==theta*(-1)**(g*(k[C]^C));transfers+=1
 return dict(complete_face_covariance_cases=count,survivor_rotation_covariance_cases=transfers,
             mismatches=0,scope='Declared full-channel reference and real even generators, not a microscopic parent theorem.')
if __name__=='__main__':
 r=run();root=Path(__file__).resolve().parents[1]
 (root/'results'/'symmetry_checks.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))

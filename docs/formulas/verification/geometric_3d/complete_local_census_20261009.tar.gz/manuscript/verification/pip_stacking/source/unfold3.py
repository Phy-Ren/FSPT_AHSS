"""Two chronological core states, WITHOUT an output-test copy.
All vertices are original upper/lower endpoints or resolved exchange modes.
No target formula is used to place, route, or pair modes.
"""
from itertools import combinations
F=((1,2,3),(0,1,3),(0,2,3),(0,1,2))

def build(N,K,U,V,omega,s):
    from kasteleyn import loops
    for values,degree in ((N,1),(K,1),(U,2),(V,2),(omega,2),(s,1)):
        if set(values)!=set(combinations(range(4),degree+1)):
            raise ValueError('Every face must be supplied')
    for values in (U,V,omega,s):
        if any(x not in (0,1)for x in values.values()):raise ValueError('Expected binary cochain')
    for f in combinations(range(4),3):
        if sum(s[e]for e in combinations(f,2))%2:raise ValueError('ds1 is nonzero')
        for values in (N,K):
            if values[f[1:]]-values[f[::2]]+values[f[:2]]:raise ValueError('Integer channel balance fails')
    if sum(omega.values())%2:raise ValueError('domega2 is nonzero')
    if min(*N.values(),*K.values())<0:raise ValueError('Use the declared nonnegative signed-reference realization')
    t={0:0,1:s[0,1],2:s[0,2],3:s[0,3]}
    w012=omega[0,1,2]^(s[0,1]*s[1,2])
    modes=[];ordinary={};res={};arrays={};start=[]
    def new(kind,**extra):
        i=len(modes);modes.append(dict(id=i,kind=kind,**extra));return i
    cores=[]
    for group,n,bits in [('upper',N,U),('lower',K,V)]:
        for j,f in enumerate(F):
            if bits[f]:
                ordinary[group,f]=new('ordinary',group=group,face=list(f),side='B' if j<2 else 'A',transport_bit=int(j<2))
        res[group]=[new('residual',group=group,cell=[0,1,2,3],copy=q+1,transport_bit=1)
                    for q in range(w012*n[2,3])]
        seq=[ordinary[group,f] for f in F[:2] if bits[f]]+res[group]+[ordinary[group,f] for f in F[2:] if bits[f]]
        if len(seq)%2:raise ValueError('Odd input core')
        pairs=list(zip(seq[::2],seq[1::2]));start.extend(pairs)
        cores.append(dict(group=group,modes=seq,dimers=pairs))
    for j,f in enumerate(F):
        arrays[f]=[[new('cross_exchange',group='reference',face=list(f),side='B' if j<2 else 'A',row=a+1,column=b+1,transport_bit=b%2)
                for b in range(K[f[1:]])]for a in range(N[f[:2]])]
    refs=[]
    for a in range(N[1,2]):
        for b in range(K[2,3]):refs.append((arrays[1,2,3][a][b],arrays[0,2,3][a][b]))
    for a in range(N[0,1]):
        for b in range(K[2,3]):refs.append((arrays[0,1,3][a][b],arrays[0,2,3][N[1,2]+a][b]))
        for b in range(K[1,2]):refs.append((arrays[0,1,3][a][K[2,3]+b],arrays[0,1,2][a][b]))
    start.extend(refs)
    caps=[];survivors={};face_records=[]
    for j,f in enumerate(F):
        seq=[ordinary[g,f]for g,M in [('upper',U),('lower',V)]if M[f]]+[i for row in arrays[f]for i in row]
        active=len(seq)%2;paired=seq[:-1]if active else seq
        arrows=[]
        for a,b in zip(paired[::2],paired[1::2]):
            flip=int(j<2)^ (t[f[0]]*(1^modes[a]['transport_bit']^modes[b]['transport_bit']))
            arrows.append((b,a)if flip else(a,b))
        caps.extend(arrows)
        if active:
            a=seq[-1];theta=t[f[0]]*(modes[a]['transport_bit']^int(j<2))
            survivors[f]=(a,theta)
        face_records.append(dict(face=list(f),list=seq,caps=arrows,
                                 survivor=survivors.get(f),output_bit=active))
    output_seq=[survivors[f]for f in F[:2]if f in survivors]+[(r,0)for r in res['upper']+res['lower']]+[survivors[f]for f in F[2:]if f in survivors]
    if len(output_seq)%2:raise ValueError('Odd output core')
    output=[]
    for (a,ea),(b,eb) in zip(output_seq[::2],output_seq[1::2]):output.append((b,a)if ea^eb else(a,b))
    final=caps+output
    count=loops(start,final,len(modes))
    return dict(semantics='Two actual chronological core matchings; no output-test modes.',
                modes=modes,mode_count=len(modes),input_cores=cores,
                exchange_reference=refs,face_steps=face_records,output_core=output,
                output_order=output_seq,dimers={'in':start,'out':final},count=count)

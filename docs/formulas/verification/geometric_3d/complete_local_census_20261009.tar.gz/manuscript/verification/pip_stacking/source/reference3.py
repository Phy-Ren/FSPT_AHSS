"""Independent GitHub comparator, not imported by any graph builder.
Read on 2026-10-07, THREE_DIMENSIONAL.md complex-fermion stacking.
m and mprime denote the manuscripts' shifted chain coordinates.
"""
from cup import cup,op,dc
def plus(*cs):
    return {f:sum(c[f]for c in cs)%2 for f in cs[0]}
def target(a,h,b,k,m,v,omega,s):
    nv=4
    w=plus(omega,op(s,1,s,1,0,nv))
    N=plus(a,b);t=op(a,1,b,1,0,nv);q=op(a,1,b,1,1,nv)
    dm=dc(m,2,nv)
    ordinary=cup(m,2,v,2,1)+cup(s,1,op(m,2,v,2,2,nv),2)
    mixed=cup(dm,3,v,2,2)+cup(plus(m,v),2,t,2,1)+cup(s,1,op(plus(m,v),2,t,2,2,nv),2)
    pure=cup(op(a,1,t,2,1,nv),2,b,1)
    pure+=cup(op(w,2,N,1,0,nv),3,t,2,2)
    pure+=cup(dc(h,1,nv),2,k,1)
    pure+=cup(op(s,1,a,1,0,nv),2,op(b,1,b,1,0,nv),2,1)
    pure+=cup(a,1,op(s,1,b,1,0,nv),2)
    pure+=cup(q,1,op(s,1,N,1,0,nv),2)
    inside=plus(op(s,1,q,1,0,nv),op(a,1,dc(k,1,nv),2,1,nv),op(q,1,N,1,0,nv))
    pure+=cup(s,1,inside,2)
    for z in (N,a,b):
        pure+=cup(op(op(z,1,z,1,0,nv),2,s,1,1,nv),2,z,1)
    return (ordinary+mixed+pure)%2

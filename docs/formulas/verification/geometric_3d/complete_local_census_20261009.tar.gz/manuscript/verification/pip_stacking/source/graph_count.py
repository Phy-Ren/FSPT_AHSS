"""Exact packet-level count of the explicitly constructed doubled-boundary graph.
The count uses lengths modulo four only after deriving the permutation formula.
No target obstruction or stacking formula occurs in counted().
"""
from itertools import combinations
from dataclasses import dataclass
@dataclass(frozen=True)
class D:
    lo: object
    hi: object=0
    def __add__(self,b):
        if not isinstance(b,D):b=D(b,0)
        return D((self.lo+b.lo)%2,(self.hi+b.hi+self.lo*b.lo)%2)
    __radd__=__add__
    def __mul__(self,b):
        if not isinstance(b,D):b=D(b,0)
        return D(self.lo*b.lo%2,(self.hi*b.lo+self.lo*b.hi)%2)
    __rmul__=__mul__
def counted(a,h,b,k,U,V,omega,s,f=(0,1,2,3)):
    i,j,l,r=f
    fs=((j,l,r),(i,l,r),(i,j,r),(i,j,l)) # temporarily corrected below
    fs=((j,l,r),(i,j,r),(i,l,r),(i,j,l)) # B,B,A,A
    w=omega[i,j,l]+s[i,j]*s[j,l]
    w=w%2
    nn={e:D(a[e],h[e])for e in combinations(f,2)}
    kk={e:D(b[e],k[e])for e in combinations(f,2)}
    c={g:nn[g[:2]]*kk[g[1:]]for g in fs}
    T={g:(U[g]+V[g]+c[g].lo)%2 for g in fs}
    ru=D(w,0)*nn[l,r];rv=D(w,0)*kk[l,r];ro=ru+rv
    # Initial core permutations: move each residual block before its A ports.
    value=sum(x.lo*(M[fs[2]]+M[fs[3]]) for x,M in [(ru,U),(rv,V),(ro,T)])%2
    # Covariant dual of the output core.
    output_len=sum((D(T[g])for g in fs),D(0))+ro
    value=(value+output_len.hi+T[fs[0]]+T[fs[1]]+s[i,j]*T[fs[0]]+ro.lo)%2
    # Actual product routing of cross-layer endpoints.
    u,v=nn[i,j],nn[j,l];VV,WW=kk[j,l],kk[l,r]
    R=v*WW+u*(WW+VV)
    value=(value+R.hi+u.hi*VV.lo*WW.lo)%2
    # Reorder the literal boundary words.
    lengths={};old=[]
    for group,M,res in [('u',U,ru),('v',V,rv),('o',T,ro)]:
        for ix,g in enumerate(fs):
            label=(group,ix);lengths[label]=M[g];old.append(label)
        label=(group,'res');lengths[label]=res.lo;old.append(label)
    for ix,g in enumerate(fs):
        label=('x',ix);lengths[label]=c[g].lo;old.append(label)
    new=[]
    for ix in range(4):new.extend([('u',ix),('v',ix),('x',ix),('o',ix)])
    new.extend([('u','res'),('v','res'),('o','res')])
    order={label:q for q,label in enumerate(new)}
    for q,L in enumerate(old):
        for Rlabel in old[q+1:]:
            if order[L]>order[Rlabel]:value=(value+lengths[L]*lengths[Rlabel])%2
    value=(value+ro.hi)%2 # interleave residual identities
    # Every B-face cap has the opposite arrow. Root species contributes too.
    for ix,g in enumerate(fs):
        size=D(U[g])+D(V[g])+c[g]+D(T[g])
        flip=(int(ix<2)+(s[i,j]if ix==0 else 0))%2
        value=(value+flip*size.hi)%2
    value=(value+ro.lo)%2 # residual vertical bridges are reversed
    return (value+s[i,j]*a[j,l]*(k[l,r]+b[l,r]))%2

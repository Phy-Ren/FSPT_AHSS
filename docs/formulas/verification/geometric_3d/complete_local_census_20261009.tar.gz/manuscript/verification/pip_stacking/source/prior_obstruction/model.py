"""Literal implementation of the setup specification, without an O4/O5 oracle.

All real-mode IDs, both complete directed matchings, local placement tables,
reference caps, and arrow flips are returned.  Higher cup products do not occur
in this module.  The model is a framed effective parity network; a derivation
from a single microscopic chiral parent is not assumed.
"""
from __future__ import annotations
from dataclasses import dataclass
from itertools import combinations
from typing import Mapping

Face = tuple[int, ...]

@dataclass(frozen=True)
class Input:
    p: int  # 1: 3+1D; 2: 4+1D. The degree of the integer decoration.
    N: Mapping[Face, int]
    M: Mapping[Face, int]
    omega: Mapping[Face, int]
    s: Mapping[Face, int]

    def validate(self) -> None:
        if self.p not in (1, 2):
            raise ValueError('p must be 1 (3+1D) or 2 (4+1D)')
        vertices = range(self.p + 4)
        for name, values, degree, binary in (
            ('N', self.N, self.p, False), ('M', self.M, self.p+1, True),
            ('omega', self.omega, 2, True), ('s', self.s, 1, True)):
            if set(values) != set(combinations(vertices, degree+1)):
                raise ValueError(f'{name}: specify every ordered face of degree {degree}')
            if any(type(v) is not int or (binary and v not in (0, 1)) for v in values.values()):
                raise ValueError(f'{name}: invalid integer or binary value')
        for f in combinations(vertices, 3):
            if sum(self.s[e] for e in combinations(f, 2)) % 2:
                raise ValueError(f'ds1 is nonzero on {f}')
        for f in combinations(vertices, 4):
            if sum(self.omega[e] for e in combinations(f, 3)) % 2:
                raise ValueError(f'domega2 is nonzero on {f}')
        for f in combinations(vertices, self.p+2):
            boundary = (-1)**self.s[f[:2]] * self.N[f[1:]]
            boundary += sum((-1)**j*self.N[f[:j]+f[j+1:]] for j in range(1, len(f)))
            if boundary:
                raise ValueError(f'The integer equation d_s1 N=0 fails on {f}')
        for f in combinations(vertices, self.p+3):
            if self.p == 1:
                i,j,k,l = f
                source = (self.omega[i,j,k]+self.s[i,j]*self.N[j,k])*self.N[k,l]
            else:
                i,j,k,l,m = f
                source = (self.N[i,j,k]+self.omega[i,j,k])*self.N[k,l,m]
                source += self.s[i,j]*(self.N[j,l,m]*self.N[j,k,l]+self.N[j,k,m]*self.N[k,l,m])
            if (source+sum(self.M[g] for g in combinations(f, self.p+2))) % 2:
                raise ValueError(f'Ordinary and effective endpoints do not close on {f}')


def face(cell: Face, j: int) -> Face:
    return cell[:j]+cell[j+1:]


def frames(data: Input, extra_padding: int = 0):
    """Return the stated common-frame, nonnegative parity realization.

    Padding is NOT the assertion that four microscopic p+ip layers are trivial.
    It is a finite realization of signed parity data. See the paper's scope.
    """
    if type(extra_padding) is not int or extra_padding < 0:
        raise ValueError('extra_padding must be a nonnegative integer')
    t = {0: 0, **{i: data.s[0,i] for i in range(1, data.p+4)}}
    folded = {f: (-1)**t[f[0]]*n for f,n in data.N.items()}
    c = {f: f[1]-f[0] if data.p == 1 else 1 for f in folded}
    k = max([0]+[max(0,(-n+4*c[f]-1)//(4*c[f])) for f,n in folded.items()])
    k += extra_padding
    L = {f: n+4*k*c[f] for f,n in folded.items()}
    w = {f: data.omega[f] ^ (data.s[f[:2]]*data.s[f[1:]]) for f in data.omega}
    m = {f: data.M[f] ^ (data.s[f[:2]]*((data.N[f[1:]]//2)%2)) for f in data.M}
    return folded, L, w, m, k


class Builder:
    def __init__(self, data: Input):
        self.data = data
        self.modes: list[dict] = []
        self.events: list[dict] = []
        self.ordinary_faces = tuple(combinations(range(data.p+4), data.p+2))
        self.ids = {}
        for f in self.ordinary_faces:
            self.ids[f] = len(self.modes)
            for label in ('A', 'B'):
                self.new_mode('ordinary', face=list(f), port_type=label)

    def new_mode(self, kind: str, **details) -> int:
        identity = len(self.modes)
        self.modes.append({'id': identity, 'kind': kind, **details})
        return identity

    def new_array(self, kind: str, cell: Face, height: int, width: int):
        return [[self.new_mode(kind, creation_cell=list(cell), row=i+1, column=j+1)
                 for j in range(width)] for i in range(height)]

    def row_fusion(self, rows, needed_rows: int, width: int, kind: str,
                   origin_side: str, destination_side: str, caps):
        current = len(rows)
        if current == needed_rows:
            return rows
        if kind != 'projective' or {current,needed_rows} != {0,2}:
            raise ValueError('Only a pair of binary reflection rows may appear/disappear')
        if current == 2:
            paired = [(rows[0][j], rows[1][j]) for j in range(width)]
            caps[destination_side].extend(paired)
            self.events.append({'event':'reflection_pair_annihilation', 'side':destination_side,
                                'width':width, 'dimers':[list(e) for e in paired]})
            return []
        rows = [[self.new_mode(kind, creation_reference='reflection_pair', row=i+1, column=j+1)
                 for j in range(width)] for i in range(2)]
        paired = [(rows[0][j], rows[1][j]) for j in range(width)]
        caps[origin_side].extend(paired)
        self.events.append({'event':'reflection_pair_creation', 'side':origin_side,
                            'width':width, 'dimers':[list(e) for e in paired]})
        return rows

    def route_3d(self, L, w, caps):
        # Route the two-cell OUT side to the three-cell IN side, as in the paper.
        rows_0124 = self.new_array('projective', (0,1,2,4), w[0,1,2], L[2,4])
        rows_0234 = self.new_array('projective', (0,2,3,4), w[0,2,3], L[3,4])
        x = L[3,4]
        columns_34 = [row[:x] for row in rows_0124]
        parked_23 = [row[x:] for row in rows_0124]
        rows = columns_34+rows_0234
        rows = self.row_fusion(rows, w[1,2,3]+w[0,1,3], x, 'projective', 'out','in',caps)
        n = w[1,2,3]
        flat = lambda array: [q for row in array for q in row]
        return {'in': {(1,2,3,4):flat(rows[:n]), (0,1,3,4):flat(rows[n:]),
                       (0,1,2,3):flat(parked_23)},
                'out': {(0,1,2,4):flat(rows_0124), (0,2,3,4):flat(rows_0234)}}

    def route_4d(self, P, L, kind, caps):
        first = self.new_array(kind, (0,1,2,3,4), P[0,1,2], L[2,3,4])
        second = self.new_array(kind, (0,1,2,4,5), P[0,1,2], L[2,4,5])
        third = self.new_array(kind, (0,2,3,4,5), P[0,2,3], L[3,4,5])
        x = L[3,4,5]
        joined = [r1+r2 for r1,r2 in zip(first,second)]
        columns_345 = [row[:x] for row in joined]
        parked_235 = [row[x:] for row in joined]
        rows = columns_345+third
        rows = self.row_fusion(rows, P[1,2,3]+P[0,1,3], x, kind, 'in','out',caps)
        n = P[1,2,3]
        flat = lambda array: [q for row in array for q in row]
        return {'in': {(0,1,2,3,4):flat(first), (0,1,2,4,5):flat(second),
                       (0,2,3,4,5):flat(third)},
                'out': {(1,2,3,4,5):flat(rows[:n]), (0,1,3,4,5):flat(rows[n:]),
                        (0,1,2,3,5):flat(parked_235)}}


IN3 = ((1,2,3,4), (0,1,3,4), (0,1,2,3))
OUT3 = ((0,1,2,4), (0,2,3,4))
IN4 = ((0,1,2,3,4), (0,1,2,4,5), (0,2,3,4,5))
OUT4 = ((1,2,3,4,5), (0,1,3,4,5), (0,1,2,3,5))


def build(data: Input, *, extra_padding: int = 0) -> dict:
    """Build complete directed matchings and all incidence/sign metadata.

    The returned dimers are already directed: a pair [u,v] means -i chi_u chi_v=+1.
    No additional sign is to be multiplied after the transition-loop count.
    """
    data.validate()
    folded,L,w,m,padding = frames(data,extra_padding)
    b = Builder(data)
    caps = {'in':[], 'out':[]}
    if data.p == 1:
        orders = {'in':IN3, 'out':OUT3}
        projective = b.route_3d(L,w,caps)
        intrinsic = {side:{cell:[] for cell in orders[side]} for side in orders}
    else:
        orders = {'in':IN4, 'out':OUT4}
        intrinsic = b.route_4d(L,L,'intrinsic',caps)
        projective = b.route_4d(w,L,'projective',caps)
    ordinary_count = 2*len(b.ordinary_faces)
    active_count = len(b.modes)
    external = b.new_mode('exterior_reference') if active_count % 2 else None
    matchings, placements, local_lists, logs = {}, {}, {}, {}
    for side in ('in','out'):
        edges = []
        locations = []
        rows = []
        arrow_log = []
        incidence = {f:[] for f in b.ordinary_faces}
        for cell in orders[side]:
            ordered = []
            polarities = {}
            for j in range(0,len(cell),2):
                f = face(cell,j);incidence[f].append(j)
                if m[f]:
                    mode = b.ids[f]+1
                    ordered.append(mode);polarities[mode]=1
                    locations.append({'id':mode,'cell':list(cell),'omitted_position':j,'source':'ordinary','kappa_ref':1})
            for kind,packet in (('intrinsic',intrinsic[side][cell]), ('projective',projective[side][cell])):
                width = L[cell[2:]]
                for j,mode in enumerate(packet):
                    row,column = divmod(j,width)
                    kappa = (column+1)%2 if kind == 'intrinsic' else 1
                    ordered.append(mode);polarities[mode]=kappa
                    locations.append({'id':mode,'cell':list(cell),'source':kind,'row':row+1,
                                      'column':column+1,'kappa_ref':kappa})
            for j in range(1,len(cell),2):
                f = face(cell,j);incidence[f].append(j)
                if m[f]:
                    mode = b.ids[f]
                    ordered.append(mode);polarities[mode]=0
                    locations.append({'id':mode,'cell':list(cell),'omitted_position':j,'source':'ordinary','kappa_ref':0})
            if len(ordered)%2:
                raise ValueError(f'Odd local list in {cell}; check the lower equation')
            rows.append({'cell':list(cell),'modes':ordered})
            for u,v in zip(ordered[::2],ordered[1::2]):
                flip_omega = flip_s = 0
                if cell[0] == 1:
                    # The only nonstandard cell is 1234 or 12345.
                    special = b.ids[cell[1:]]+1
                    flip_omega = data.omega[0,1,2]*int(special in (u,v))
                    flip_s = data.s[0,1]*(1 ^ polarities[u] ^ polarities[v])
                flip = flip_omega ^ flip_s
                directed = [v,u] if flip else [u,v]
                edges.append(directed)
                arrow_log.append({'cell':list(cell),'standard_dimer':[u,v],
                                  'omega_flip':flip_omega,'antiunitary_flip':flip_s,
                                  'actual_dimer':directed})
        edges.extend([list(edge) for edge in caps[side]])
        exterior_ports = []
        for f,js in incidence.items():
            a = b.ids[f]
            if not m[f] or not js:
                edges.append([a,a+1])
            elif len(js)==1:
                exterior_ports.append(a+js[0]%2)
            elif len(js)!=2 or js[0]%2 == js[1]%2:
                raise ValueError('The oriented face incidence is inconsistent')
        if external is not None:
            exterior_ports.append(external)
        exterior_ports.sort()
        if len(exterior_ports)%2:
            raise ValueError('The common exterior has odd dimension')
        edges.extend([[u,v] for u,v in zip(exterior_ports[::2],exterior_ports[1::2])])
        flat = [i for edge in edges for i in edge]
        if sorted(flat) != list(range(len(b.modes))):
            raise ValueError('A mode is missing or paired more than once')
        matchings[side] = edges; placements[side] = locations; local_lists[side]=rows;logs[side]=arrow_log
    def stringify(values):
        return {''.join(map(str,f)):v for f,v in sorted(values.items())}
    return {'schema':'effective-majorana-network-v2','p':data.p,'spatial_dimension':data.p+2,
            'input':{'n_integer':stringify(data.N),'n_majorana':stringify(data.M),
                     'omega2':stringify(data.omega),'s1':stringify(data.s)},
            'frames':{'folded_signed_layers':stringify(folded),'resolved_lengths':stringify(L),
                      'omega2_prime':stringify(w),'shifted_majorana':stringify(m),
                      'common_padding':padding},
            'ordinary_mode_count':ordinary_count,'mode_count':len(b.modes),
            'modes':b.modes,'placements':placements,'local_lists':local_lists,
            'reference_caps':{side:[list(e) for e in caps[side]] for side in caps},
            'events':b.events,'arrow_log':logs,'dimers':matchings,
            'scope':'A specified framed effective parity model, not a microscopic chiral-parent identification.'}


def from_json(record: dict) -> Input:
    payload = record.get('input',record)
    def read(name):
        if name not in payload:
            raise ValueError(f'Missing field: {name}')
        return {tuple(map(int,key)):value for key,value in payload[name].items()}
    p = record.get('p',payload.get('p'))
    data = Input(p,read('n_integer'),read('n_majorana'),read('omega2'),read('s1'))
    data.validate()
    return data

from dataclasses import dataclass
@dataclass(frozen=True)
class Poly:
    terms:frozenset[int]
    @staticmethod
    def coerce(x):
        if isinstance(x,Poly):return x
        return Poly(frozenset((0,))) if int(x)%2 else Poly(frozenset())
    @staticmethod
    def var(i):return Poly(frozenset((1<<i,)))
    def __add__(self,x):return Poly(self.terms^self.coerce(x).terms)
    __radd__=__add__
    __xor__=__add__
    __rxor__=__add__
    __sub__=__add__
    __rsub__=__add__
    def __mul__(self,x):
        b=self.coerce(x).terms
        if not self.terms or not b:return Poly.coerce(0)
        if b==frozenset((0,)):return self
        if self.terms==frozenset((0,)):return Poly(b)
        out=set()
        for u in self.terms:
            for v in b:
                m=u|v
                if m in out:out.remove(m)
                else:out.add(m)
        return Poly(frozenset(out))
    __rmul__=__mul__
    def __mod__(self,n):
        if n!=2:raise ValueError('Only F_2 reduction is implemented')
        return self
    def __bool__(self):return bool(self.terms)
    def __eq__(self,x):return self.terms==self.coerce(x).terms
    def degree(self):return max((m.bit_count() for m in self.terms),default=-1)


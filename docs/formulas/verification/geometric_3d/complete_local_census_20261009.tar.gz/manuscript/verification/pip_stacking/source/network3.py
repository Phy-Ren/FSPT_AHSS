"""Exploratory doubled-boundary P comparison, with fixed positive-reference exchange walls.
No higher cups or source/product oracles are called here.
Input U,V are framed Majorana bits, N,K closed common-frame integers.
"""
from itertools import combinations
F=((1,2,3),(0,1,3),(0,2,3),(0,1,2))
def build(N,K,U,V,omega,s):
    """Construct a Gaussian sewing kernel's folded parity comparison.

    Upper/lower core words are physical input references; output core is the
    dual testing boundary, NOT a third pre-prepared physical input state.
    All exchange walls and every bridge are fixed before a target formula is read.
    """
    from itertools import combinations
    for d,q in ((N,1),(K,1),(U,2),(V,2),(omega,2),(s,1)):
        if set(d)!=set(combinations(range(4),q+1)):raise ValueError("Missing cochain faces")
    for f in combinations(range(4),3):
        if sum(s[e]for e in combinations(f,2))%2:raise ValueError("ds is nonzero")
        for d in (N,K):
            if d[f[1:]]-d[f[::2]]+d[f[:2]]:raise ValueError("Integer list balance fails")
    if sum(omega.values())%2:raise ValueError("domega is nonzero")
    W012=omega[0,1,2]^(s[0,1]*s[1,2])
    if (sum(U.values())+W012*N[2,3])%2 or (sum(V.values())+W012*K[2,3])%2:
        raise ValueError("The complete input core has odd endpoint number")
    t={0:0,1:s[0,1],2:s[0,2],3:s[0,3]}
    w={f:omega[f]^(s[f[:2]]*s[f[1:]]) for f in omega}
    if min(*N.values(),*K.values())<0:raise ValueError("nonnegative common-frame counts required")
    T={f:U[f]^V[f]^((N[f[:2]]*K[f[1:]])%2) for f in F}
    modes=[]; ids={}; res={}; arrays={}
    def new(kind,**data):
        i=len(modes);modes.append(dict(id=i,kind=kind,**data));return i
    for group,M in [('upper',U),('lower',V),('output',T)]:
        for j,f in enumerate(F):
            if M[f]: ids[group,f]=new('ordinary',group=group,face=list(f),side='B'if j<2 else 'A',
                                     metric=(int(j<2)^t[f[0]]))
        count=w[0,1,2]*(N[2,3]if group=='upper' else K[2,3]if group=='lower' else N[2,3]+K[2,3])
        res[group]=[new('residual',group=group,copy=j+1,metric=1)for j in range(count)]
    for f in F:
        arrays[f]=[[new('cross_exchange',face=list(f),row=i+1,column=j+1,wall_polarity=j%2)
                    for j in range(K[f[1:]])]for i in range(N[f[:2]])]
    initial=[]; core_lists=[]; core_logs=[]
    for group,M in [('upper',U),('lower',V),('output',T)]:
        seq=[ids[group,f]for f in F[:2]if M[f]]+res[group]+[ids[group,f]for f in F[2:]if M[f]]
        if len(seq)%2:raise ValueError(('odd core',group))
        core_lists.append({'group':group,'modes':list(seq)})
        for a,b in zip(seq[::2],seq[1::2]):
            reverse=group=='output' and (1^modes[a]['metric']^modes[b]['metric'])
            initial.append((b,a)if reverse else(a,b))
            core_logs.append({'group':group,'standard_pair':[a,b],
                              'dual_reversal':bool(reverse),'actual_pair':list(initial[-1])})
    routes=[[]for _ in range(3)]
    for i in range(N[1,2]):
        for j in range(K[2,3]):routes[0].append((arrays[1,2,3][i][j],arrays[0,2,3][i][j]))
    for i in range(N[0,1]):
        for j in range(K[2,3]):routes[1].append((arrays[0,1,3][i][j],arrays[0,2,3][N[1,2]+i][j]))
        for j in range(K[1,2]):routes[2].append((arrays[0,1,3][i][K[2,3]+j],arrays[0,1,2][i][j]))
    for r,edges in enumerate(routes):
        initial.extend(edges)
    final=[]; bridge_lists=[]; bridge_logs=[]
    for j,f in enumerate(F):
        seq=[ids[g,f] for g,M in [('upper',U),('lower',V)]if M[f]]
        seq += [i for row in arrays[f] for i in row]
        if T[f]:seq.append(ids['output',f])
        assert len(seq)%2==0
        bridge_lists.append({'face':list(f),'modes':list(seq)})
        for a,b in zip(seq[::2],seq[1::2]):
            def polarity(i):
                mode=modes[i]
                if mode['kind']=='cross_exchange':return mode['wall_polarity']
                return int(mode.get('side')=='B')
            flip=int(j<2)
            flip ^= t[f[0]]*(1^polarity(a)^polarity(b))
            final.append((b,a)if flip else(a,b))
            bridge_logs.append({'face':list(f),'unoriented_pair':[a,b],
                'geometric_B':j<2,'root_antiunitary':t[f[0]],
                'mode_polarities':[polarity(a),polarity(b)],
                'actual_pair':list(final[-1])})
    final.extend([(b,a) for a,b in zip(res['upper']+res['lower'],res['output'])])
    assert sorted(x for e in initial for x in e)==list(range(len(modes)))
    assert sorted(x for e in final for x in e)==list(range(len(modes)))
    return dict(
                comparison_semantics="Folded Gaussian-kernel grading; output is a dual testing boundary.",
                cross_wall_reference="positive-to-negative first, alternating in each row",
                core_lists=core_lists,core_arrow_log=core_logs,
                bridge_lists=bridge_lists,bridge_arrow_log=bridge_logs,
                cross_arrays={''.join(map(str,f)):r for f,r in arrays.items()},
                residual_identity_lists=res,cross_reference_routes=routes,
                modes=modes,dimers={'in':initial,'out':final},mode_count=len(modes),
                output_chain={''.join(map(str,f)):v for f,v in T.items()})

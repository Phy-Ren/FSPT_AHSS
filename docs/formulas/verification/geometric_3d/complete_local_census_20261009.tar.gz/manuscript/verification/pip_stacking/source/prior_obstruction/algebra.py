"""Manuscript cochains, kept separate from the signed dimer network.

These routines also accept Boolean-polynomial entries for an exact symbolic
certificate. All products and sums here have coefficients in F_2.
"""
from itertools import combinations
from .cup import cup,op,dc,wordop

def plus(*cochains):
    return {k:sum(c[k] for c in cochains)%2 for k in cochains[0]}

def bits(N):
    return {f:v%2 for f,v in N.items()},{f:(v//2)%2 for f,v in N.items()}

def ingredients(a,h,M,W,S,p):
    nv=p+4
    b=op(a,p,a,p,p-1,nv)
    w=plus(W,op(S,1,S,1,0,nv))
    m=plus(M,op(S,1,h,p,0,nv))
    dm=dc(m,p+1,nv)
    beta=op(w,2,w,2,1,nv)
    A=op(a,p,a,p,p-2,nv) if p==2 else {f:0 for f in combinations(range(nv),p+3)}
    B=op(w,2,a,p,0,nv)
    return b,w,m,dm,beta,A,B

def manuscript_bits(a,h,M,W,S,p):
    """Equations (145)-(151) of the supplied latest manuscript."""
    nv=p+4
    b,w,m,dm,beta,A,B=ingredients(a,h,M,W,S,p)
    s1m=plus(op(m,p+1,m,p+1,p,nv),op(m,p+1,dm,p+2,p+1,nv))
    ordinary=cup(m,p+1,m,p+1,p-1)^cup(m,p+1,dm,p+2,p)^cup(W,2,m,p+1)^cup(S,1,s1m,p+2)
    za=a[0,1,2]*a[0,2,3]*a[2,3,5]*a[3,4,5] if p==2 else 0
    zw=(w[0,1,2]*w[0,2,3]*a[2,3,5]*a[3,4,5] if p==2 else w[0,1,2]*w[0,2,3]*a[2,3]*a[3,4])
    beta_s=op(beta,3,S,1,1,nv)
    ssw=op(S,1,op(S,1,w,2,1,nv),2,0,nv)
    pure=za^zw^cup(plus(beta,op(S,1,w,2,0,nv)),3,h,p)^cup(plus(beta_s,ssw),3,a,p)
    if p==2:
        sa=op(S,1,a,2,0,nv)
        parts=[op(A,4,B,4,4,nv),op(op(a,2,S,1,1,nv),2,a,2,0,nv),op(a,2,b,3,1,nv),A]
        pure^=cup(A,4,B,4,3)^cup(h,2,dc(h,2,nv),3)^cup(b,3,sa,3,1)^cup(S,1,plus(*parts),4)
    return ordinary^pure

def counted_bits(a,h,M,W,S,p):
    """Analytic output of the network lemmas; not called by network assembly.

This is intentionally written as the independent shuffle, cap, colour, and
local-arrow counts, rather than as a copy of the manuscript expression.
"""
    nv=p+4
    b,w,m,dm,beta,A,B=ingredients(a,h,M,W,S,p)
    bare=cup(m,p+1,m,p+1,p-1)^cup(m,p+1,dm,p+2,p)
    bare^=cup(W,2,m,p+1)
    # Ordinary modes in the single nonstandard cell.
    bare^=cup(S,1,plus(op(m,p+1,m,p+1,p,nv),op(m,p+1,dm,p+2,p+1,nv)),p+2)
    # Binary-reflection transport: ordered packet swap and column caps.
    folded_h=h[tuple(range(3,nv))]^S[0,3]*a[tuple(range(3,nv))]
    z=(w[0,1,2]*w[0,2,3]*a[2,3,5]*a[3,4,5] if p==2 else w[0,1,2]*w[0,2,3]*a[2,3]*a[3,4])
    right=tuple(range(3,nv))
    packet=z^beta[0,1,2,3]*folded_h
    packet^=S[0,1]*w[1,2,3]*(folded_h^a[right])
    if p==2:
        packet^=a[0,1,2]*a[0,2,3]*a[2,3,5]*a[3,4,5]
        packet^=h[0,1,2]*b[2,3,4,5]
        packet^=cup(A,4,B,4,3)
        packet^=S[0,1]*A[1,2,3,4,5]*B[1,2,3,4,5]
        # B,A,B,A,... wall polarity in each intrinsic row.
        packet^=S[0,1]*h[1,2,3]*a[3,4,5]
    return bare^packet

def B4_bits(a,h,S):
    """Explicit natural four-cochain relating the two 4+1D representatives."""
    b=op(a,2,a,2,1,5)
    return (cup(op(h,2,S,1,1,5),2,a,2)
            ^cup(S,1,op(b,3,a,2,2,5),3)
            ^wordop((b,S,a),(3,1,2),(1,2,1,3,1),tuple(range(5))))

def restrict(c,vertices):
    vs=set(vertices)
    return {tuple(vertices.index(i) for i in f):v for f,v in c.items() if set(f)<=vs}

def dB4_bits(a,h,S):
    return sum(B4_bits(restrict(a,f),restrict(h,f),restrict(S,f)) for f in combinations(range(6),5))%2

def manuscript(N,M,W,S,p):return manuscript_bits(*bits(N),M,W,S,p)
def counted(N,M,W,S,p):return counted_bits(*bits(N),M,W,S,p)
def boundary(N,S,p):return dB4_bits(*bits(N),S) if p==2 else 0

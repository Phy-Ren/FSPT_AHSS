"""Unreduced gamma/psi network with explicit reset-chain endpoints.

Unlike model.py (the reduced reference), this constructor keeps the independent
ordinary decoration and every chosen reset channel separate. It never calls the
reduced constructor or an O4/O5 formula. Reuses only the previously specified
residual point-mode routing and input validation.

Reset rule: for N>=0 reverse N copies, giving floor(N/2) negative eigenchannels;
for N<0 the explicitly specified inverse reference is minus the reversal of |N|
copies, giving ceil(|N|/2) channels. Each finite negative-mass interval contributes
TWO ends. Same-face even conversion rules are fully visible in the output.
"""
from __future__ import annotations
from itertools import combinations
from .model import Input, Builder, face, IN3, OUT3, IN4, OUT4


def common_frame(data: Input, extra_padding: int = 0):
    if type(extra_padding) is not int or extra_padding < 0:
        raise ValueError('extra_padding must be a nonnegative integer')
    t = {0:0, **{i:data.s[0,i] for i in range(1,data.p+4)}}
    n_at_0 = {f:(-1)**t[f[0]]*n for f,n in data.N.items()}
    positive_cocycle = {f:f[1]-f[0] if data.p==1 else 1 for f in n_at_0}
    pad = max([0]+[max(0,(-n+4*positive_cocycle[f]-1)//(4*positive_cocycle[f]))
                       for f,n in n_at_0.items()])+extra_padding
    lengths = {f:n+4*pad*positive_cocycle[f] for f,n in n_at_0.items()}
    omega_prime = {f:data.omega[f]^(data.s[f[:2]]*data.s[f[1:]]) for f in data.omega}
    # Number of reset channels, not the number of endpoints and NOT reduced mod 2.
    reset_channels = {f:data.s[f[:2]]*abs(data.N[f[1:]]//2) for f in data.M}
    return n_at_0,lengths,omega_prime,reset_channels,t,pad


def build_split(data: Input, *, extra_padding: int = 0) -> dict:
    data.validate()
    n_at_0,lengths,omega_prime,reset_count,t,padding=common_frame(data,extra_padding)
    b=Builder(data)
    caps={'in':[],'out':[]}
    if data.p==1:
        orders={'in':IN3,'out':OUT3}
        projective=b.route_3d(lengths,omega_prime,caps)
        intrinsic={s:{c:[] for c in orders[s]} for s in orders}
    else:
        orders={'in':IN4,'out':OUT4}
        intrinsic=b.route_4d(lengths,lengths,'intrinsic',caps)
        projective=b.route_4d(omega_prime,lengths,'projective',caps)
    ordinary_count=2*len(b.ordinary_faces)
    # Keep all pre-existing IDs, including the exterior reference, unchanged.
    exterior=b.new_mode('exterior_reference') if len(b.modes)%2 else None
    residual_dimension=len(b.modes)
    reset={}
    for f in b.ordinary_faces:
        reset[f]=[]
        native=data.N[f[1:]]
        for j in range(reset_count[f]):
            pair=[]
            for end in ('A','B'):
                # These are geometric endpoints of a FINITE interval.
                # Their wall polarities are t(face_root) and 1+t(face_root),
                # which is why their transported laws are ordinary A/B laws.
                pair.append(b.new_mode('reset_effective',face=list(f),channel=j+1,
                                      geometric_end=end,local_species_vertex=f[0],
                                      raw_wall_polarity=t[f[0]]^(end=='B'),
                                      native_sheet_value=native))
            reset[f].append(pair)
    records={s:[] for s in ('in','out')}
    placements={s:[] for s in ('in','out')}
    lists={s:[] for s in ('in','out')}
    logs={s:[] for s in ('in','out')}
    reset_rules={s:[] for s in ('in','out')}
    signed_conversions={s:[] for s in ('in','out')}
    for side in ('in','out'):
        edges=records[side]
        incidence={f:[] for f in b.ordinary_faces}
        for c in orders[side]:
            for j in range(len(c)):
                incidence[face(c,j)].append(j)

        def active_end(f,end):
            """Physical survivor after same-face pairwise cancellations.

            The original gamma exists only according to the original n_majorana.
            An odd reset list is NOT silently renamed gamma.
            """
            if reset_count[f]%2:
                if data.M[f]:return None
                return reset[f][-1][end]
            return b.ids[f]+end if data.M[f] else None

        for c in orders[side]:
            seq=[];pol={};special=None
            for j in range(0,len(c),2):
                f=face(c,j);mode=active_end(f,1)
                if mode is not None:
                    seq.append(mode);pol[mode]=1
                    placements[side].append({'id':mode,'cell':list(c),'face':list(f),
                       'geometric_end':'B','source':b.modes[mode]['kind'],'end_transport_bit':1})
                    if j==0:special=mode
            for kind,packet in (('intrinsic',intrinsic[side][c]),('projective',projective[side][c])):
                width=lengths[c[2:]]
                for j,mode in enumerate(packet):
                    row,column=divmod(j,width)
                    k=(column+1)%2 if kind=='intrinsic' else 1
                    seq.append(mode);pol[mode]=k
                    placements[side].append({'id':mode,'cell':list(c),'source':kind,
                        'row':row+1,'column':column+1,'wall_polarity':k})
            for j in range(1,len(c),2):
                f=face(c,j);mode=active_end(f,0)
                if mode is not None:
                    seq.append(mode);pol[mode]=0
                    placements[side].append({'id':mode,'cell':list(c),'face':list(f),
                        'geometric_end':'A','source':b.modes[mode]['kind'],'end_transport_bit':0})
            if len(seq)%2:raise ValueError(f'Odd complete core at {c}')
            lists[side].append({'cell':list(c),'modes':seq})
            for u,v in zip(seq[::2],seq[1::2]):
                wo=st=0
                if c[0]==1:
                    wo=data.omega[0,1,2]*int(special in (u,v))
                    st=data.s[0,1]*(1^pol[u]^pol[v])
                ed=[v,u] if wo^st else [u,v]
                edges.append(ed)
                logs[side].append({'cell':list(c),'standard_dimer':[u,v],
                                  'omega_flip':wo,'antiunitary_flip':st,'actual_dimer':ed})
        edges.extend([list(e) for e in caps[side]])
        # (virtual ordered slot, actual ID): exterior order is geometric slot order,
        # never the allocation order of newly appended psi IDs.
        exterior_slots=[]
        for f,js in incidence.items():
            ga=b.ids[f];gb=ga+1;pairs=reset[f]
            def addq(u,v):edges.append([v,u] if t[f[0]] else [u,v])
            if not js:
                edges.append([ga,gb]);edges.extend([list(e) for e in pairs])
                reset_rules[side].append({'face':list(f),'rule':'absent_face_reference',
                                         'channel_count':len(pairs)})
                continue
            # Cancel consecutive pairs of FULL channels. The B-end arrow is reversed.
            pair_limit=len(pairs)-(len(pairs)%2)
            for j in range(0,pair_limit,2):
                a,b0=pairs[j];aa,bb=pairs[j+1]
                addq(a,aa);addq(bb,b0)
                # Image on operators: first B -> q*second A;
                # second A -> -q*first B. Determinant +1.
                signed_conversions[side].append({'face':list(f),'type':'two_channel_rotation',
                    'modes':[b0,aa],'quarter_turn_sign':(-1)**t[f[0]],'determinant':1})
            if len(pairs)%2:
                pa,pb=pairs[-1]
                if data.M[f]:
                    addq(ga,pa);addq(pb,gb)
                    rule='gamma_plus_reset_cancel'
                    signed_conversions[side].append({'face':list(f),'type':'gamma_reset_rotation',
                        'modes':[gb,pa],'quarter_turn_sign':(-1)**t[f[0]],'determinant':1})
                else:
                    edges.append([ga,gb])
                    rule='reset_survives_as_psi'
                    signed_conversions[side].append({'face':list(f),'type':'two_endpoint_transfer',
                        'pairs':[[ga,pa],[gb,pb]],'determinant':1})
            else:
                rule='gamma_survives' if data.M[f] else 'both_inactive'
                if not data.M[f]:edges.append([ga,gb])
            reset_rules[side].append({'face':list(f),'rule':rule,'channel_count':len(pairs),
                                     'native_gamma_bit':data.M[f],'root_antiunitary':t[f[0]]})
            if len(js)==1:
                end=js[0]%2  # opposite end to the cell incidence
                mode=active_end(f,end)
                if mode is not None:exterior_slots.append((ga+end,mode))
            elif len(js)!=2 or js[0]%2==js[1]%2:
                raise ValueError('Inconsistent oriented incidence')
        if exterior is not None:exterior_slots.append((exterior,exterior))
        exterior_slots.sort()
        exterior_ids=[mode for _,mode in exterior_slots]
        if len(exterior_ids)%2:raise ValueError('Odd exterior completion')
        edges.extend([[u,v] for u,v in zip(exterior_ids[::2],exterior_ids[1::2])])
        flat=[v for e in edges for v in e]
        if sorted(flat)!=list(range(len(b.modes))):
            from collections import Counter
            raise ValueError(('Not a perfect matching',side,[i for i,n in Counter(flat).items() if n!=1],
                              sorted(set(range(len(b.modes)))-set(flat))))
    def ser(c):return {''.join(map(str,f)):v for f,v in sorted(c.items())}
    return {'schema':'separate-gamma-psi-v4','p':data.p,'spatial_dimension':data.p+2,
            'input':{'n_integer':ser(data.N),'n_majorana':ser(data.M),
                     'omega2':ser(data.omega),'s1':ser(data.s)},
            'frames':{'n_at_vertex_0':ser(n_at_0),'residual_point_realization_lengths':ser(lengths),
                      'omega2_prime':ser(omega_prime),'common_padding':padding},
            'reset_channel_counts':ser(reset_count),'mode_count':len(b.modes),
            'ordinary_mode_count':ordinary_count,'residual_reference_dimension':residual_dimension,
            'reset_endpoint_ids':{''.join(map(str,f)):p for f,p in reset.items()},
            'modes':b.modes,'dimers':records,'placements':placements,'local_lists':lists,
            'arrow_log':logs,'reset_rules':reset_rules,'even_conversion_gates':signed_conversions,
            'reference_caps':{s:[list(e) for e in caps[s]] for s in caps},'events':b.events,
            'scope':'Explicit separate gamma/psi effective model; local even-conversion theorem applies. '
                    'Residual point-mode transport and signed chiral-parent realization remain fixed model input.'}

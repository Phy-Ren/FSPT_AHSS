"""Unchanged previous obstruction network (imports localized)."""

"""Representative changes; kept out of the physical graph constructor."""
from itertools import combinations
from cup import cup,op,dc
def A2(f,a,h,b,k,m,v,s):
    i,j,l=f
    t=a[i,j]*b[j,l]
    return (a[i,j]*k[j,l]+h[i,j]*b[j,l]+h[i,j]*k[j,l]+m[f]*v[f]
            +t*(m[f]+v[f])
            +s[i,j]*(h[i,j]*b[j,l]+a[i,j]*b[i,j]*(a[j,l]+b[j,l])))%2
def dA2(a,h,b,k,m,v,s):
    return sum(A2(f,a,h,b,k,m,v,s)for f in combinations(range(4),3))%2
def C3(a,h,m,omega,s,nv=4):
    """An explicit closed single-state cochain, NOT a general pair cocycle.
       C = s cup m + m cup a + W cup h + (s cup_1 W) cup a."""
    W={f:(omega[f]+s[f[:2]]*s[f[1:]])%2 for f in omega}
    z=op(s,1,W,2,1,nv)
    return {f:(cup(s,1,m,2,0,f)+cup(m,2,a,1,0,f)+cup(W,2,h,1,0,f)+cup(z,2,a,1,0,f))%2
            for f in combinations(range(nv),4)}

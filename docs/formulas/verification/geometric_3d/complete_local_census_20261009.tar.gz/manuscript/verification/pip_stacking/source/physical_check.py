"""Compare the P-kernel grading with ACTUAL prior F-network parity counts."""
from itertools import combinations
from data3 import prepare,output,restrict
from unfold3 import build
from kasteleyn import loops,word_parity
from prior_obstruction.model import Input
from prior_obstruction.split_model import build_split
from reference3 import target
from gauge import dA2

def P(data,trace=True):
    inputs,math,padding=prepare(data)
    rec=build(*inputs)
    r=loops(rec['dimers']['in'],rec['dimers']['out'],rec['mode_count'])
    assert r['parity_change']==word_parity(rec['dimers']['in'])^word_parity(rec['dimers']['out'])
    rec['count']=r;rec['padding']=list(padding)
    if not trace:
        return r['parity_change']
    from rotations import repair_and_compile
    from reset_tracks import inventory
    from face_cleanup import build as cleanup
    rec['core_unitary']=repair_and_compile(rec)
    rec['reset_operations']=inventory(data)
    n,k,m,v,omega,s=inputs
    rec['face_cleanup_operations']={}
    for f in m:
        cols=list(range(1,k[f[1:]]+1))*n[f[:2]]
        mod=cleanup(m[f],v[f],cols,0 if f[0]==0 else s[0,f[0]])
        face=''.join(map(str,f))
        mod['named_mode_binding']={}
        for ch in mod['channels']:
            if ch['kind']=='upper_gamma':stem='gamma:upper:'+face
            elif ch['kind']=='lower_gamma':stem='gamma:lower:'+face
            else:
                row=(ch['index']-1)//k[f[1:]]+1
                stem='psi:exchange:'+face+':'+str(row)+','+str(ch['column'])
            for side,i in zip(('A','B'),ch['ids']):mod['named_mode_binding'][str(i)]=stem+':'+side
        mod['named_quarter_turn_gates']=[[mod['named_mode_binding'][str(a)],mod['named_mode_binding'][str(b)],q]for a,b,q in mod['quarter_turn_gates']]
        rec['face_cleanup_operations'][face]=mod
    for family,mods in rec['reset_operations'].items():
        for face,mod in mods.items():
            carrier='lower'if family=='lower_input'else'upper'
            binding={'0':'gamma:'+carrier+':'+face+':A','1':'gamma:'+carrier+':'+face+':B'}
            for j,(a,b)in enumerate(mod['reset_ids'],1):
                binding[str(a)]='psi:reset:'+family+':'+face+':'+str(j)+':A'
                binding[str(b)]='psi:reset:'+family+':'+face+':'+str(j)+':B'
            mod['named_mode_binding']=binding
            mod['named_reduced_to_separate_gates']=[[binding[str(a)],binding[str(b)],q]for a,b,q in mod['reduced_to_separate_gates']]
            mod['named_separate_to_reduced_gates']=[[binding[str(a)],binding[str(b)],q]for a,b,q in mod['separate_to_reduced_gates']]
    for mode in rec['modes']:
        if mode['kind']=='ordinary':name='gamma:'+mode['group']+':'+''.join(map(str,mode['face']))+':'+mode['side']
        elif mode['kind']=='cross_exchange':name='psi:exchange:'+''.join(map(str,mode['face']))+':'+str(mode['row'])+','+str(mode['column'])+':'+mode['side']
        else:name='psi:residual:'+mode['group']+':0123:'+str(mode['copy'])
        mode['global_name']=name
    rec['core_unitary']['named_gates']=[]
    naming={mode['id']:mode['global_name']for mode in rec['modes']}
    naming[rec['mode_count']]='c:upper:0123:A';naming[rec['mode_count']+1]='c:upper:0123:B'
    for a,b,q in rec['core_unitary']['gates']:rec['core_unitary']['named_gates'].append([naming[a],naming[b],q])
    rec['reference_comparison']={'repository_E3':target(*math),
                                 'pair_coboundary':dA2(*math[:6],math[7])}
    rec['reference_comparison']['residual']=r['parity_change']^rec['reference_comparison']['repository_E3']^rec['reference_comparison']['pair_coboundary']
    return rec if trace else r['parity_change']

def F(n,m,omega,s,trace=False):
    rec=build_split(Input(1,n,m,omega,s))
    r=loops(rec['dimers']['in'],rec['dimers']['out'],rec['mode_count'])
    assert r['parity_change']==word_parity(rec['dimers']['in'])^word_parity(rec['dimers']['out'])
    return (r['parity_change'],rec) if trace else r['parity_change']

def compatibility(data,trace=False):
    N,M=output(data)
    values=[F(N,M,data['omega2'],data['s1']),
            F(data['n1'],data['n2'],data['omega2'],data['s1']),
            F(data['n1prime'],data['n2prime'],data['omega2'],data['s1'])]
    E=[]
    for f in combinations(range(5),4):
        local={k:restrict(d,f)for k,d in data.items()}
        E.append(P(local,trace=False))
    return {'five_P_counts':E,'three_physical_F_counts':values,
            'dE3':sum(E)%2,'Delta_O4_phys':sum(values)%2,
            'defect':(sum(E)+sum(values))%2}

"""The previously proved reset conversion, now as explicit two-ended modules.
Gamma and psi IDs remain distinct throughout. Output modules are used backwards
only after upper output ordinary ports exist; their references are empty pairs.
"""
from rotations import rotate_edges
from kasteleyn import loops

def module(native_bit,channel_count,antiunitary_species):
    if native_bit not in (0,1) or channel_count<0 or antiunitary_species not in (0,1):raise ValueError('Invalid reset module')
    t=antiunitary_species;r=channel_count;q=(-1)**t;active=native_bit^(r%2)
    gamma=(0,1);tracks=[(2+2*j,3+2*j)for j in range(r)]
    n=2+2*r
    reduced=[gamma]if not active else[(0,n),(1,n+1)]
    reduced+=tracks
    gates=[]
    for j in range(0,r-r%2,2):gates.append([tracks[j][1],tracks[j+1][0],q])
    if r%2:
        a,b=tracks[-1]
        if native_bit:gates.append([1,a,q])
        else:gates.extend([[0,a,1],[1,b,1]])
    actual=list(reduced)
    for u,v,sgn in gates:actual=rotate_edges(actual,u,v,sgn)
    # Complete explicit target, independent of gate replay.
    target=[]
    for j in range(0,r-r%2,2):
        a,b=tracks[j];aa,bb=tracks[j+1]
        target += [(a,aa)if q==1 else(aa,a),(bb,b)if q==1 else(b,bb)]
    if r%2:
        a,b=tracks[-1]
        if native_bit:target +=[(0,a)if q==1 else(a,0),(b,1)if q==1 else(1,b)]
        else:target +=[(0,1),(a,n),(b,n+1)]
    else:target +=[(0,n),(1,n+1)]if native_bit else[(0,1)]
    if set(actual)!=set(target):raise AssertionError(('reset arrow mismatch',native_bit,r,t,actual,target))
    c=loops(reduced,target,n+2*active)
    if c['parity_change']:raise AssertionError('Reset conversion must be even')
    return dict(native_bit=native_bit,channel_count=r,root_antiunitary=t,
                reduced_bit=active,ordinary_ids=gamma,reset_ids=tracks,
                external_partner_ids=[n,n+1]if active else[],
                reduced_state=reduced,separate_state=target,
                reduced_to_separate_gates=gates,
                separate_to_reduced_gates=[[u,v,-s]for u,v,s in reversed(gates)],
                parity_change=0,mode_count=n+2*active)

def inventory(data):
    """Face-local circuits to apply BEFORE and AFTER the chronological core P."""
    from data3 import output
    N,M=output(data);s=data['s1']
    t={0:0,1:s[0,1],2:s[0,2],3:s[0,3]}
    result={}
    for name,n,bits in [('upper_input',data['n1'],data['n2']),('lower_input',data['n1prime'],data['n2prime']),('upper_output',N,M)]:
        result[name]={''.join(map(str,f)):module(bits[f],s[f[:2]]*abs(n[f[1:]]//2),t[f[0]])for f in bits}
    return result

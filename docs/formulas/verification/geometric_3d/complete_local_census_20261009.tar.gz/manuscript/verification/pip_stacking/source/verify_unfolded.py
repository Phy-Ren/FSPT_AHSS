#!/usr/bin/env python3
"""Independent new checks of chronological graphs, physical unitary gates,
shared-face gluing and lower-vacuum cleanup. The old kernel is a comparator only.
"""
import argparse,json,time
from pathlib import Path
from itertools import product
from data3 import generate,prepare
from unfold3 import build
from network3 import build as old_kernel
from kasteleyn import loops,word_parity,matrix,pfaffian_sign
from rotations import repair_and_compile,rotate_edges
from face_cleanup import build as clean
from reset_tracks import module
from physical_check import compatibility
from reference3 import target
from gauge import dA2
ROOT=Path(__file__).resolve().parents[1]
def run(full=False):
 start=time.monotonic();counts=dict(chronological_tetrahedra=0,actual_core_circuits=0,
                  shared_face_cleanups=0,reset_channel_modules=0,physical_FP_checks=0,matrix_pfaffians=0)
 local=256 if full else 24;five=128 if full else 6
 for bg in ('zero','w','s','both'):
  for seed in range(local):
   raw,math,pads=prepare(generate(4,bg,70000+seed));r=build(*raw);old=old_kernel(*raw)
   E=r['count']['parity_change']
   assert E==loops(old['dimers']['in'],old['dimers']['out'],old['mode_count'])['parity_change']
   assert E==target(*math)^dA2(*math[:6],math[7])
   assert not any(m.get('group')=='output' for m in r['modes'])
   counts['chronological_tetrahedra']+=1
   circuit=repair_and_compile(r,seed%2);current=circuit['start']
   for a,b,q in circuit['gates']:current=rotate_edges(current,a,b,q)
   assert set(current)==set(circuit['end']);counts['actual_core_circuits']+=1
   if seed<3 and r['mode_count']:
    pi=pfaffian_sign(matrix(r['dimers']['in']));po=pfaffian_sign(matrix(r['dimers']['out']))
    assert pi*po==(-1)**E;counts['matrix_pfaffians']+=2
  for seed in range(five):
   c=compatibility(generate(5,bg,20000+seed));assert c['defect']==0;counts['physical_FP_checks']+=1
 for rows in range(9):
  for width in range(9):
   for u,v,t in product(range(2),repeat=3):
    r=clean(u,v,list(range(1,width+1))*rows,t)
    assert r['count']['parity_change']==0
    assert [2,3]in r['dimers']['out'] or (2,3)in r['dimers']['out']
    counts['shared_face_cleanups']+=1
 for m,r,t in product(range(2),range(16),range(2)):
  module(m,r,t);counts['reset_channel_modules']+=1
 # Negative controls: deleting output survivor signs or using + raw cross vacuum
 # in antiunitary species is NOT passed as a harmless gauge change.
 neg=clean(0,0,[1,2],1)
 wrong=list(neg['dimers']['out']);e=wrong[2];wrong[2]=(e[1],e[0])
 assert loops(neg['dimers']['in'],wrong)['parity_change']==1
 # Explicit empty-upper transfer from lower with external bonds retained.
 simple=clean(0,1,[],1)
 assert simple['actual_survivor_channel']==1 and simple['count']['parity_change']==0
 return dict(scope='Chronological stabilized effective P move; no output test systems.',mode='full'if full else'quick',
             **counts,P_graphs_in_FP_checks=5*counts['physical_FP_checks'],
             unreduced_F_graphs=3*counts['physical_FP_checks'],mismatches=0,
             negative_controls_passed=True,seconds=round(time.monotonic()-start,3))
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--full',action='store_true');a=ap.parse_args()
 out=run(a.full);(ROOT/'results'/('unfolded_full.json'if a.full else'unfolded_quick.json')).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))

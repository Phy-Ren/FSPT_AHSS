"""Exact even Gaussian operations on signed Majorana matchings.
A gate (u,v,q) sends u -> q v and v -> -q u.  It is
exp(-q*pi*chi_u*chi_v/4), so every gate is parity even and unitary.
No obstruction or stacking formula is used.
"""
def rotate_edges(edges,u,v,q=1):
    if u==v or q not in (-1,1):raise ValueError('Invalid quarter turn')
    def image(i):
        if i==u:return v,q
        if i==v:return u,-q
        return i,1
    out=[]
    for a,b in edges:
        aa,sa=image(a);bb,sb=image(b)
        out.append((aa,bb)if sa*sb==1 else(bb,aa))
    return out

def compile_even(start,target):
    """Map each ordered start dimer to the corresponding ordered target dimer.
    Returns a deterministic sequence of quarter turns; raises on opposite parity.
    Normalization is exactly one, not a postselected projection amplitude.
    """
    from kasteleyn import word_parity
    n=2*len(start)
    if len(target)!=len(start) or sorted(x for e in start for x in e)!=list(range(n)) or sorted(x for e in target for x in e)!=list(range(n)):
        raise ValueError('Need complete matchings on the same IDs')
    if word_parity(start)!=word_parity(target):raise ValueError('An even circuit cannot change total parity')
    desired=[None]*n
    for (a,b),(c,d) in zip(start,target):desired[a]=c;desired[b]=d
    dest=list(range(n));sign=[1]*n;gates=[]
    def step(u,v,q):
        for k in range(n):
            if dest[k]==u:dest[k]=v;sign[k]*=q
            elif dest[k]==v:dest[k]=u;sign[k]*=-q
        gates.append([u,v,q])
    for k in range(n-1):
        u=dest[k];v=desired[k]
        if u!=v:step(u,v,sign[k])
        if sign[k]!=1:
            partner=dest[n-1]
            step(v,partner,1);step(v,partner,1)
    if dest!=desired or sign!=[1]*n:raise AssertionError('SO compilation failed')
    current=list(map(tuple,start))
    for u,v,q in gates:current=rotate_edges(current,u,v,q)
    if set(current)!=set(map(tuple,target)):raise AssertionError('Gate replay failed')
    return gates

def repair_and_compile(record,occupation=0):
    """Keep the actual upper point fermion; change its occupation by counted parity.
    The local c,c' preprocessing first leaves occupation n3+n3' on this carrier.
    """
    n=record['mode_count'];parity=record['count']['parity_change']
    cin=(n,n+1)if occupation==0 else(n+1,n)
    cout=(n,n+1)if occupation^parity==0 else(n+1,n)
    start=list(map(tuple,record['dimers']['in']))+[cin]
    end=list(map(tuple,record['dimers']['out']))+[cout]
    gates=compile_even(start,end)
    return {'point_fermion_modes':[n,n+1], 'initial_point_occupation':occupation,
            'final_point_occupation':occupation^parity,'gates':gates,
            'start':start,'end':end,'total_mode_count':n+2,
            'total_parity_preserved':True}

def cancel_pair(kx,ky,t):
    """Both geometric ends of two parked channels; input is endpoint bridges.
    kx,ky are [A,B] transport bits: ordinary=[0,1], exchange=[beta-1,beta-1].
    Raw cross-channel reference is -i psi_A psi_B=(-1)^t, never silently +1.
    IDs xA,xB,yA,yB are 0,1,2,3.
    """
    qx=(-1)**(t*(1^kx[0]^kx[1]));qy=(-1)**(t*(1^ky[0]^ky[1]))
    a=(-1)**(t*(1^kx[0]^ky[0]));b=(-1)**(t*(1^kx[1]^ky[1]))
    bridges=[(0,2)if a==1 else(2,0),(3,1)if b==1 else(1,3)]
    vacuum=[(0,1)if qx==1 else(1,0),(2,3)if qy==1 else(3,2)]
    # references -> bridges: xB -> a*qx*yA; yA -> -a*qx*xB.
    q=a*qx
    if set(rotate_edges(vacuum,1,2,q))!=set(bridges):raise AssertionError('Cap identity')
    return dict(raw_reference_signs=[qx,qy],bridge_signs=[a,b],dimers={'in':bridges,'out':vacuum},
                cleanup_gate=[1,2,-q])

def transfer_survivor(k,t,partner_signs=(1,1)):
    """An active channel at IDs2,3 and an empty upper carrier0,1.
    External partners4,5 show that bonds really move, rather than disappear.
    Normalized output field is theta_C psi_C, theta_C=(-1)^{t(k_C+C)}.
    """
    theta=[(-1)**(t*k[0]),(-1)**(t*(k[1]^1))]
    rawq=(-1)**(t*(1^k[0]^k[1]))
    a,b=partner_signs
    before=[(0,1),(2,4)if a==1 else(4,2),(3,5)if b==1 else(5,3)]
    # Old active -> theta * upper; upper -> -theta * old active.
    gates=[[2,0,theta[0]],[3,1,theta[1]]]
    after=before
    for u,v,q in gates:after=rotate_edges(after,u,v,q)
    target=[(2,3)if rawq==1 else(3,2),
            (0,4)if a*theta[0]==1 else(4,0),(1,5)if b*theta[1]==1 else(5,1)]
    if set(after)!=set(target):raise AssertionError('Survivor transfer')
    return dict(theta=theta,raw_reference_sign=rawq,dimers={'in':before,'out':target},gates=gates)

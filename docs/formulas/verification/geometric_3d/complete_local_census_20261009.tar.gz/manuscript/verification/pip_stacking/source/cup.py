from itertools import combinations,combinations_with_replacement
from functools import lru_cache
@lru_cache(None)
def faces(p,q,k):
    d=p+q-k
    if k<0 or d<0:return ()
    word=[j%2 for j in range(k+2)]
    ans=[]
    for cuts in combinations_with_replacement(range(d+1),k+1):
        ends=(0,)+cuts+(d,)
        L=[[],[]]
        for j,c in enumerate(word):L[c]+=list(range(ends[j],ends[j+1]+1))
        if all(len(l)==deg+1 and all(x<y for x,y in zip(l,l[1:])) for l,deg in zip(L,(p,q))):ans.append(tuple(map(tuple,L)))
    return tuple(ans)
def cup(a,p,b,q,k=0,v=None):
    if v is None:v=tuple(range(p+q-k+1))
    return sum(a[tuple(v[j] for j in l)]*b[tuple(v[j] for j in r)] for l,r in faces(p,q,k))%2
def op(a,p,b,q,k=0,nv=6):
    return {v:cup(a,p,b,q,k,v) for v in combinations(range(nv),p+q-k+1)}
def dc(a,p,nv=6,mod=2,s=None):
    return {v:sum(((-1)**s[(v[0],v[1])] if j==0 and s is not None else (-1)**j)*a[v[:j]+v[j+1:]] for j in range(p+2))%mod for v in combinations(range(nv),p+2)}
if __name__=='__main__':
 print('4cup3 4:',faces(4,4,3))
@lru_cache(None)
def wordfaces(degrees,word):
    d=sum(degrees)-len(word)+len(degrees)
    if d<0:return ()
    ans=[]
    for cuts in combinations_with_replacement(range(d+1),len(word)-1):
        ends=(0,)+cuts+(d,);L=[[] for _ in degrees]
        for j,c in enumerate(word):L[c-1]+=list(range(ends[j],ends[j+1]+1))
        if all(len(l)==deg+1 and all(x<y for x,y in zip(l,l[1:])) for l,deg in zip(L,degrees)):ans.append(tuple(map(tuple,L)))
    return tuple(ans)
def wordop(cochains,degrees,word,v):
    ans=0
    for fs in wordfaces(tuple(degrees),tuple(word)):
        value=1
        for c,l in zip(cochains,fs):value*=c[tuple(v[j] for j in l)]
        ans^=value
    return ans

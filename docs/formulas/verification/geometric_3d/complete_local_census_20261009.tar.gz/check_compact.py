"""Private candidate: compact E3 after restoring legacy pure-gamma arrows."""
from audit_references import *
from certify import free
from reference3 import plus
from cup import cup,op,dc
from graph_count import counted
from binary_poly import Poly
from prior_obstruction.algebra import manuscript_bits


def compact(a,h,b,hp,m,v,w,s):
    e=op(a,1,b,1,0,4)
    ordinary=cup(m,2,v,2,1)+cup(s,1,op(m,2,v,2,2,4),2)
    mixed=cup(m,2,dc(v,2,4),3,2)+cup(plus(m,v),2,e,2,1)+cup(s,1,op(plus(m,v),2,e,2,2,4),2)
    pure=cup(op(a,1,e,2,1,4),2,b,1)+cup(h,1,op(b,1,b,1,0,4),2)+cup(s,1,op(h,1,b,1,0,4),2)
    return (ordinary+mixed+pure)%2


def exact():
    a,h,b,k,m,v,w,s,t,names=free(4)
    hn={f:h[f]+t[f[0]]*a[f]for f in a}
    kn={f:k[f]+t[f[0]]*b[f]for f in b}
    M=plus(m,v,op(a,1,b,1,0,4))
    shift=B3(m)+B3(v)+B3(M)
    direct=counted(a,h,b,k,m,v,w,s)+shift
    trial=compact(a,hn,b,kn,m,v,w,s)
    residual=direct+trial
    assert not residual, ('compact candidate fails',len(residual.terms))
    assert not trial+target(a,hn,b,kn,m,v,w,s)+dA2(a,hn,b,kn,m,v,s)+shift
    local=dict(free_bits=len(names),residual_monomials=len(residual.terms),compact_monomials=len(trial.terms))
    a,h,b,k,m,v,w,s,t,names=free(5)
    hn={f:h[f]+t[f[0]]*a[f]for f in a}
    kn={f:k[f]+t[f[0]]*b[f]for f in b}
    dE=Poly.coerce(0)
    for cell in combinations(range(5),4):
        dE+=compact(*(restrict(x,cell) for x in (a,hn,b,kn,m,v,w,s)))
    def source(A,H,M):
        native=plus(M,op(s,1,H,1,0,5))
        return manuscript_bits(A,H,native,w,s,1)+dc(op(M,2,M,2,1,5),3,5)[0,1,2,3,4]
    A=plus(a,b);H=plus(hn,kn,{f:a[f]*b[f] for f in a});M=plus(m,v,op(a,1,b,1,0,5))
    residual=dE+source(A,H,M)+source(a,hn,m)+source(b,kn,v)
    assert not residual, ('paired identity fails',len(residual.terms))
    return dict(local=local,paired_identity=dict(free_bits=len(names),residual_monomials=len(residual.terms)))


def physical():
    n=0;native_negative=0
    for bg in ('zero','w','s','both'):
        for seed in range(256):
            data=generate(4,bg,110000+seed)
            if seed%2:
                for nk,mk in (('n1','n2'),('n1prime','n2prime')):
                    data[nk]={f:-v for f,v in data[nk].items()}
                    data[mk]={f:v^(data['s1'][f[:2]]*(data[nk][f[1:]]%2)) for f,v in data[mk].items()}
                native_negative+=1
            raw,math,_=prepare(data)
            row,initial,final=corrected_P(raw)
            result=loops(initial,final,len(row['modes']))['parity_change']
            assert result==compact(*math)
            n+=1
    return dict(actual_P_graphs=n,signed_input_tests=native_negative,mismatches=0)

if __name__=='__main__':
    result=dict(status='Candidate pairing reference; legacy intermediate schedule not yet certified.',exact=exact(),physical=physical())
    (ROOT/'compact_checks.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

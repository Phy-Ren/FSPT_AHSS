"""Exact packet-level count of the explicitly constructed doubled-boundary graph.
The count uses lengths modulo four only after deriving the permutation formula.
No target obstruction or stacking formula occurs in counted().
"""
from itertools import combinations
from dataclasses import dataclass
@dataclass(frozen=True)
class D:
    lo: object
    hi: object=0
    def __add__(self,b):
        if not isinstance(b,D):b=D(b,0)
        return D((self.lo+b.lo)%2,(self.hi+b.hi+self.lo*b.lo)%2)
    __radd__=__add__
    def __mul__(self,b):
        if not isinstance(b,D):b=D(b,0)
        return D(self.lo*b.lo%2,(self.hi*b.lo+self.lo*b.hi)%2)
    __rmul__=__mul__

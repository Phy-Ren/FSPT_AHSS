"""Exact all-local-input identities for the one-even-input 4D sector.
This tests a counted graph polynomial, never selects physical arrows.
"""
import sys,json,time
from pathlib import Path
from itertools import combinations
from binary_poly import Poly
from digits import D
from graph_count4 import counted
from reference4 import target
from gauge4 import dA3
from prior_obstruction.algebra import B4_bits,counted_bits
from data4 import restrict
from cup import op
Z=Poly.coerce(0)

def free(nv,even):
    names=[]
    def var(name):
        p=Poly.var(len(names));names.append(name);return p
    t=[Z]+[var('s0'+str(i))for i in range(1,nv)]
    s={(i,j):t[i]+t[j]for i,j in combinations(range(nv),2)}
    w={(0,i,j):var('w0'+str(i)+str(j))for i,j in combinations(range(1,nv),2)}
    for i,j,k in combinations(range(1,nv),3):w[i,j,k]=w[0,i,j]+w[0,i,k]+w[0,j,k]
    W={f:w[f]+s[f[:2]]*s[f[1:]]for f in w}
    def one(prefix,is_even):
        n={(0,i,j):D(Z if is_even else var(prefix+'a0'+str(i)+str(j)),var(prefix+'h0'+str(i)+str(j)))for i,j in combinations(range(1,nv),2)}
        for i,j,k in combinations(range(1,nv),3):
            q=n[0,i,k];n[i,j,k]=n[0,j,k]+D(q.lo,q.hi+q.lo)+n[0,i,j]
        a={f:x.lo for f,x in n.items()};h={f:x.hi for f,x in n.items()}
        m={(0,i,j,k):var(prefix+'m0'+str(i)+str(j)+str(k))for i,j,k in combinations(range(1,nv),3)}
        for i,j,k,l in combinations(range(1,nv),4):
            m[i,j,k,l]=(a[0,i,j]+W[0,i,j])*a[j,k,l]+sum((m[(0,)+f]for f in combinations((i,j,k,l),3)),Z)
        return a,h,m
    a,h,m=one('upper_',even in ('upper','both'));b,k,v=one('lower_',even in ('lower','both'))
    return a,h,b,k,m,v,w,s,t,names

def certify(even):
    start=time.monotonic()
    a,h,b,k,m,v,w,s,t,names=free(5,even)
    hn={f:h[f]+t[f[0]]*a[f]for f in a};kn={f:k[f]+t[f[0]]*b[f]for f in b}
    raw=counted(a,h,b,k,m,v,w,s)
    target_value=target(a,hn,b,kn,m,v,w,s)
    A={f:a[f]+b[f]for f in a};H={f:hn[f]+kn[f]+a[f]*b[f]for f in a}
    DeltaB=B4_bits(a,hn,s)+B4_bits(b,kn,s)+B4_bits(A,H,s)
    pair_boundary=dA3(a,hn,b,kn,m,v,s)
    comparison=raw+target_value+DeltaB+pair_boundary
    assert not comparison
    local=dict(free_bits=len(names),raw_terms=len(raw.terms),repo_terms=len(target_value.terms),
               DeltaB_terms=len(DeltaB.terms),pair_boundary_terms=len(pair_boundary.terms),residual_terms=len(comparison.terms),variables=names)
    a,h,b,k,m,v,w,s,t,names=free(6,even)
    lhs=Z
    for f in combinations(range(6),5):
        hf={e:h[e]+t[f[0]]*a[e]for e in h};kf={e:k[e]+t[f[0]]*b[e]for e in k}
        lhs+=counted(*(restrict(q,f)for q in(a,hf,b,kf,m,v,w,s)))
    hn={f:h[f]+t[f[0]]*a[f]for f in a};kn={f:k[f]+t[f[0]]*b[f]for f in b}
    A={f:a[f]+b[f]for f in a};H={f:hn[f]+kn[f]+a[f]*b[f]for f in a};E3=op(a,2,b,2,1,6)
    M={f:m[f]+v[f]+E3[f]for f in m}
    rhs=Z
    for aa,hh,mm in ((a,hn,m),(b,kn,v),(A,H,M)):
        native={f:mm[f]+s[f[:2]]*hh[f[1:]]for f in mm}
        rhs+=counted_bits(aa,hh,native,w,s,2)
    assert not(lhs+rhs)
    return dict(sector=even,local_comparison=local,compatibility=dict(free_bits=len(names),dE_terms=len(lhs.terms),DeltaOphys_terms=len(rhs.terms),residual_terms=len((lhs+rhs).terms),variables=names),seconds=round(time.monotonic()-start,3))

def main():
    report={'scope':'Exact identities for the stated one-even-input sector only. Not an exhaustive numerical enumeration.',
        'sectors':[certify(x)for x in ('upper','lower','both')]}
    dest=Path(__file__).resolve().parents[1]/'results/exact_sector_certificates.json'
    dest.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items()if k!='sectors'},indent=2))
    for r in report['sectors']:print(r['sector'],r['local_comparison']['free_bits'],r['compatibility']['free_bits'],r['seconds'])
    return report
if __name__=='__main__':main()

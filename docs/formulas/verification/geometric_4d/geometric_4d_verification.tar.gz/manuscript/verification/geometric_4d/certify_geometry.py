"""Exact identities after the geometric matching change, all backgrounds.

The count polynomial comes from the archived shuffle proof; the additional
local word-sign theorem is checked independently by check_geometry.py.
"""
from geometric4 import *
from certify_sectors import free,Z
from graph_count4 import counted
from reference4 import target
from comparison4 import dA3_full
from prior_obstruction.algebra import B4_bits,counted_bits,manuscript_bits
from data4 import restrict
from cup import op,dc
import json,time

def B(a,h,m,s):return B4_bits(a,h,s)+core_shift(m)

def report_poly(p,names):
    used=0
    for t in p.terms:used|=t
    return dict(terms=len(p.terms),free_bits=used.bit_count(),variables=[v for i,v in enumerate(names)if used>>i&1])

def run():
    st=time.monotonic();report={}
    for nv in (5,6):
        a,h,b,k,m,v,w,s,t,names=free(nv,'neither')
        hn={f:h[f]+t[f[0]]*a[f]for f in a};kn={f:k[f]+t[f[0]]*b[f]for f in b}
        aa={f:a[f]+b[f]for f in a};hh={f:hn[f]+kn[f]+a[f]*b[f]for f in a}
        e=op(a,2,b,2,1,nv);mm={f:m[f]+v[f]+e[f]for f in m}
        if nv==5:
            deltaG=core_shift(m)+core_shift(v)+core_shift(mm)
            physical=counted(a,h,b,k,m,v,w,s)+a[0,2,4]*b[0,1,2]*b[2,3,4]+deltaG
            repo=target(a,hn,b,kn,m,v,w,s)
            db=B(a,hn,m,s)+B(b,kn,v,s)+B(aa,hh,mm,s)
            da=dA3_full(a,hn,b,kn,m,v,s)
            assert not(physical+repo+db+da)
            report['E4']=dict(free_bits=len(names),physical_terms=len(physical.terms),canonical_terms=len(repo.terms),reference_terms=len(db.terms),boundary_terms=len(da.terms),residual_terms=0)
            # Lower stacking equation in native coordinates, evaluated on a
            # four-simplex, including the integer-digit carry.
            native=[{f:M[f]+s[f[:2]]*H[f[1:]]for f in M}for M,H in((m,hn),(v,kn),(mm,hh))]
            def lower(A):return (A[0,1,2]+w[0,1,2])*A[2,3,4]+s[0,1]*op(A,2,A,2,1,5)[1,2,3,4]
            E3={f:native[0][f]+native[1][f]+native[2][f]for f in m}
            assert not(dc(E3,3,5)[0,1,2,3,4]+lower(a)+lower(b)+lower(aa))
            report['E3_endpoint_compatibility']=dict(free_bits=len(names),residual_terms=0)
        else:
            dE=Z
            for f in combinations(range(6),5):
                H={q:h[q]+t[f[0]]*a[q]for q in h};K={q:k[q]+t[f[0]]*b[q]for q in k}
                args=tuple(restrict(q,f)for q in(a,H,b,K,m,v,w,s))
                ap,hp,bp,kp,mp,vp,wp,sp=args
                ep=op(ap,2,bp,2,1,5);out={q:mp[q]+vp[q]+ep[q]for q in mp}
                dE+=counted(*args)+ap[0,2,4]*bp[0,1,2]*bp[2,3,4]+core_shift(mp)+core_shift(vp)+core_shift(out)
            deltaO=Z
            for A,H,M in((a,hn,m),(b,kn,v),(aa,hh,mm)):
                native={f:M[f]+s[f[:2]]*H[f[1:]]for f in M}
                physical=counted_bits(A,H,native,w,s,2)
                dg=sum((core_shift(restrict(M,f))for f in combinations(range(6),5)),Z)
                physical+=dg
                repo=manuscript_bits(A,H,native,w,s,2)
                db=sum((B(*(restrict(q,f)for q in(A,H,M,s)))for f in combinations(range(6),5)),Z)
                assert not(physical+repo+db)
                if M is m:report['O5']=dict(allowed_input_bits=45,**report_poly(physical,names),canonical_terms=len(repo.terms),reference_boundary_terms=len(db.terms),residual_terms=0)
                deltaO+=physical
            assert not(dE+deltaO)
            report['paired_physical_identity']=dict(free_bits=len(names),dE_terms=len(dE.terms),deltaO_terms=len(deltaO.terms),residual_terms=0)
    report['seconds']=round(time.monotonic()-st,3)
    report['scope']='Exact Boolean coefficient identities, plus a separate arbitrary-length local matching theorem; not enumeration of 2^75 graphs.'
    Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':run()

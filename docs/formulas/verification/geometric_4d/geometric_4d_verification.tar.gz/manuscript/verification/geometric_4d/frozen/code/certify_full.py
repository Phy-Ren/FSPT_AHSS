"""All-local-input certificates for the counted full-background 4D graph.

The only additional grade beyond the independently counted rectangle graph is
one per specified partner-retaining contact. Symmetry conjugates its actual
couplings, so it cannot change this relative grade.
"""
from pathlib import Path
import sys,json,time
from itertools import combinations
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'base4d'))
from certify_sectors import free,Z
from graph_count4 import counted
from reference4 import target
from comparison4 import dA3_full
from prior_obstruction.algebra import B4_bits,counted_bits
from data4 import restrict
from cup import op

def contact_grade(a,b):
    # Derived from one transposition per ordered triple of copy IDs.
    return a[0,2,4]*b[0,1,2]*b[2,3,4]

def run():
    start=time.monotonic()
    a,h,b,k,m,v,w,s,t,names=free(5,'neither')
    hn={f:h[f]+t[f[0]]*a[f] for f in a};kn={f:k[f]+t[f[0]]*b[f] for f in b}
    raw=counted(a,h,b,k,m,v,w,s)+contact_grade(a,b)
    repo=target(a,hn,b,kn,m,v,w,s)
    aa={f:a[f]+b[f] for f in a};hh={f:hn[f]+kn[f]+a[f]*b[f] for f in a}
    db=B4_bits(a,hn,s)+B4_bits(b,kn,s)+B4_bits(aa,hh,s)
    da=dA3_full(a,hn,b,kn,m,v,s)
    residual=raw+repo+db+da
    assert not residual
    local=dict(free_bits=len(names),variables=names,physical_count_terms=len(raw.terms),repo_terms=len(repo.terms),Delta_B4_terms=len(db.terms),dA3_terms=len(da.terms),residual_terms=len(residual.terms))
    a,h,b,k,m,v,w,s,t,names=free(6,'neither')
    lhs=Z
    for f in combinations(range(6),5):
        hf={e:h[e]+t[f[0]]*a[e] for e in h};kf={e:k[e]+t[f[0]]*b[e] for e in k}
        args=tuple(restrict(q,f) for q in (a,hf,b,kf,m,v,w,s))
        lhs+=counted(*args)+contact_grade(args[0],args[2])
    hn={f:h[f]+t[f[0]]*a[f] for f in a};kn={f:k[f]+t[f[0]]*b[f] for f in b}
    aa={f:a[f]+b[f] for f in a};hh={f:hn[f]+kn[f]+a[f]*b[f] for f in a}
    e=op(a,2,b,2,1,6);mm={f:m[f]+v[f]+e[f] for f in m}
    rhs=Z
    for A,H,M in ((a,hn,m),(b,kn,v),(aa,hh,mm)):
        native={f:M[f]+s[f[:2]]*H[f[1:]] for f in M}
        rhs+=counted_bits(A,H,native,w,s,2)
    assert not(lhs+rhs)
    report=dict(scope='All locally allowed lower data in the fixed signed/mod-four effective reference; both backgrounds',
        local_equivalence=local,physical_compatibility=dict(free_bits=len(names),variables=names,dE_terms=len(lhs.terms),Delta_Ophys_terms=len(rhs.terms),residual_terms=len((lhs+rhs).terms)),seconds=round(time.monotonic()-start,3))
    (ROOT/'results/exact_full.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items()if k not in ('local_equivalence','physical_compatibility')},indent=2))
    print('Local:',local['free_bits'],'bits; zero residual')
    print('Compatibility:',len(names),'bits; zero residual')
    return report
if __name__=='__main__':run()

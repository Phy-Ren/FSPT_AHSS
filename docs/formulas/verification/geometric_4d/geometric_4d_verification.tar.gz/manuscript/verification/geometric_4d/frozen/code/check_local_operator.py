"""Independent two-complex-fermion matrix check of the contact operation."""
from pathlib import Path
import json, numpy as np
I=np.eye(2,dtype=complex);X=np.array([[0,1],[1,0]],complex)
Y=np.array([[0,-1j],[1j,0]],complex);Z=np.diag([1.,-1.])
g=[np.kron(X,I),np.kron(Y,I),np.kron(Z,X),np.kron(Z,Y)]
u=g[2]@(g[0]-g[1])/np.sqrt(2)
expected=[g[1],g[0],-g[2],g[3]]
errors=[float(np.max(abs(u@x@u.conj().T-y)))for x,y in zip(g,expected)]
parity=-g[0]@g[1]@g[2]@g[3]
report={'unitarity_error':float(np.max(abs(u@u.conj().T-np.eye(4)))),
        'conjugation_errors':errors,
        'total_parity_commutator':float(np.max(abs(u@parity-parity@u)))}
assert max([report['unitarity_error'],report['total_parity_commutator']]+errors)<1e-14
root=Path(__file__).resolve().parents[1]
(root/'results/local_operator.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))

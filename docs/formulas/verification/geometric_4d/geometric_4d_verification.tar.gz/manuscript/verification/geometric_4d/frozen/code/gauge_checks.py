#!/usr/bin/env python3
"""Exact paired-source/product and closed single-state gauge checks.

This is an algebraic audit, deliberately separate from physical graph building.
It tests the identities for a nonclosed B4 and a closed C4 without modifying
any computed mode or arrow. The general identities follow by linearity of d.
"""
from pathlib import Path
import sys,json
R=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(R/'base4d'))
from certify_sectors import free
from cup import op,dc
from reference4 import plus

def run():
    a,h,b,k,m,v,w,s,t,names=free(6,'neither')
    # Native second digits, including signs from each simplex's own first vertex.
    h={f:h[f]+t[f[0]]*a[f]for f in a}
    k={f:k[f]+t[f[0]]*b[f]for f in b}
    N=plus(a,b);H={f:h[f]+k[f]+a[f]*b[f]for f in a}
    # B4=a cup h is a deliberately nonclosed reference change.
    Bs=[op(A,2,Hh,2,0,6) for A,Hh in ((a,h),(b,k),(N,H))]
    delta_B=plus(*Bs)
    d_delta_B=dc(delta_B,4,6)
    delta_dB=plus(*(dc(B,4,6)for B in Bs))
    assert d_delta_B==delta_dB
    assert any(bool(x)for x in d_delta_B.values()),'Negative control must really be nonzero.'
    # C4=a cup a is a closed single-state expression (not claimed nonexact).
    Cs=[op(A,2,A,2,0,6)for A in (a,b,N)]
    for C in Cs:assert not any(bool(x)for x in dc(C,4,6).values())
    d_delta_C=dc(plus(*Cs),4,6)
    assert not any(bool(x)for x in d_delta_C.values())
    report={'free_bits':len(names),'test_B4':'[n2]_2 cup [floor(n2/2)]_2',
      'd_Delta_B4_equals_Delta_dB4':True,
      'source_only_change_has_nonzero_defect':True,
      'source_only_defect_monomials':sum(len(x.terms)for x in d_delta_B.values()),
      'paired_change_residual_monomials':sum(len((d_delta_B[f]+delta_dB[f]).terms)for f in d_delta_B),
      'test_C4':'[n2]_2 cup [n2]_2; closed, not asserted to define a nontrivial class',
      'closed_single_state_residual_monomials':sum(len(x.terms)for x in d_delta_C.values()),
      'general_rule':'O->O+dB, E->E+DeltaB+dA+DeltaC, dC=0; Delta uses the actual second-order output'}
    (R/'results/gauge_checks.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2));return report
if __name__=='__main__':run()

"""Four-dimensional single-layer extension of the manuscript's fixed gamma graph.

No obstruction/product formula is imported. The frozen constructors supply
mode identities and histories. Only each cell's local matching is replaced.
"""
from pathlib import Path
import sys
from itertools import combinations
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'frozen/code'))
sys.path.insert(0,str(ROOT/'frozen/base4d'))
from kasteleyn import loops,word_parity
from prior_obstruction.model import Input,build as old_F
from prior_obstruction.split_model import build_split as old_split_F
from full_network import build as old_P

# Clockwise circuit in the original resolved four-simplex. Its arrows follow
# this linear order; the closing edge points from 0123 B to 0234 A.
SLOTS=(4,2,0,3,1)

def local_pairs(face_modes,central):
    """Insert an odd central remainder at the last occupied B (else first A).

    Even face subsets use EXACTLY the original 16 gamma configurations. Center
    pairs keep their existing labels. No surviving mode is renamed a gamma.
    """
    ports={j:face_modes[j]for j in SLOTS if j in face_modes}
    q=list(central);edges=[]
    if len(q)%2:
        bs=[j for j in SLOTS[:3]if j in ports]
        if bs:
            j=bs[-1];edges.append((ports.pop(j),q.pop(0)))
        else:
            j=next(j for j in SLOTS[3:]if j in ports)
            edges.append((q.pop(0),ports.pop(j)))
    edges+=list(zip(q[::2],q[1::2]))
    if len(ports)==2:
        seq=[ports[j]for j in SLOTS if j in ports];edges.append(tuple(seq))
    elif len(ports)==4:
        gap=next(i for i,j in enumerate(SLOTS)if j not in ports)
        walk=[SLOTS[(gap+i)%5]for i in range(1,5)]
        for j,k in zip(walk[::2],walk[1::2]):
            if SLOTS.index(j)>SLOTS.index(k):j,k=k,j
            edges.append((ports[j],ports[k]))
    elif ports:raise ValueError('The endpoint condition must make the full core even')
    assert sorted(v for e in edges for v in e)==sorted(list(face_modes.values())+list(central))
    return edges

def change_F(data,split=False,extra_padding=0):
    r=(old_split_F if split else old_F)(data,extra_padding=extra_padding)
    edges_out={};new_log={}
    for side in ('in','out'):
        old_core={tuple(e['actual_dimer'])for e in r['arrow_log'][side]}
        edges=[tuple(e)for e in r['dimers'][side]if tuple(e) not in old_core]
        log=[]
        for row in r['local_lists'][side]:
            cell=tuple(row['cell']);ports={};central=[];bits={}
            places={p['id']:p for p in r['placements'][side]if tuple(p['cell'])==cell}
            for mode in row['modes']:
                p=places[mode]
                if p['source'] in ('intrinsic','projective'):
                    central.append(mode);bits[mode]=p.get('kappa_ref',p.get('wall_polarity'))
                else:
                    face=tuple(r['modes'][mode]['face'])
                    j=next(j for j in range(5)if cell[:j]+cell[j+1:]==face)
                    ports[j]=mode;bits[mode]=int(j%2==0)
            special=ports.get(0)
            for u,v in local_pairs(ports,central):
                w=s=0
                if cell[0]==1:
                    w=data.omega[0,1,2]*int(special in (u,v))
                    s=data.s[0,1]*(1^bits[u]^bits[v])
                edge=(v,u)if w^s else(u,v)
                edges.append(edge)
                log.append(dict(cell=list(cell),standard_dimer=[u,v],actual_dimer=list(edge),omega_flip=w,antiunitary_flip=s))
        assert sorted(v for e in edges for v in e)==list(range(r['mode_count']))
        edges_out[side]=edges;new_log[side]=log
    r['archived_dimers']=r['dimers'];r['dimers']=edges_out;r['arrow_log']=new_log
    r['count']=loops(edges_out['in'],edges_out['out'],r['mode_count'])
    return r

def change_P(data):
    r=old_P(data)
    raw_old=r['unrefined_count']
    # Origins are immutable; rho carries each physical operator to its current
    # slot. The contact acts on whole carriers, including all their partners.
    modes=r['modes'];rho=r['current_slot_modes'];n=len(modes)
    old_input={tuple(e)for c in r['input_cores']for e in c['dimers']}
    initial=[tuple(e)for e in r['dimers']['in']if tuple(e)not in old_input]
    c=(0,1,2,3,4)
    for row in r['input_cores']:
        ports={};central=[]
        for i in row['modes']:
            mode=modes[i]
            if mode['kind']=='ordinary':
                f=tuple(mode['face']);j=next(j for j in range(5)if c[:j]+c[j+1:]==f);ports[j]=i
            else:central.append(i)
        initial+=local_pairs(ports,central)
    output_ids={i for e in r['output_core']for i in e}
    final=[tuple(e)for e in r['dimers']['out']if not set(e)<=output_ids]
    ports={};central=[];sign={}
    for f in r['face_steps']:
        if f['survivor']:
            i,theta=f['survivor'];face=tuple(f['face'])
            j=next(j for j in range(5)if c[:j]+c[j+1:]==face);ports[j]=i;sign[i]=theta
    # Recover row-major N2 order from the same frozen rectangle assembly.
    # The old output list is consecutive-paired, so concatenation of its edges
    # recovers the list up to orientation. Recover intrinsic/projective slots
    # explicitly from their physical copy origins instead.
    a=data['n2'];b=data['n2prime']
    from data4 import prepare
    (A,B,*_),_,_=prepare(data)
    r0=A[0,1,2];c0=A[2,3,4];r1=B[0,1,2];c1=B[2,3,4]
    by={}
    for m in modes:
        if m['kind']=='intrinsic':key=('intrinsic',m['group'],m['row'],m['column'])
        elif m['kind']=='cross_intrinsic':key=('intrinsic',m['block'],m['row'],m['column'])
        elif m['kind']=='projective':key=('projective',m['group'],m['row'],m['column'])
        else:continue
        by[key]=rho[m['id']]
    for i in range(1,r0+r1+1):
        for j in range(1,c0+c1+1):
            group='upper'if i<=r0 and j<=c0 else 'upper-lower'if i<=r0 else 'lower-upper'if j<=c0 else 'lower'
            key=('intrinsic',group,i if i<=r0 else i-r0,j if j<=c0 else j-c0)
            central.append(by[key])
    w=data['omega2'][0,1,2]^(data['s1'][0,1]*data['s1'][1,2])
    for i in range(1,w+1):
        for j in range(1,c0+c1+1):
            central.append(by['projective','upper'if j<=c0 else'lower',i,j if j<=c0 else j-c0])
    for u,v in local_pairs(ports,central):final.append((v,u)if sign.get(u,0)^sign.get(v,0)else(u,v))
    after=[(rho[u],rho[v])for u,v in initial]
    for e in (initial,after,final):assert sorted(i for p in e for i in p)==list(range(n))
    r['archived_dimers']=r['dimers'];r['dimers']={'in':initial,'after_contacts':after,'out':final}
    r['count']=loops(initial,final,n)
    r['stage_counts']={'capped_contacts':loops(initial,after,n),'remaining_regrouping':loops(after,final,n)}
    return r

def core_shift(m):
    return (m[0,1,2,3]*m[0,1,3,4]+m[0,1,2,3]*m[1,2,3,4]
          +m[0,1,3,4]*m[1,2,3,4]+m[0,1,2,4]*m[0,2,3,4])%2

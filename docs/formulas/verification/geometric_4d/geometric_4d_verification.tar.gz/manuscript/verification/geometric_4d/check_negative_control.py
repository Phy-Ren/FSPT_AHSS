"""Removing the actual contact must break the physical paired identity."""
from geometric4 import *
from data4 import load,restrict,output
import json
raw=json.loads((ROOT/'cases/previous_bare_failure.json').read_text());d=load(raw['input'])
right=wrong=0
for cell in combinations(range(6),5):
    r=change_P({k:restrict(v,cell)for k,v in d.items()});rho=r['current_slot_modes'];inv={v:i for i,v in enumerate(rho)}
    without=[(inv[a],inv[b])for a,b in r['dimers']['out']]
    right^=r['count']['parity_change'];wrong^=loops(r['dimers']['in'],without,r['mode_count'])['parity_change']
N,M=output(d);target=0
for n,m in((d['n2'],d['n3']),(d['n2prime'],d['n3prime']),(N,M)):
    target^=change_F(Input(2,n,m,d['omega2'],d['s1']),True)['count']['parity_change']
assert right^target==0 and wrong^target==1
report=dict(status='PASS',correct_identity_residual=right^target,omitted_contact_residual=wrong^target)
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))

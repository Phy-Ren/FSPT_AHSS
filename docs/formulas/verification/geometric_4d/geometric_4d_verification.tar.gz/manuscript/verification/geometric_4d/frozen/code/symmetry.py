"""Symmetry transport of actual operators, couplings, and the capped contact.

No stacking or obstruction formula is used. 'anti' refers to conjugation of i,
not to a sign freely assigned to a Majorana diagram. Every other sign is an
explicit real-mode transport sign in a fixed common basis.
"""
from pathlib import Path
from itertools import product,combinations
import sys,json,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'base4d'))
from kasteleyn import loops,pfaffian_sign
from contact_mass import hamiltonian,LEFT,RIGHT,conjugacy

def transport_edges(edges, signs, permutation=None, anti=0):
    if permutation is None:permutation=list(range(len(signs)))
    if anti not in (0,1) or any(x not in (-1,1) for x in signs):
        raise ValueError('anti must be binary and real transport signs must be +/-1')
    out=[]
    for x,y in edges:
        a,b=permutation[x],permutation[y]
        out.append((a,b) if (-1)**anti*signs[x]*signs[y]==1 else (b,a))
    return out

def signed_contact_edges(edges,x,y,relative_sign=1,point=None):
    """Full Clifford image: x -> delta*y, y -> delta*x, point -> -point."""
    if x==y or relative_sign not in (-1,1):raise ValueError('Invalid contact')
    out=[]
    for a,b in edges:
        aa=y if a==x else x if a==y else a
        bb=y if b==x else x if b==y else b
        sa=relative_sign if a in (x,y) else (-1 if a==point else 1)
        sb=relative_sign if b in (x,y) else (-1 if b==point else 1)
        out.append((aa,bb) if sa*sb==1 else (bb,aa))
    return out

def all_matchings(xs):
    if not xs:yield [];return
    a=xs[0]
    for j,b in enumerate(xs[1:],1):
        for r in all_matchings(xs[1:j]+xs[j+1:]):yield [(a,b)]+r

def partner_tests(full=False):
    count=0
    for n in ((2,4,6,8) if full else (2,4,6)):
        for pairs in all_matchings(list(range(n))):
            for arrows in product((0,1),repeat=n//2):
                e=[(b,a) if s else (a,b) for (a,b),s in zip(pairs,arrows)]
                for x,y in combinations(range(n),2):
                    for delta in (-1,1):
                        end=signed_contact_edges(e,x,y,delta)
                        assert loops(e,end,n)['parity_change']==1
                        # The physical point fermion repairs that measured odd grade.
                        end2=signed_contact_edges(e+[(n,n+1)],x,y,delta,n)
                        assert loops(e+[(n,n+1)],end2,n+2)['parity_change']==0
                        count+=1
    return count

def group_tests():
    """All bilinear omega representatives on Z2 x Z2 and all homomorphisms s.
    Check both exact real representations and the reset-end embedding.
    The symbolic cancellation is stated in the note; this is an independent test.
    """
    G=list(product(range(2),repeat=2));idx={g:i for i,g in enumerate(G)}
    add=lambda a,b:tuple(x^y for x,y in zip(a,b));count=0
    for ws in product((0,1),repeat=4):
      w=lambda g,h:sum(ws[2*i+j]*g[i]*h[j] for i in range(2)for j in range(2))%2
      for ss in product((0,1),repeat=2):
        s=lambda g:sum(x*y for x,y in zip(g,ss))%2
        mats={}
        for g in G:
          T=np.zeros((8,8),dtype=int)
          for sigma in G:
            for k in (0,1):
              T[2*idx[add(g,sigma)]+(k^s(g)),2*idx[sigma]+k]=(-1)**(w(g,sigma)+s(g)*s(sigma)+s(g)*k)
              # A/B geometric reset ends: k_A=s(sigma), k_B=1+s(sigma).
              for side in (0,1):
                k0=side^s(sigma)
                assert (w(g,sigma)+s(g)*s(sigma)+s(g)*k0)%2==(w(g,sigma)+s(g)*side)%2
          mats[g]=T
        for g in G:
          for h in G:
            assert np.array_equal(mats[g]@mats[h],(-1)**w(g,h)*mats[add(g,h)])
            count+=1
    return count

def operator_tests():
    I=np.eye(2);X=np.array([[0,1],[1,0]],complex);Y=np.array([[0,-1j],[1j,0]],complex);Z=np.diag([1.,-1.])
    g=[np.kron(X,I),np.kron(Y,I),np.kron(Z,X),np.kron(Z,Y)]
    P=-g[0]@g[1]@g[2]@g[3];rows=[]
    for ea,eb,ec in product((-1,1),repeat=3):
      delta=ea*eb;U=ec*ea*g[2]@(g[0]-delta*g[1])/np.sqrt(2)
      targets=[delta*g[1],delta*g[0],-g[2],g[3]]
      err=max(float(np.max(abs(U@a@U.conj().T-b)))for a,b in zip(g,targets))
      assert err<1e-14 and np.max(abs(U@P-P@U))<1e-14
      rows.append(dict(signs=[ea,eb,ec],relative_sign=delta,max_error=err))
    return rows

def mass_symmetry_tests():
    a,_=hamiltonian(LEFT);b,_=hamiltonian(RIGHT);n=len(a);parent=n-4
    qperm,qsign=conjugacy(n)
    def image(A,p,sg,anti=0):return (-1)**anti*A[np.ix_(p,p)]*sg[:,None]*sg[None,:]
    gap=[float(np.min(abs(np.linalg.eigvalsh(1j*x))))for x in (a,b)]
    assert min(gap)>1e-5
    rows=[];pfchecks=0;cases=0
    # Same physical transport applied to both massive capped systems.
    # Color/projective signs, arbitrary fixed cap partner signs, both unitarities.
    for anti in (0,1):
      for colors in product((-1,1),repeat=3):
       for caps in product((-1,1),repeat=4):
        p=list(range(n));sg=np.ones(n,dtype=int)
        for j in range(parent):
          x=j//6;r=(j%6)//3;c=j%3
          p[j]=6*x+3*(r^anti)+c
          sg[j]=colors[c]*(-1 if anti and r==0 else 1)
        sg[parent:]=caps
        ag=image(a,p,sg,anti);bg=image(b,p,sg,anti)
        # Sparse Qg = S Q S^{-1}; explicit matrices used to avoid a silent
        # assumption that the two real bases are separately reorderable.
        inv=np.argsort(p);newp=[int(inv[qperm[p[j]]])for j in range(n)]
        news=np.array([sg[j]*qsign[p[j]]*sg[newp[j]]for j in range(n)])
        err=float(np.max(abs(image(ag,newp,news)-bg)))
        assert err<1e-13
        # Conjugation preserves det Q=-1, including the four retained caps.
        inversions=sum(newp[i]>newp[j]for i in range(n)for j in range(i+1,n))
        det=(-1)**inversions*int(np.prod(news));assert det==-1
        if caps==(-1,-1,-1,-1):
            ps=[pfaffian_sign(ag),pfaffian_sign(bg)];assert ps[0]*ps[1]==-1;pfchecks+=2
            rows.append(dict(anti=anti,color_signs=colors,cap_signs=caps,pfaffians=ps,max_conjugacy_error=err))
        cases+=1
    return dict(real_modes=n,base_gaps=gap,common_transport_cases=cases,independent_pfaffian_evaluations=pfchecks,sampled_pfaffians=rows)

def run(full=False):
    start=time.monotonic()
    report=dict(projective_group_law_checks=group_tests(),local_repaired_operators=operator_tests(),
                arbitrary_partner_signed_contacts=partner_tests(full),capped_mass_covariance=mass_symmetry_tests(),seconds=round(time.monotonic()-start,3))
    (ROOT/'results'/('symmetry_full.json'if full else'symmetry_quick.json')).write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2));return report
if __name__=='__main__':run('--full'in sys.argv)

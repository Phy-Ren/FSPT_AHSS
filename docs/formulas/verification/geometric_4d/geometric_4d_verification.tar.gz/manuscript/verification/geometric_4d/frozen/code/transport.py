"""Whole-carrier transport and correlated edge tracking in a fixed CAR basis."""
from pathlib import Path
import sys,itertools
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'base4d'))
from rotations import rotate_edges
from kasteleyn import loops,word_parity


def transfer(edges,source,reserve):
    """Move every real component, not just the zero mode of a complex orbital.

    source,reserve each have even cardinality. Reserve starts in the chosen
    pair vacuum. An existing edge to a source mode becomes a bridge automatically.
    """
    if len(source)!=len(reserve) or len(source)%2 or set(source)&set(reserve):
        raise ValueError('Need disjoint equally sized complete even real-mode carriers')
    cur=list(map(tuple,edges));snap=[cur]
    for x,y in zip(source,reserve):
        cur=rotate_edges(cur,x,y,1);snap.append(cur)
    return dict(dimers={'in':list(map(tuple,edges)),'out':cur},
        gates=[[x,y,1]for x,y in zip(source,reserve)],intermediate_matchings=snap)


def verify():
    def matchings(xs):
        if not xs:
            yield []; return
        for j in range(1,len(xs)):
            for tail in matchings(xs[1:j]+xs[j+1:]):
                yield [(xs[0],xs[j])]+tail
    checks=0
    for n in (2,4,6):
        for m in matchings(list(range(n))):
            for sign in itertools.product((0,1),repeat=n//2):
                d=[(b,a)if s else(a,b)for(a,b),s in zip(m,sign)]
                for size in range(2,n+1,2):
                    for src in itertools.combinations(range(n),size):
                        dst=list(range(n,n+size))
                        refs=list(zip(dst[::2],dst[1::2]));rec=transfer(d+refs,src,dst)
                        result=loops(rec['dimers']['in'],rec['dimers']['out'],n+size)
                        assert result['parity_change']==0
                        assert sorted(x for e in rec['dimers']['out']for x in e)==list(range(n+size))
                        checks+=1
    # Six-mode example: both old psi partners are ordinary gamma' modes.
    sample=transfer([(0,2),(3,1),(4,5)],[2,3],[4,5])
    sample['names']=["gamma'_0134,B","gamma'_0234,A","psi'_01234,1","psi'_01234,2","eta_1","eta_2"]
    sample['count']=loops(sample['dimers']['in'],sample['dimers']['out'],6)
    return dict(exhaustive_small_carrier_cases=checks,six_mode_example=sample)
if __name__=='__main__':
 import json
 result=verify();print(json.dumps(result,indent=2))
 (Path(__file__).resolve().parents[1]/'results/transport_verification.json').write_text(json.dumps(result,indent=2)+'\n')

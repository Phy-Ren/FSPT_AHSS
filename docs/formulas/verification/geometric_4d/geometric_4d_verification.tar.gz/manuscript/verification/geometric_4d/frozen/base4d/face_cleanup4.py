"""Two-ended cleanup for a tetrahedral seam, separate from a five-mode core.

Ordinary channels have A/B transport bits (0,1). Each resolved O or I channel
has the stated reference wall bit at both ends; the full species-related mass
history is retained. The output is actual rotations, not a relabeling psi=gamma.
This elementary identity does not repair the general core compatibility defect.
"""
from rotations import rotate_edges
from kasteleyn import loops

def build(upper_bit,lower_bit,wall_bits,species_bit):
    u,v,t=upper_bit,lower_bit,species_bit
    if any(x not in (0,1) for x in [u,v,t]+list(wall_bits)):
        raise ValueError('Expected binary wall/species/chain data')
    channels=[dict(kind='upper_gamma',ids=[0,1],transport=[0,1],reference_sign=1),
              dict(kind='lower_gamma',ids=[2,3],transport=[0,1],reference_sign=1)]
    for i,k in enumerate(wall_bits):
        channels.append(dict(kind='exchange_psi',index=i+1,ids=[4+2*i,5+2*i],
                             transport=[k,k],reference_sign=(-1)**t))
    active=([0]if u else[])+([1]if v else[])+list(range(2,len(channels)))
    survivor=active[-1]if len(active)%2 else None
    parked=list(zip(active[::2],active[1::2]));initial=[];gates=[]
    for i,bit in ((0,u),(1,v)):
        if not bit:initial.append(tuple(channels[i]['ids']))
    for i,j in parked:
        x,y=channels[i],channels[j];xa,xb=x['ids'];ya,yb=y['ids'];kx,ky=x['transport'],y['transport']
        qa=(-1)**(t*(1^kx[0]^ky[0]));qb=(-1)**(t*(1^kx[1]^ky[1]))
        initial.extend([(xa,ya)if qa==1 else(ya,xa),(yb,xb)if qb==1 else(xb,yb)])
        gates.append([xb,ya,-qa*x['reference_sign']])
    n=2*len(channels);theta=None
    if survivor is not None:
        x=channels[survivor];xa,xb=x['ids'];k=x['transport']
        theta=[(-1)**(t*k[0]),(-1)**(t*(k[1]^1))]
        initial.extend([(xa,n)if theta[0]==1 else(n,xa),(xb,n+1)if theta[1]==1 else(n+1,xb)])
        if survivor!=0:gates.extend([[xa,0,theta[0]],[xb,1,theta[1]]])
    target=[]
    for i,x in enumerate(channels):
        a,b=x['ids']
        if i==0 and survivor is not None:target.extend([(a,n),(b,n+1)])
        else:target.append((a,b)if x['reference_sign']==1 else(b,a))
    end=initial
    for x,y,q in gates:end=rotate_edges(end,x,y,q)
    assert set(end)==set(target)
    counted=loops(initial,target,n+(2 if survivor is not None else 0));assert not counted['parity_change']
    return dict(channels=channels,active_order=active,survivor=survivor,
                dimers={'in':initial,'out':target},gates=gates,count=counted,
                interpretation='Both incident cores are sewn BEFORE this shared-face cleanup.')

def verify():
    from itertools import product
    cases=0
    for size in range(7):
        for walls in product((0,1),repeat=size):
            for u,v,t in product((0,1),repeat=3):
                build(u,v,walls,t);cases+=1
    return cases
if __name__=='__main__':print(verify(),'complete two-ended cleanup tests passed.')

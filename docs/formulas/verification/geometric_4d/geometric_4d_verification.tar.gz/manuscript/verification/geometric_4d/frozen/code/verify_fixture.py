#!/usr/bin/env python3
"""Rebuild the fixed full-background example and compare every physical field."""
from pathlib import Path
import sys,json
R=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(R/'base4d'))
from data4 import load,prepare
from full_network import build
from reference4 import target,delta_B4
from comparison4 import dA3_full
from replay_matchings import replay
f=json.loads((R/'cases/full_background_contact.json').read_text())
d=load(f['input']);r=build(d,compile_gates=True)
expected=json.loads((R/'results/full_background_graph.json').read_text())
for key in ('modes','current_slot_modes','contacts','face_steps','output_core','dimers','count','core_circuit'):
    assert json.dumps(r[key],sort_keys=True)==json.dumps(expected[key],sort_keys=True),key
q=prepare(d)[1];s=f['checked_summary']
assert r['mode_count']==s['real_modes'] and len(r['contacts'])==s['literal_contacts']
assert target(*q)==s['repo_E4'] and delta_B4(d)==s['Delta_B4']
assert dA3_full(*q[:6],q[7])==s['dA3']
assert r['count']['parity_change']==s['network_E4']==s['repo_E4']^s['Delta_B4']^s['dA3']
ans=replay(r,True)
print(json.dumps({'fixture':'full_background_contact','all_edges_and_gates_identical':True,'summary':s,
 'stage_parities':ans['stage_parities'],'core_gates_replayed':ans['even_core_gates_replayed']},indent=2))

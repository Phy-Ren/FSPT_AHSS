"""Even psi subcircuits; the original pure-gamma move is never recompiled."""
from geometric4 import *
from data4 import generate
from rotations import rotate_edges
from itertools import product
import json,time

def compile_psi(r,first,last):
    modes=r['modes'];n=len(modes);first=list(map(tuple,first));last=list(map(tuple,last))
    psi={p['id']for p in modes if p['kind'] not in ('ordinary','exterior_reference')}
    gamma={p['id']for p in modes if p['kind']=='ordinary'}
    permitted={e for e in first+last if set(e)<=gamma}
    parity=loops(first,last,n);current=first+[(n,n+1)];gates=[];odd=0;components=0
    def gate(u,v,q):
        nonlocal current
        assert u in psi or v in psi
        after=rotate_edges(current,u,v,q)
        assert not loops(current,after,n+2)['parity_change']
        assert {e for e in after if set(e)<=gamma}<=permitted
        current=after;gates.append((u,v,q))
    for loop in parity['loops']:
        ids={e['from']for e in loop['edges']};choices=ids&psi
        if not choices:continue
        pivot=min(choices);remaining=set(ids);components+=1
        targets={e for e in last if e[0]in ids}
        partners={i:j for a,b in targets for i,j in((a,b),(b,a))}
        while len(remaining)>2:
            mate=next(b if a==pivot else a for a,b in current if pivot in(a,b));other=partners[mate]
            assert other!=pivot
            wanted=next(e for e in targets if set(e)=={mate,other})
            for sign in (1,-1):
                if wanted in rotate_edges(current,pivot,other,sign):break
            else:raise AssertionError('No oriented quarter turn')
            gate(pivot,other,sign);remaining-={mate,other}
        wanted=next(e for e in targets if pivot in e)
        if wanted not in current:
            # A single continuous even pi/2 rotation of psi with an already
            # present real component of c. Its two quarter steps are recorded.
            gate(pivot,n,1);gate(pivot,n,1);odd^=1
        assert targets<=set(current)
    for loop in parity['loops']:
        ids={e['from']for e in loop['edges']}
        if not ids&psi:assert {e for e in first if e[0]in ids}<=set(current)
    assert ((n+1,n)if odd else(n,n+1))in current
    # Same sequence works for both initial occupations; no fresh point mode.
    flipped=first+[(n+1,n)]
    for g in gates:flipped=rotate_edges(flipped,*g)
    assert set(flipped)==set(current[:-1]+[current[-1][::-1]])
    return components,len(gates)

def run():
    st=time.monotonic();stats=dict(P_graphs=0,F_graphs=0,psi_components=0,even_gates=0)
    for bg in('zero','w','s','both'):
        for seed in range(64):
            d=generate(5,bg,53000+seed);r=change_P(d)
            c,g=compile_psi(r,r['dimers']['after_contacts'],r['dimers']['out'])
            stats['P_graphs']+=1;stats['psi_components']+=c;stats['even_gates']+=g
        for seed in range(32):
            d=generate(6,bg,55000+seed);r=change_F(Input(2,d['n2'],d['n3'],d['omega2'],d['s1']),True)
            c,g=compile_psi(r,r['dimers']['in'],r['dimers']['out'])
            stats['F_graphs']+=1;stats['psi_components']+=c;stats['even_gates']+=g
    stats.update(status='PASS',pure_gamma_components_unchanged=True,intermediate_gamma_pairs_only_initial_or_target=True,seconds=round(time.monotonic()-st,3))
    Path(__file__).with_suffix('.json').write_text(json.dumps(stats,indent=2)+'\n');print(json.dumps(stats,indent=2))
if __name__=='__main__':run()

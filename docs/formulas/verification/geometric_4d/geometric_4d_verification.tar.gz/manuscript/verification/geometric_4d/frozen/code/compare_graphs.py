#!/usr/bin/env python3
"""Locate the first difference between two exported physical graph records."""
from pathlib import Path
import argparse,json
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('reference',type=Path);p.add_argument('candidate',type=Path)
a=p.parse_args();r=json.loads(a.reference.read_text());c=json.loads(a.candidate.read_text())
for key in ('input','modes','current_slot_modes','contacts','face_steps','output_core','dimers','count'):
    if r[key]!=c[key]:
        if isinstance(r[key],list):
            for i,(u,v)in enumerate(zip(r[key],c[key])):
                if u!=v:raise SystemExit(f'First mismatch: {key}[{i}]\nreference={u}\ncandidate={v}')
        raise SystemExit(f'Mismatch in {key}; inspect the two named fields.')
print('All origins, slot identities, contacts, face bridges, core bonds and transition loops agree.')

#!/usr/bin/env python3
"""Build one physical four-simplex stacking graph; never import target formulas.

Input is either a JSON object with the six complete cochains, or a case/report
with an 'input' field containing them. Values live on vertices 0,...,4. Face
keys are strings such as '012'. Use --gates for the parity-repaired core circuit.
"""
from pathlib import Path
import argparse
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'base4d'))
from data4 import load
from full_network import build


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('case', type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--gates', action='store_true')
    args = parser.parse_args()
    try:
        document = json.loads(args.case.read_text())
        report = build(load(document.get('input', document)),
                       compile_gates=args.gates)
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report, indent=2) + '\n')
    except (OSError, ValueError, KeyError, TypeError) as exc:
        parser.error(str(exc))
    print(f"{report['mode_count']} persistent real modes; "
          f"{len(report['contacts'])} literal contacts; "
          f"parity {report['count']['parity_change']}")
    print(f"Wrote {args.output}")


if __name__ == '__main__':
    main()

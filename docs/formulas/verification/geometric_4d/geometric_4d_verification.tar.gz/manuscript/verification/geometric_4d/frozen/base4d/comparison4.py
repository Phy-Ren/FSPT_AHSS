"""Exact diagnostics, never imported by the mode/arrow constructor.

The full graph has a nonclosed residual T4. Its cancellation is NOT a proved
physical contact operation. In the one-even-input sector T4 vanishes identically.
"""
from itertools import combinations
from cup import cup,op
from data4 import restrict

def A3_full(a,h,b,k,m,v,s):
    e=cup(a,2,b,2,1)
    return (m[0,1,2,3]*v[0,1,2,3]+e*(m[0,1,2,3]+v[0,1,2,3])
        +cup(h,2,k,2,1)+a[0,1,3]*k[1,2,3]
        +(1+s[0,1])*h[0,1,3]*b[1,2,3]
        +s[0,1]*a[0,1,3]*b[0,1,3]*(a[1,2,3]+b[1,2,3]))%2

def dA3_full(a,h,b,k,m,v,s):
    return sum(A3_full(*(restrict(q,f)for q in (a,h,b,k,m,v,s)))for f in combinations(range(5),4))%2

def residual_T4(a,b):return (a[0,2,4]*b[0,1,2]*b[2,3,4])%2

def dT4(a,b):return sum(residual_T4(restrict(a,f),restrict(b,f))for f in combinations(range(6),5))%2

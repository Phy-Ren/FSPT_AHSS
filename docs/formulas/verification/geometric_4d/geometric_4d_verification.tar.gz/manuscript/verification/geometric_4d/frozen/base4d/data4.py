"""Local exact lower-tower inputs for the 4+1D research candidate."""
from itertools import combinations
import random
from cup import cup,op,dc

def restrict(d,V):
    V=tuple(V);S=set(V)
    return {tuple(V.index(i)for i in f):v for f,v in d.items()if set(f)<=S}

def generate(nv=6,background='both',seed=0):
    r=random.Random(seed);t=[0]+[r.randrange(2)if background in ('s','both')else 0 for _ in range(nv-1)]
    s={f:t[f[0]]^t[f[1]]for f in combinations(range(nv),2)}
    e={f:r.randrange(2)if background in ('w','both')else 0 for f in s}
    omega=dc(e,1,nv);w={f:omega[f]^(s[f[:2]]*s[f[1:]])for f in omega}
    def one():
        a={(0,i,j):r.randrange(4)for i,j in combinations(range(1,nv),2)}
        for i,j,k in combinations(range(1,nv),3):a[i,j,k]=a[0,j,k]-a[0,i,k]+a[0,i,j]
        # Optional common positive closed multiple-four stabilization.
        pad=max(0,(-min(a.values())+3)//4)
        a={f:x+4*pad for f,x in a.items()}
        m={(0,i,j,k):r.randrange(2)for i,j,k in combinations(range(1,nv),3)}
        for i,j,k,l in combinations(range(1,nv),4):
            m[i,j,k,l]=((a[0,i,j]+w[0,i,j])*a[j,k,l]+m[0,j,k,l]+m[0,i,k,l]+m[0,i,j,l]+m[0,i,j,k])%2
        n={f:(-1)**t[f[0]]*x for f,x in a.items()}
        native={f:m[f]^(s[f[:2]]*((n[f[1:]]//2)%2))for f in m}
        return n,native
    n,m=one();b,v=one()
    return dict(n2=n,n3=m,n2prime=b,n3prime=v,omega2=omega,s1=s)

def output(data):
    a,b,m,v,w,s=(data[k]for k in ('n2','n2prime','n3','n3prime','omega2','s1'))
    N={f:a[f]+b[f]for f in a};M={}
    for f in m:
        i,j,k,l=f
        M[f]=(m[f]+v[f]+a[i,k,l]*b[i,j,k]+a[i,j,l]*b[j,k,l]+s[i,j]*a[j,k,l]*b[j,k,l])%2
    return N,M

def prepare(data):
    s=data['s1'];t={0:0,**{i:s[0,i]for i in range(1,5)}}
    def one(n,m):
        h={f:(x//2)%2 for f,x in n.items()};a={f:x%2 for f,x in n.items()}
        shift={f:m[f]^(s[f[:2]]*h[f[1:]])for f in m}
        n0={f:(-1)**t[f[0]]*x for f,x in n.items()}
        pad=max(0,(-min(n0.values())+3)//4);lens={f:x+4*pad for f,x in n0.items()}
        return lens,a,h,shift,pad
    A,a,h,m,pad=one(data['n2'],data['n3']);B,b,k,v,pad2=one(data['n2prime'],data['n3prime'])
    return (A,B,m,v,data['omega2'],s),(a,h,b,k,m,v,data['omega2'],s),(pad,pad2)

def dump(data):return {k:{''.join(map(str,f)):v for f,v in sorted(d.items())}for k,d in data.items()}
def load(data):return {k:{tuple(map(int,f)):v for f,v in d.items()}for k,d in data.items()}

def make_even(data,which):
    """Double one sheet cochain and rebuild the same free shifted chain choices."""
    nk='n2'+which;mk='n3'+which;n=data[nk];s=data['s1']
    old={f:data[mk][f]^(s[f[:2]]*((n[f[1:]]//2)%2))for f in data[mk]}
    n={f:2*x for f,x in n.items()};m={f:x for f,x in old.items()if f[0]==0}
    for f in old:
        if f[0]:m[f]=sum(m[(0,)+q]for q in combinations(f,3))%2
    data[nk]=n;data[mk]={f:m[f]^(s[f[:2]]*((n[f[1:]]//2)%2))for f in m}
    return data

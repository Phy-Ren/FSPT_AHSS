# Native 4+1D geometric pairing audit

Run from this directory with Python 3.10+ and NumPy:

```bash
python check_geometry.py
python certify_geometry.py
python check_reference_formulas.py
python check_circuits.py
python check_cleanup.py
python check_reset.py
python check_negative_control.py
```

The first script builds actual directed graphs independently of the mathematical
comparator. The second proves exact source and product identities with arbitrary
allowed local data and both backgrounds. The others replay even psi circuits,
complete two-ended cleanup and native inverse reset. The cleanup graph run takes
about two minutes on one CPU. No finite graph sample is called exhaustive over
75 free bits. Arbitrary integer multiplicities are handled by the local matching
and integer shuffle proofs; the explicit graphs independently test those proofs.

`geometric4.py` retains the fixed ordinary graph from manuscript Fig. 3. Its
central-mode rule is identical in both inputs and the output. The local comparison
with the frozen source is the higher cup `check_n3 cup_2 check_n3`. The source
witness is the old array reference plus that cup. The product witness is its
actual lower-output difference plus the explicitly printed degree-three boundary.
`certify_geometry.json` records the coefficient identities, not a target-selected
matching. The source test has 45 free input bits (30 remain in the final reduced
polynomial); the product and compatibility domains have 42 and 75, respectively.

Every new circuit gate has a psi direction. Pure-gamma components use the original
move; pure-gamma dimers in a mixed component are only initial or final dimers.
The already present point direction is included in the same even operation whenever
necessary. It is never an independent odd operation followed by a repair. The
cleanup leaves all reference dimers in place until the full loop count is checked.
Output indexing names the current physical occupants after the contacts; it does
not execute an additional permutation.

The files under `frozen/` are byte-preserved physical and algebraic inputs, recorded
in `FROZEN_MANIFEST.json`. Historical comments and function names there describe
that archive, not new conventions. The wrapper never edits frozen files or invokes
an archived all-in-one runner that would rewrite its result logs. The full capped
mass and signed-partner check can be repeated by calling `partner_tests(True)` and
`mass_symmetry_tests()` from `frozen/code/symmetry.py`; the resulting receipt is
`mass_checks.json`. The scope is the specified stabilized effective seam model,
with complete partners retained, not uniqueness of a microscopic chiral parent.

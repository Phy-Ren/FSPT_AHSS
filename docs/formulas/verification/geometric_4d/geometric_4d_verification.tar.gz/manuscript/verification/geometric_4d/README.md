# 4+1D geometric pairing checks

Run from this directory with Python 3.10+ and NumPy:

```bash
python check_geometry.py
python certify_geometry.py
python check_reference_formulas.py
python check_circuits.py
python check_cleanup.py
python check_negative_control.py
```

- `check_geometry.py` builds the directed graphs of the F and P moves and
  compares their loop parities with the source and product formulas.
- `certify_geometry.py` proves the source and product identities as exact
  Boolean coefficient identities for arbitrary allowed local data and both
  backgrounds. The source has 45 free input bits (30 remain in the reduced
  polynomial); the product and their compatibility have 42 and 75.
- `check_reference_formulas.py` evaluates the two printed reference polynomials independently.
- `check_circuits.py` replays the even psi circuits.
- `check_cleanup.py` follows the P move until every reference dimer is back
  in place; it takes about two minutes on one CPU.
- `check_negative_control.py` removes the contact on an input where this matters and confirms that the identity then fails.

Each script writes its receipt next to it as JSON. The graph runs are samples;
arbitrary multiplicities are covered by the local matching and integer shuffle
arguments, which the explicit graphs test independently.

`geometric4.py` contains the pairing rule. It keeps the ordinary graph of
Fig. 3 of the manuscript and uses the same rule for the effective Majorana
zero modes on both inputs and the output. The source is compared with the
higher cup $n_3\cup_2n_3$; the product is compared with its lower-output
difference plus the printed degree-three boundary.

Every circuit gate has a psi direction. Pure-gamma components use the original
move, and pure-gamma dimers in a mixed component occur only as initial or final
dimers. Output slots are filled by the modes that occupy them after the moves;
no extra permutation is applied.

The files under `frozen/` are the graph constructor and comparison code,
byte-identical to the author-supplied archive and listed with their hashes in
`FROZEN_MANIFEST.json`. The mass-pairing check of the contacts can be repeated
with `partner_tests(True)` and `mass_symmetry_tests()` from
`frozen/code/symmetry.py`; its receipt is `mass_checks.json`.

The frozen constructor reads the Majorana field as
`c3 = n3 + s1 [floor(n2/2)]_2` (key `n_majorana`, or `n3` in the generators)
and forms the decorated chain `n3` in `frames()`.

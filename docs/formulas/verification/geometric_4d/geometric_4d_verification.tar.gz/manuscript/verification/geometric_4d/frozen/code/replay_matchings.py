#!/usr/bin/env python3
"""Count exported physical directed matchings without consulting any cochains.

Also replay the optional explicit parity-even core circuit. A Pfaffian check
is independent of the transition-loop and dimer-word implementations.
"""
from pathlib import Path
import argparse
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'base4d'))
from kasteleyn import loops, matrix, pfaffian_sign, word_parity
from rotations import rotate_edges


def replay(report: dict, pfaffian: bool = False) -> dict:
    n = report['mode_count']
    edges = report['dimers']
    for name in ('in', 'after_contacts', 'out'):
        flat = [i for edge in edges[name] for i in edge]
        if sorted(flat) != list(range(n)):
            raise ValueError(f'{name}: not a perfect matching of the common mode set')
    result = loops(edges['in'], edges['out'], n)
    assert result['parity_change'] == report['count']['parity_change']
    contacts = loops(edges['in'], edges['after_contacts'], n)['parity_change']
    remaining = loops(edges['after_contacts'], edges['out'], n)['parity_change']
    assert result['parity_change'] == contacts ^ remaining
    result['stage_parities'] = {'contacts': contacts, 'remaining_regrouping': remaining}
    if pfaffian:
        signs = [pfaffian_sign(matrix(edges[s])) if n else 1 for s in ('in', 'out')]
        assert signs[0] * signs[1] == (-1) ** result['parity_change']
        result['independent_pfaffian_signs'] = signs
    if 'core_circuit' in report:
        circuit = report['core_circuit']
        current = circuit['start']
        all_gates = circuit['contact_gates'] + circuit['regrouping_gates']
        for gate in all_gates:
            current = rotate_edges(current, *gate)
        assert set(map(tuple, current)) == set(map(tuple, circuit['end']))
        assert loops(circuit['start'], circuit['end'], circuit['total_mode_count'])['parity_change'] == 0
        result['even_core_gates_replayed'] = len(all_gates)
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('graph', type=Path)
    parser.add_argument('--pfaffian', action='store_true')
    args = parser.parse_args()
    try:
        result = replay(json.loads(args.graph.read_text()), args.pfaffian)
    except (OSError, ValueError, KeyError, TypeError) as exc:
        parser.error(str(exc))
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()

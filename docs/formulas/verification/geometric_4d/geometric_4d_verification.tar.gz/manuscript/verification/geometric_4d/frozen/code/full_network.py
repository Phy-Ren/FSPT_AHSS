"""Full-background 4+1D local network with persistent-mode capped-braid contacts.

The constructor uses integer copy labels, existing mode identities, and actual
pairings only. It never imports a target cochain or a gauge comparator.
"""
from pathlib import Path
import sys
from itertools import combinations
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'base4d'))
from network4 import build as rectangle_build
from data4 import prepare
from kasteleyn import loops,word_parity
from rotations import rotate_edges,compile_even


def image_edges(edges,p):
    return [(p[a],p[b]) for a,b in edges]


def validate(data):
    """Native twisted integer cocycles and original Majorana source, exactly."""
    from cup import op
    expected={'n2':3,'n2prime':3,'n3':4,'n3prime':4,'omega2':3,'s1':2}
    if set(data)!=set(expected):
        raise ValueError('Input must contain n2,n2prime,n3,n3prime,omega2,s1.')
    for key,size in expected.items():
        if set(data[key])!=set(combinations(range(5),size)):
            raise ValueError(f'{key}: every ordered face on 0,...,4 is required.')
        if any(not isinstance(x,int) for x in data[key].values()):
            raise ValueError(f'{key}: integer values are required.')
        if key not in ('n2','n2prime') and any(x not in (0,1) for x in data[key].values()):
            raise ValueError(f'{key}: binary values are required.')
    s=data['s1'];w=data['omega2']
    for f in combinations(range(5),3):
        if sum(s[e] for e in combinations(f,2))%2:raise ValueError('d s1 is nonzero')
    for f in combinations(range(5),4):
        if sum(w[e] for e in combinations(f,3))%2:raise ValueError('d omega2 is nonzero')
    for suffix in ('','prime'):
        n=data['n2'+suffix];m=data['n3'+suffix]
        for f in combinations(range(5),4):
            value=(-1)**s[f[:2]]*n[f[1:]]+sum((-1)**j*n[f[:j]+f[j+1:]] for j in range(1,4))
            if value:raise ValueError(f'n2{suffix}: twisted integer balance fails on {f}')
        sq1=op(n,2,n,2,1,5)
        source=(n[0,1,2]+w[0,1,2])*n[2,3,4]+s[0,1]*sq1[1,2,3,4]
        if (sum(m.values())+source)%2:raise ValueError(f'n3{suffix}: original endpoint equation fails')


def build(data,*,compile_gates=False):
    validate(data)
    args,_,padding=prepare(data)
    upper,lower,_,_,_,_=args
    r=rectangle_build(*args)
    n=r['mode_count'];rho=list(range(n));events=[]
    by_face={}
    old_lower={}
    for m in r['modes']:
        if m['kind']=='cross_exchange':
            by_face[m['block'],tuple(m['face']),m['row']-1,m['column']-1]=m['id']
        elif m['kind']=='intrinsic' and m['group']=='lower':
            old_lower[m['row']-1,m['column']-1]=m['id']
    # Natural-color braid: A is upper 024; B and C are lower 012,234.
    # Chronological order is lexicographic alpha,beta,gamma. Each event acts on
    # the CURRENT occupants of the AB and BC wall slots; AC is retained.
    for alpha in range(upper[0,2,4]):
        for beta in range(lower[0,1,2]):
            for gamma in range(lower[2,3,4]):
                AB=by_face['O',(0,1,2,4),alpha,beta]
                AC=by_face['I',(0,2,3,4),alpha,gamma]
                BC=old_lower[beta,gamma]
                x,y,z=rho[AB],rho[AC],rho[BC]
                events.append(dict(copies=[alpha+1,beta+1,gamma+1],
                    triangles={'A':[0,2,4],'B':[0,1,2],'C':[2,3,4]},
                    slots={'AB':AB,'AC':AC,'BC':BC},before={'AB':x,'AC':y,'BC':z},
                    after={'AB':z,'AC':y,'BC':x},
                    active_operator=['point_real',(x,z)],
                    operation='U=(c+c^dagger)*(chi_AB-chi_BC)/sqrt(2); swap AB,BC and flip point_real'))
                rho[AB],rho[BC]=rho[BC],rho[AB]
    initial=list(map(tuple,r['dimers']['in']))
    straight=list(map(tuple,r['dimers']['out']))
    after_contacts=image_edges(initial,rho)
    final=image_edges(straight,rho)
    for edges in (initial,after_contacts,final):
        assert sorted(x for e in edges for x in e)==list(range(n))
    counted=loops(initial,final,n)
    contact_count=loops(initial,after_contacts,n)
    regroup_count=loops(after_contacts,final,n)
    assert counted['parity_change']==contact_count['parity_change']^regroup_count['parity_change']
    assert contact_count['parity_change']==len(events)%2
    # Origin tags are immutable. Roles/positions after the contact are a separate
    # map; no mode is deleted, and no new output copy is allocated.
    roles=[]
    for slot,identity in enumerate(rho):
        m=r['modes'][slot]
        roles.append(dict(slot=slot,mode_id=identity,current_role={k:v for k,v in m.items() if k!='id'}))
    report=dict(input={key:{''.join(map(str,f)):int(v) for f,v in cochain.items()} for key,cochain in data.items()},schema='full4d-capped-contact-v2',scope='specified stabilized effective seam model, both symmetry backgrounds; standard root' ,
        modes=r['modes'],mode_count=n,padding=padding,
        input_cores=r['input_cores'],exchange_reference=r['exchange_reference'],routes=r['routes'],
        contacts=events,current_slot_modes=rho,current_roles=roles,
        dimers={'in':initial,'after_contacts':after_contacts,'out':final},
        face_steps=[dict(face=f['face'],list=[rho[j]for j in f['list']],
            caps=image_edges(f['caps'],rho),
            survivor=None if f['survivor'] is None else [rho[f['survivor'][0]],f['survivor'][1]],
            output_bit=f['output_bit'])for f in r['face_steps']],
        output_core=image_edges(r['output_core'],rho),count=counted,
        stage_counts={'capped_contacts':contact_count,'remaining_regrouping':regroup_count},
        unrefined_count=r['count'])
    if compile_gates:
        start=initial+[(n,n+1)]
        # Each contact is an explicit SO transformation: AB<->BC and c_R->-c_R.
        cur=start;gates=[]
        for e in events:
            x=e['before']['AB'];z=e['before']['BC']
            target=[]
            for a,b in cur:
                aa=z if a==x else x if a==z else a
                bb=z if b==x else x if b==z else b
                sign=(-1 if a==n else 1)*(-1 if b==n else 1)
                target.append((aa,bb)if sign==1 else(bb,aa))
            local=compile_even(cur,target)
            gates.extend(local);cur=target
        k=len(events)%2
        assert set(cur)==set(after_contacts+[(n,n+1)if k==0 else(n+1,n)])
        end=final+[(n,n+1)if counted['parity_change']==0 else(n+1,n)]
        gates2=compile_even(cur,end)
        replay=start
        for g in gates+gates2:replay=rotate_edges(replay,*g)
        assert set(replay)==set(end)
        report['core_circuit']=dict(start=start,after_contacts=cur,end=end,
            point_modes=[n,n+1],contact_gates=gates,regrouping_gates=gates2,
            point_final_occupation=counted['parity_change'],total_mode_count=n+2)
    return report

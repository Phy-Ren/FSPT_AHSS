"""Candidate 4+1D chronological P graph. Independent of target cochain formulas.

Mode routing is the five-step rectangle pasting specified in stacking_note.tex.
This file constructs its own parity; it does NOT claim compatibility until tested.
"""
from itertools import combinations
from kasteleyn import loops
F=((1,2,3,4),(0,1,3,4),(0,1,2,3),(0,2,3,4),(0,1,2,4)) # B B B A A

def build(a,b,u,v,omega,s,*,options=None):
    opt=dict(ref_reverse=0,O_clock=1,I_clock=0,array_order=0,geometric_source_sign=1)
    if options:opt.update(options)
    nv=5
    for q,k in ((a,2),(b,2),(u,3),(v,3),(omega,2),(s,1)):
        if set(q)!=set(combinations(range(nv),k+1)):raise ValueError('Missing face')
    for q in (u,v,omega,s):
        if any(x not in (0,1) for x in q.values()):raise ValueError("Expected binary chain/background cochain")
    for f in combinations(range(nv),3):
        if sum(s[e] for e in combinations(f,2)) % 2:raise ValueError("ds1 must vanish")
    for f in combinations(range(nv),4):
        if sum(omega[e] for e in combinations(f,3)) % 2:raise ValueError("domega2 must vanish")
    for q in (a,b):
        if any(not isinstance(x,int) for x in q.values()):raise ValueError("Layer counts must be integers")
        if min(q.values())<0:raise ValueError('Use the explicitly declared nonnegative copy reference')
        for f in combinations(range(nv),4):
            if sum((-1)**j*q[f[:j]+f[j+1:]]for j in range(4)):raise ValueError('Integer balance')
    w={f:omega[f]^(s[f[:2]]*s[f[1:]])for f in omega}
    t={0:0,**{i:s[0,i]for i in range(1,5)}}
    modes=[];ordinary={};intr={};proj={};arrays={};start=[];core=[]
    def new(kind,**x):
        j=len(modes);modes.append(dict(id=j,kind=kind,**x));return j
    def array(kind,rows,cols,**x):
        return [[new(kind,row=r+1,column=c+1,**x)for c in range(cols)]for r in range(rows)]
    flat=lambda rows:[j for row in rows for j in row]
    for group,n,chain in (('upper',a,u),('lower',b,v)):
        for k,f in enumerate(F):
            if chain[f]:ordinary[group,f]=new('ordinary',group=group,face=list(f),side='B'if k<3 else'A',transport_bit=int(k<3))
        intr[group]=array('intrinsic',n[0,1,2],n[2,3,4],group=group,cell=[0,1,2,3,4])
        proj[group]=array('projective',w[0,1,2],n[2,3,4],group=group,cell=[0,1,2,3,4])
        seq=[ordinary[group,f]for f in F[:3]if chain[f]]+flat(intr[group])+flat(proj[group])+[ordinary[group,f]for f in F[3:]if chain[f]]
        if len(seq)%2:raise ValueError('Input core has odd number of endpoints')
        pairs=list(zip(seq[::2],seq[1::2]));start.extend(pairs);core.append(dict(group=group,modes=seq,dimers=pairs))
    for k,f in enumerate(F):
        i,j,l,m=f
        arrays['O',f]=array('cross_exchange',a[i,l,m],b[i,j,l],group='reference',face=list(f),side='B'if k<3 else'A',block='O')
        arrays['I',f]=array('cross_exchange',a[i,j,m],b[j,l,m],group='reference',face=list(f),side='B'if k<3 else'A',block='I')
    X=array('cross_intrinsic',a[0,1,2],b[2,3,4],group='output',cell=[0,1,2,3,4],block='upper-lower')
    Y=array('cross_intrinsic',b[0,1,2],a[2,3,4],group='output',cell=[0,1,2,3,4],block='lower-upper')
    # Paste rectangular SOURCE arrays and pair their positions with SINK arrays.
    refs=[];routes=[]
    def connect(src,dst,stage):
        assert len(src)==len(dst)
        edges=[]
        for r1,r2 in zip(src,dst):
            assert len(r1)==len(r2)
            edges.extend(zip(r1,r2))
        refs.extend(edges);routes.append(dict(stage=stage,pairs=[list(x)for x in edges]))
    rows=X+arrays['I',(0,2,3,4)]
    connect(rows[:a[1,2,4]],arrays['I',(1,2,3,4)],1)
    rows=rows[a[1,2,4]:]
    rows=[r1+r2 for r1,r2 in zip(rows,arrays['I',(0,1,2,4)])]
    connect([r[b[1,2,3]:]for r in rows],arrays['I',(0,1,3,4)],2)
    rows=[r[:b[1,2,3]]for r in rows]
    rows=arrays['O',(1,2,3,4)]+rows
    connect(rows[:a[0,1,3]],arrays['I',(0,1,2,3)],3)
    rows=rows[a[0,1,3]:]
    rows=[r1+r2 for r1,r2 in zip(rows,arrays['O',(0,1,3,4)])]
    connect([r[b[0,1,2]:]for r in rows],arrays['O',(0,2,3,4)],4)
    rows=[r[:b[0,1,2]]for r in rows]
    rows=arrays['O',(0,1,2,3)]+rows
    # Y stored in output (lower row, upper column) order: transpose for this routing.
    Ytranspose=[[Y[r][c]for r in range(b[0,1,2])]for c in range(a[2,3,4])]
    connect(rows[:a[2,3,4]],Ytranspose,5)
    connect(rows[a[2,3,4]:],arrays['O',(0,1,2,4)],5)
    if opt['geometric_source_sign']:
        refs=[(j,i) if modes[i].get('side')=='A' else (i,j) for i,j in refs]
    if opt['ref_reverse']:refs=[(j,i)for i,j in refs]
    oriented = {frozenset(e): e for e in refs}
    for route in routes:
        route["endpoint_correspondences"] = route.pop("pairs")
        route["actual_directed_dimers"] = [list(oriented[frozenset(e)]) for e in route["endpoint_correspondences"]]
    start.extend(refs)
    caps=[];survivors={};face_steps=[]
    for k,f in enumerate(F):
        seq=[ordinary[g,f]for g,m in (('upper',u),('lower',v))if m[f]]
        for name in (('O','I')if opt['array_order']==0 else('I','O')):
            for row in arrays[name,f]:
                for x in row:
                    modes[x]['transport_bit']=((modes[x]['column']-1)+opt[name+'_clock'])%2
                    seq.append(x)
        active=len(seq)%2
        paired=seq[:-1]if active else seq;edges=[]
        for x,y in zip(paired[::2],paired[1::2]):
            flip=int(k<3)^(t[f[0]]*(1^modes[x]['transport_bit']^modes[y]['transport_bit']))
            edges.append((y,x)if flip else(x,y))
        caps.extend(edges)
        if active:
            x=seq[-1];theta=t[f[0]]*(modes[x]['transport_bit']^int(k<3));survivors[f]=(x,theta)
        face_steps.append(dict(face=list(f),list=seq,caps=edges,survivor=survivors.get(f),output_bit=active))
    # Tensor-product ordering of combined intrinsic rows/columns: UU,UL / LU,LL.
    joint=[intr['upper'][r]+X[r]for r in range(a[0,1,2])]+[Y[r]+intr['lower'][r]for r in range(b[0,1,2])]
    jp=[proj['upper'][r]+proj['lower'][r]for r in range(w[0,1,2])]
    output_seq=[survivors[f]for f in F[:3]if f in survivors]+[(q,0)for q in flat(joint)+flat(jp)]+[survivors[f]for f in F[3:]if f in survivors]
    if len(output_seq)%2:raise ValueError('Odd final core')
    output=[]
    for (x,ex),(y,ey)in zip(output_seq[::2],output_seq[1::2]):output.append((y,x)if ex^ey else(x,y))
    final=caps+output
    for E in (start,final):
        assert sorted(x for e in E for x in e)==list(range(len(modes))), 'Not a perfect matching'
    counted=loops(start,final,len(modes))
    return dict(semantics='Candidate chronological 4+1D core; routing and its parity must be audited.',options=opt,
                modes=modes,mode_count=len(modes),input_cores=core,face_steps=face_steps,
                exchange_reference=refs,routes=routes,output_core=output,output_order=output_seq,
                dimers={'in':start,'out':final},count=counted)

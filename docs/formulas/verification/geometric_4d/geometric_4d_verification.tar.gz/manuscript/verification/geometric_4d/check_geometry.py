from geometric4 import *
from data4 import generate,prepare,restrict,output
from reference4 import target,delta_B4
from comparison4 import dA3_full
from prior_obstruction.algebra import manuscript,boundary
from itertools import product
import json,time

def run():
    start=time.monotonic();stats=dict(core_states=0,P_graphs=0,F_graphs=0,split_F_graphs=0,compatibility=0)
    for vals in product((0,1),repeat=5):
        for k in range(17):
            if (sum(vals)+k)%2:continue
            faces={j:j for j in range(5)if vals[j]};center=list(range(5,5+k))
            old=[j for j in (0,2,4)if vals[j]]+center+[j for j in(1,3)if vals[j]]
            a=list(zip(old[::2],old[1::2]));b=local_pairs(faces,center)
            m={tuple(j for j in range(5)if j!=i):vals[i]for i in range(5)}
            word=lambda e: sum(x>y for i,x in enumerate([v for q in e for v in q]) for y in [v for q in e for v in q][i+1:])%2
            assert word(a)^word(b)==core_shift(m), (vals,k,a,b)
            stats['core_states']+=1
    def P(data):
        r=change_P(data);_,args,_=prepare(data)
        a,h,b,k,m,v,w,s=args
        from cup import op
        t=op(a,2,b,2,1,5);M={f:(m[f]+v[f]+t[f])%2 for f in m}
        shift=core_shift(m)^core_shift(v)^core_shift(M)
        expected=target(*args)^delta_B4(data)^dA3_full(a,h,b,k,m,v,s)^shift
        assert r['count']['parity_change']==expected,(data,r['count']['parity_change'],expected)
        stats['P_graphs']+=1
        return r['count']['parity_change']
    def F(data,split=False):
        q=Input(2,data['n2'],data['n3'],data['omega2'],data['s1'])
        r=change_F(q,split)
        m={f:data['n3'][f]^(data['s1'][f[:2]]*((data['n2'][f[1:]]//2)%2))for f in data['n3']}
        shift=sum(core_shift(restrict(m,c))for c in combinations(range(6),5))%2
        expected=manuscript(q.N,q.M,q.omega,q.s,2)^boundary(q.N,q.s,2)^shift
        assert r['count']['parity_change']==expected
        stats['split_F_graphs'if split else'F_graphs']+=1
        return r['count']['parity_change']
    for bg in ('zero','w','s','both'):
        for seed in range(128):P(generate(5,bg,seed+31209))
        for seed in range(32):
            data=generate(6,bg,seed+32509)
            a=F(data);assert a==F(data,True)
            n,m=output(data)
            out=dict(n2=n,n3=m,omega2=data['omega2'],s1=data['s1'])
            lower=dict(n2=data['n2prime'],n3=data['n3prime'],omega2=data['omega2'],s1=data['s1'])
            rhs=a^F(lower)^F(out)
            lhs=sum(P({k:restrict(q,c)for k,q in data.items()})for c in combinations(range(6),5))%2
            assert lhs==rhs
            stats['compatibility']+=1
    stats['seconds']=round(time.monotonic()-start,3)
    Path(__file__).with_suffix('.json').write_text(json.dumps(stats,indent=2)+'\n')
    print(json.dumps(stats,indent=2))
if __name__=='__main__':run()

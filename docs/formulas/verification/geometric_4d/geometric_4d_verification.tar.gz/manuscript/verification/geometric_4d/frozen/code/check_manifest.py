#!/usr/bin/env python3
"""Verify immutable release inputs and sources, without hashing mutable run logs."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
manifest=json.loads((ROOT/'MANIFEST.json').read_text())
failures=[]
for rel,expected in manifest['sha256'].items():
    p=ROOT/rel
    if not p.is_file():failures.append('Missing: '+rel)
    elif hashlib.sha256(p.read_bytes()).hexdigest()!=expected:failures.append('Changed: '+rel)
if failures:raise SystemExit('\n'.join(failures))
print(f"All {len(manifest['sha256'])} immutable files match the release checksums.")
print('Mutable verification logs/timings are intentionally excluded; code and case inputs are not.')

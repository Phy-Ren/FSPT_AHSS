"""Use actual prior F diagrams on the right of the compatibility check."""
from itertools import combinations
from data4 import prepare,output,restrict
from network4 import build
from kasteleyn import loops,word_parity,pfaffian_sign,matrix
from prior_obstruction.model import Input
from prior_obstruction.split_model import build_split
from reference4 import target,delta_B4
from comparison4 import dA3_full,residual_T4,dT4
from rotations import repair_and_compile

def P(data,trace=False,compile_gates=False):
    args,math,padding=prepare(data)
    record=build(*args)
    E=record['count']['parity_change']
    assert E==word_parity(record['dimers']['in'])^word_parity(record['dimers']['out'])
    if not trace:return E
    record['padding']=padding
    record['scope']='Candidate full 4D P core. Certified formula equivalence only when at least one sheet cochain is even.'
    record['one_even_input']=all(x%2==0 for x in data['n2'].values())or all(x%2==0 for x in data['n2prime'].values())
    A=dA3_full(*math[:6],math[7]);B=delta_B4(data);T=residual_T4(math[0],math[2]);repo=target(*math)
    record['comparison']=dict(counted=E,repo=repo,DeltaB4=B,dA3=A,unresolved_T4=T,
        exact_diagnostic_residual=E^repo^B^A^T,certified_equivalence_residual=E^repo^B^A)
    assert not record['comparison']['exact_diagnostic_residual']
    if compile_gates:record['core_gate_sequence']=repair_and_compile(record)
    return record

def F(n,m,w,s,trace=False):
    rec=build_split(Input(2,n,m,w,s))
    E=loops(rec['dimers']['in'],rec['dimers']['out'],rec['mode_count'])['parity_change']
    return (E,rec)if trace else E

def compatibility(data):
    N,M=output(data)
    E=[P({k:restrict(v,f)for k,v in data.items()})for f in combinations(range(6),5)]
    O=[F(data['n2'],data['n3'],data['omega2'],data['s1']),
       F(data['n2prime'],data['n3prime'],data['omega2'],data['s1']),F(N,M,data['omega2'],data['s1'])]
    return dict(six_actual_P_counts=E,three_actual_F_counts=O,dE4=sum(E)%2,DeltaO5phys=sum(O)%2,
        defect=(sum(E)+sum(O))%2,predicted_dT4=dT4(data['n2'],data['n2prime']))

"""Independent finite, local permutation-mass contact with fixed partner IDs.

The two mass words are 12,23,12 and 23,12,23. All couplings and all massive
modes are included. No stacking/obstruction polynomial occurs in this module.
"""
import numpy as np

LEFT=((0,1),(1,2),(0,1)); RIGHT=((1,2),(0,1),(1,2))

def swap(i,j):
    q=np.eye(3);q[[i,j]]=q[[j,i]];return q

def hamiltonian(word, lengths=(10,10,10,10), mass=.6, velocity=1., wilson=1., cap=.25, bc=1):
    if len(lengths)!=4 or min(lengths)<2 or mass<=0 or cap<0 or bc not in (-1,1):
        raise ValueError('Invalid contact parameters')
    L=sum(lengths);n=6*L;A=np.zeros((n+4,n+4));M=np.eye(3);Ms=[]
    for j,size in enumerate(lengths):
        if j:M=swap(*word[j-1])@M
        Ms.extend([M.copy()for _ in range(size)])
    def at(x,side,a):return 6*x+3*side+a
    def add(i,j,x):A[i,j]+=x;A[j,i]-=x
    for x,M in enumerate(Ms):
        for a in range(3):
            for b in range(3):add(at(x,0,a),at(x,1,b),mass*M[a,b]+wilson*(a==b))
        y=(x+1)%L;sg=bc if y==0 else 1
        for a in range(3):
            add(at(x,0,a),at(y,0,a),sg*velocity/2)
            add(at(x,1,a),at(y,1,a),-sg*velocity/2)
            add(at(x,0,a),at(y,1,a),-sg*wilson/2)
            add(at(y,0,a),at(x,1,a),-sg*wilson/2)
    # Fixed partner order AB, AC, BC, closing AC. A cap couples only to one
    # lattice site's outgoing and incoming fields immediately before its wall.
    labels={(0,1):0,(0,2):1,(1,2):2};M=np.eye(3);caps=[]
    for (p,q),x0 in zip(word,np.cumsum(lengths)[:-1]):
        root=(np.eye(3)[p]-np.eye(3)[q])/np.sqrt(2)
        v=M.T@root;pair=tuple(np.flatnonzero(abs(v)>1e-8));v*=np.sign(v[pair[0]])
        w=M@v;vec=np.r_[w,-v]/np.sqrt(2);partner=n+labels[pair]
        for a,value in enumerate(vec):add(partner,6*(x0-1)+a,cap*value)
        caps.append(dict(partner=partner,color_pair=list(pair),site=int(x0-1),coefficients=vec.tolist()))
        M=swap(p,q)@M
    v=(np.eye(3)[0]-np.eye(3)[2])/np.sqrt(2);w=M@v
    vec=bc*np.r_[w,-v]/np.sqrt(2)
    for a,value in enumerate(vec):add(n+3,6*(L-1)+a,cap*value)
    caps.append(dict(partner=n+3,color_pair=[0,2],site=L-1,closing_reference=True,coefficients=vec.tolist()))
    return A,caps

def conjugacy(size):
    n=size-4
    perm=[3*(j//3)+(2-j%3)for j in range(n)]+[n+2,n+1,n,n+3]
    signs=np.array([1]*n+[-1]*4)
    # Parent: the 1<->3 transposition on both chiralities has determinant +1.
    # Partners: AB<->BC and four minus signs have determinant -1.
    return perm,signs

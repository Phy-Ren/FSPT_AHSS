#!/usr/bin/env python3
"""Run independent physical graphs, mass models, gauges, and exact certificates.

--full increases numerical graph/partner tests. Exact all-input certificates are
run in either mode. Dimension-specific helpers run in separate processes so
modules named cup/data/etc cannot silently shadow one another.
"""
from pathlib import Path
import argparse,json,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--full',action='store_true')
a=p.parse_args();start=time.monotonic();flag=['--full'] if a.full else []
three=ROOT/'three_dimensional_reference/code'
jobs=[(three/'certify.py',[]), (three/'verify_unfolded.py',flag),
      (three/'symmetry_checks.py',[]),(three/'verify_examples.py',[]),(three/'fock_check.py',[]),
      (ROOT/'code/transport.py',[]),(ROOT/'code/symmetry.py',flag),
      (ROOT/'code/verify_full.py',flag),(ROOT/'code/gauge_checks.py',[]),
      (ROOT/'code/verify_fixture.py',[])]
records=[]
for script,options in jobs:
    rel=str(script.relative_to(ROOT));print(f'\n=== {rel} {" ".join(options)} ===',flush=True)
    before=time.monotonic()
    completed=subprocess.run([sys.executable,str(script),*options],cwd=ROOT,
                             text=True,capture_output=True)
    log_name=rel.replace('/','__').replace('.py','')+('_full' if a.full else '_quick')+'.log'
    (ROOT/'results'/log_name).write_text(completed.stdout+completed.stderr)
    print(completed.stdout,end='')
    if completed.stderr:print(completed.stderr,file=sys.stderr,end='')
    records.append({'script':rel,'arguments':options,'returncode':completed.returncode,
                    'seconds':round(time.monotonic()-before,3),'log':'results/'+log_name})
    if completed.returncode:
        raise SystemExit(f'FAILED: {rel}; retained stdout/stderr in results/{log_name}')
report={'mode':'full'if a.full else 'quick','jobs':records,'all_passed':True,
        'seconds':round(time.monotonic()-start,3),
        'scope':'Specified effective seam/contact model; exact certificates cover all local cochain inputs. No universal microscopic-parent derivation is inferred.'}
(ROOT/'results'/('reproduction_full.json'if a.full else'reproduction_quick.json')).write_text(json.dumps(report,indent=2)+'\n')
print('\nAll requested checks passed. Detailed per-module logs and JSON certificates are in results/.')

"""Independent mathematical target, transcribed from FOUR_DIMENSIONAL.md.
Read 2026-10-08. Not imported by network4.py.
"""
from cup import cup,op,dc,wordop

def plus(*cs):return {f:sum(c[f]for c in cs)%2 for f in cs[0]}
def target(a,h,b,k,m,v,omega,s):
    nv=5;V=tuple(range(nv))
    w=plus(omega,op(s,1,s,1,0,nv));N=plus(a,b)
    t=op(a,2,b,2,1,nv);q=op(a,2,b,2,2,nv)
    dh=dc(h,2,nv);dk=dc(k,2,nv)
    val=cup(m,3,v,3,2)+cup(s,1,op(m,3,v,3,3,nv),3)
    val+=cup(dc(m,3,nv),4,v,3,3)
    val+=cup(plus(m,v),3,t,3,2)+cup(s,1,op(plus(m,v),3,t,3,3,nv),3)
    for word,cs in [
        ('12413423',[a,a,a,b]),('12314132',[a,a,b,b]),('12314324',[a,a,b,b]),
        ('12341321',[a,a,b,b]),('12132413',[a,b,b,b]),('12324214',[a,b,b,b])]:
        val+=wordop(cs,[2]*4,tuple(map(int,word)),V)
    val+=cup(op(w,2,N,2,0,nv),4,t,3,3)
    val+=cup(op(w,2,a,2,2,nv),2,plus(b,q),2)
    val+=cup(op(w,2,b,2,2,nv),2,a,2)
    val+=cup(h,2,plus(k,b),2)+cup(a,2,k,2)+cup(dh,3,k,2,1)+cup(plus(h,k),2,q,2)
    bb=op(b,2,b,2,1,nv)
    val+=cup(op(s,1,a,2,0,nv),3,bb,3,2)
    val+=cup(a,2,op(s,1,b,2,0,nv),3,1)
    val+=cup(q,2,op(s,1,N,2,0,nv),3,1)
    ell={f:(a[(f[0],f[2],f[3])]*b[f[:3]]*(1+a[(f[0],f[1],f[3])]*b[f[1:]]))%2 for f in t}
    inside=plus(op(s,1,q,2,0,nv),op(a,2,dk,3,2,nv),op(q,2,N,2,1,nv),ell)
    val+=cup(s,1,inside,3)
    return val%2

def B4(data):
    # Previous physical F graph source: O5phys = O5repo + d B4.
    n=data['n2'];s=data['s1'];h={f:(v//2)%2 for f,v in n.items()};a={f:v%2 for f,v in n.items()}
    b=op(a,2,a,2,1,5)
    return (s[0,2]*h[0,1,2]*a[2,3,4]
       +s[0,1]*b[1,2,3,4]*(a[1,2,4]+a[2,3,4])
       +s[0,1]*b[0,1,3,4]*a[1,2,3]
       +s[0,2]*b[0,1,2,4]*a[2,3,4])%2

def delta_B4(data):
    from data4 import output
    n,m=output(data)
    return B4(data)^B4(dict(n2=data['n2prime'],s1=data['s1']))^B4(dict(n2=n,s1=data['s1']))

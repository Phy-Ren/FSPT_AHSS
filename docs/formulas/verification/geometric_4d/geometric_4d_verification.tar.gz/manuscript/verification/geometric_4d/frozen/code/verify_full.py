"""Numerical diagrams, exact gates, paired source checks, and negative controls."""
from pathlib import Path
from itertools import combinations
import sys,json,time,random
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'base4d'))
from full_network import build
from data4 import generate,prepare,output,restrict,load
from reference4 import target,delta_B4
from comparison4 import dA3_full
from graph_count4 import counted
from physical_check4 import F
from rotations import rotate_edges
from face_cleanup4 import verify as check_cleanup
from kasteleyn import loops,matrix,pfaffian_sign
from symmetry import transport_edges

def run(full=False):
    start=time.monotonic();N=256 if full else 16;K=64 if full else 4
    bybg=[];contacts=0;gates=0;mat=0;cov=0
    for bi,bg in enumerate(('none','w','s','both')):
      nc=0
      for i in range(N):
        data=generate(5,bg,92000+1000*bi+i)
        rec=build(data,compile_gates=i<16)
        args,q,pad=prepare(data)
        E=rec['count']['parity_change']
        assert E==target(*q)^delta_B4(data)^dA3_full(*q[:6],q[7])
        A,B,m,v,w,s=args
        dig=({f:x%2 for f,x in A.items()},{f:(x//2)%2 for f,x in A.items()},
             {f:x%2 for f,x in B.items()},{f:(x//2)%2 for f,x in B.items()},m,v,w,s)
        assert rec['unrefined_count']['parity_change']==counted(*dig)
        assert E==rec['unrefined_count']['parity_change']^(len(rec['contacts'])%2)
        assert len(rec['current_slot_modes'])==len(set(rec['current_slot_modes']))==rec['mode_count']
        assert all(m['kind'] not in ('output_test','test_copy') for m in rec['modes'])
        contacts+=len(rec['contacts']);nc+=len(rec['contacts'])
        if 'core_circuit' in rec:
            c=rec['core_circuit'];cur=c['start']
            for g in c['contact_gates']+c['regrouping_gates']:cur=rotate_edges(cur,*g)
            assert set(cur)==set(c['end']);gates+=1
            # The same operator must also work when the existing point fermion
            # is occupied. It must not rely on preparing an extra output vacuum.
            cur=c['start'][:-1]+[tuple(reversed(c['start'][-1]))]
            for g in c['contact_gates']+c['regrouping_gates']:cur=rotate_edges(cur,*g)
            expected=c['end'][:-1]+[tuple(reversed(c['end'][-1]))]
            assert set(cur)==set(expected)
        # Complete nonstandard-frame images, not independently restandardized arrows.
        rng=random.Random(i+100*bi);signs=[rng.choice((-1,1))for _ in range(rec['mode_count'])]
        for anti in (0,1):
            ei=transport_edges(rec['dimers']['in'],signs,anti=anti)
            eo=transport_edges(rec['dimers']['out'],signs,anti=anti)
            assert loops(ei,eo,rec['mode_count'])['parity_change']==E;cov+=1
        if i<4 and rec['mode_count']:
            pf=pfaffian_sign(matrix(rec['dimers']['in']))*pfaffian_sign(matrix(rec['dimers']['out']))
            assert pf==(-1)**E;mat+=2
      for i in range(K):
        data=generate(6,bg,73000+1000*bi+i);NN,MM=output(data)
        es=[build({k:restrict(v,f)for k,v in data.items()})['count']['parity_change'] for f in combinations(range(6),5)]
        os=[F(data['n2'],data['n3'],data['omega2'],data['s1']),
            F(data['n2prime'],data['n3prime'],data['omega2'],data['s1']),
            F(NN,MM,data['omega2'],data['s1'])]
        assert (sum(es)+sum(os))%2==0,(bg,i,es,os)
      bybg.append(dict(background=bg,local_graphs=N,literal_contacts=nc,physical_compatibility_inputs=K))
    old=json.loads((ROOT/'cases/previous_bare_failure.json').read_text());d=load(old['input']);NN,MM=output(d)
    es=[];wrong=[]
    for f in combinations(range(6),5):
        r=build({k:restrict(v,f)for k,v in d.items()});es.append(r['count']['parity_change']);wrong.append(r['unrefined_count']['parity_change'])
    os=[F(d['n2'],d['n3'],d['omega2'],d['s1']),F(d['n2prime'],d['n3prime'],d['omega2'],d['s1']),F(NN,MM,d['omega2'],d['s1'])]
    assert(sum(es)+sum(os))%2==0 and(sum(wrong)+sum(os))%2==1
    from certify_full import run as cert
    report=dict(scope='Full-background capped-contact effective model, not a common microscopic chiral-parent theorem',
       tests=bybg,total_local_graphs=4*N,contacts_resolved=contacts,compiled_and_replayed_core_circuits=gates,
       common_frame_image_checks=cov,matrix_pfaffian_evaluations=mat,
       physical_compatibility_inputs=4*K,P_graphs_in_compatibility=24*K,F_graphs_in_compatibility=12*K,
       two_ended_cleanup_tests=check_cleanup(),
       required_negative_control=dict(without_contact=wrong,with_contact=es,physical_F=os),
       exact_certificate=cert(),mismatches=0,seconds=round(time.monotonic()-start,3))
    (ROOT/'results'/('network_full.json'if full else'network_quick.json')).write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items()if k!='exact_certificate'},indent=2));return report
if __name__=='__main__':run('--full'in sys.argv)

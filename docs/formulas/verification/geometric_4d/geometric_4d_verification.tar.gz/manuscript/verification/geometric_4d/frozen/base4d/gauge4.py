"""Explicit pair-boundary in the certified one-even-input sector.
Not a full odd--odd stacking primitive.
"""
from itertools import combinations
from cup import cup
from data4 import restrict

def A3(a,h,b,k,m,v,s):
    """Tetrahedron 0123; native second digits and shifted Majorana cochains."""
    return (m[0,1,2,3]*v[0,1,2,3]+cup(h,2,k,2,1)
            +a[0,1,3]*k[1,2,3]
            +(1+s[0,1])*h[0,1,3]*b[1,2,3])%2

def dA3(a,h,b,k,m,v,s):
    return sum(A3(*(restrict(q,f)for q in (a,h,b,k,m,v,s)))for f in combinations(range(5),4))%2

"""Derived rectangular permutation count for network4 candidate, not a target.
Validated against literal directed matchings before use in symbolic diagnostics.
"""
from itertools import combinations
from digits import D
from network4 import F

def perm(old,new,length):
    at={x:j for j,x in enumerate(new)};v=0
    for i,x in enumerate(old):
        for y in old[i+1:]:
            if at[x]>at[y]:v+=length[x]*length[y]
    return v%2

def counted(a,h,b,k,U,V,omega,s,options=None):
    opt=dict(ref_reverse=0,O_clock=1,I_clock=0,array_order=0,geometric_source_sign=1)
    if options:opt.update(options)
    an={f:D(a[f],h[f])for f in a};bn={f:D(b[f],k[f])for f in b}
    w=(omega[0,1,2]+s[0,1]*s[1,2])%2
    c={}
    for f in F:
        i,j,l,r=f
        c['O',f]=an[i,l,r]*bn[i,j,l];c['I',f]=an[i,j,r]*bn[j,l,r]
    T={f:(U[f]+V[f]+c['O',f].lo+c['I',f].lo)%2 for f in F}
    IU=an[0,1,2]*an[2,3,4];IV=bn[0,1,2]*bn[2,3,4]
    PU=D(w)*an[2,3,4];PV=D(w)*bn[2,3,4]
    X=an[0,1,2]*bn[2,3,4];Y=bn[0,1,2]*an[2,3,4]
    R=IU+IV+X+Y+PU+PV
    val=(IU.lo+PU.lo)*(U[F[3]]+U[F[4]])+(IV.lo+PV.lo)*(V[F[3]]+V[F[4]])+R.lo*(T[F[3]]+T[F[4]])
    val+=(an[0,1,2].hi+bn[0,1,2].hi)*an[2,3,4].lo*bn[2,3,4].lo
    outlen=R+sum((D(T[f])for f in F),D(0))
    val+=outlen.hi+sum(T[f]for f in F[:3])+s[0,1]*T[F[0]]+R.lo
    # Signed word of the six source to six sink reference arrays.
    crossold=[(name,f)for f in F for name in ('O','I')]+['X','Y']
    source=['X',('I',F[3]),('I',F[4]),('O',F[0]),('O',F[1]),('O',F[2])]
    sink=[('I',F[0]),('I',F[1]),('I',F[2]),('O',F[3]),'Y',('O',F[4])]
    lens={lab:c[lab].lo for lab in c};lens.update(X=X.lo,Y=Y.lo)
    val+=perm(crossold,source+sink,lens)
    total=X+c['I',F[3]]+c['I',F[4]]+c['O',F[0]]+c['O',F[1]]+c['O',F[2]]
    val+=total.hi+opt['ref_reverse']*total.lo
    rho=an[0,1,4].hi*(bn[2,3,4].lo*bn[1,2,4].lo+bn[1,2,3].lo*bn[1,3,4].lo)
    carry=an[0,1,4].lo*bn[1,2,3].lo
    rho+=carry*(c['I',F[1]].lo+c['O',F[0]].lo)
    rho+=an[0,3,4].hi*(bn[1,2,3].lo*bn[0,1,3].lo+bn[0,1,2].lo*bn[0,2,3].lo)
    carry=an[0,3,4].lo*bn[0,1,2].lo
    rho+=carry*(c['O',F[3]].lo+c['O',F[2]].lo)
    rho+=an[2,3,4].hi*bn[0,1,2].hi
    val+=rho+opt['geometric_source_sign']*(c['I',F[3]].lo+c['I',F[4]].lo)
    # Folded identity comparison has three cores and residual evaluation dimers.
    old=[];length={}
    for group,M,res in [('u',U,[('iu',IU),('pu',PU)]),('v',V,[('iv',IV),('pv',PV)]),('o',T,[('oiu',IU),('ox',X),('oy',Y),('oiv',IV),('opu',PU),('opv',PV)])]:
        for f in F:label=(group,f);old.append(label);length[label]=M[f]
        for label,L in res:old.append(label);length[label]=L.lo
    for f in F:
        for name in ('O','I'):label=(name,f);old.append(label);length[label]=c[label].lo
    old+=['X','Y'];length.update(X=X.lo,Y=Y.lo)
    new=[]
    for f in F:new.extend([('u',f),('v',f)]+[(name,f)for name in (('O','I')if opt['array_order']==0 else('I','O'))]+[('o',f)])
    new+=['iu','X','Y','iv','pu','pv','oiu','ox','oy','oiv','opu','opv']
    val+=perm(old,new,length)+R.hi+R.lo
    for j,f in enumerate(F):
        size=D(U[f])+D(V[f])+c['O',f]+c['I',f]+D(T[f])
        val+=int(j<3)*size.hi
        if j==0:
            # Explicit antiunitary signs on the nonstandard face only.
            i,l,r,z=f
            pol=an[i,r,z].lo*(bn[i,l,r].hi+opt['O_clock']*bn[i,l,r].lo)
            pol+=an[i,l,z].lo*(bn[l,r,z].hi+opt['I_clock']*bn[l,r,z].lo)
            val+=s[0,1]*(size.hi+U[f]+V[f]+T[f]+pol)
    return val%2

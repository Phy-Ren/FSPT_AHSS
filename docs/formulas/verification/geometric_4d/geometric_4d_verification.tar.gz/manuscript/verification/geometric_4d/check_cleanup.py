"""Retain both ends and all reference bonds through the 4D P cleanup.
The current occupants after physical contacts, not their origin tags, fill the
single-layer output slots. No extra permutation is applied at relabeling.
"""
from geometric4 import *
from data4 import generate,prepare,output
from rotations import rotate_edges
from face_cleanup4 import verify as face_verify
from symmetry import signed_contact_edges,all_matchings,transport_edges,operator_tests,group_tests
from itertools import product
import json,time
stats=dict(graphs=0,quarter_turns=0,contact_steps=0,full_point_occupation_cases=0,negative_controls=0,signed_input_cases=0,central_output_modes=0)
def edge(a,b,sign=1):return (a,b)if sign==1 else(b,a)
def step(state,u,v,q):
    out=rotate_edges(state,u,v,q)
    count=loops(state,out,2*len(state));assert count['parity_change']==0
    assert all(p['kasteleyn']for p in count['loops']);stats['quarter_turns']+=1
    return out

def close(row,data,seed):
    raw,_,_=prepare(data);A,B,m,v,w,s=raw
    modes=row['modes'];rho=row['current_slot_modes'];nextid=len(modes)
    def new():
        nonlocal nextid
        q=nextid;nextid+=1;return q
    ext=[];target=[];gates=[];replace={};phase={};localcaps=[]
    F=((1,2,3,4),(0,1,3,4),(0,1,2,3),(0,2,3,4),(0,1,2,4))
    for j,f in enumerate(F):
        side=int(j<3);t=0 if f[0]==0 else s[0,f[0]];ch=[];active=[]
        for group,bit in(('upper',m[f]),('lower',v[f])):
            loc=next((p['id']for p in modes if p['kind']=='ordinary'and p['group']==group and tuple(p['face'])==f),None)
            if loc is None:loc=new()
            far=new();ch.append(dict(ids=(far,loc)if side else(loc,far),k=(0,1),ref=1))
            if bit:active.append(len(ch)-1)
            else:ext.append(ch[-1]['ids'])
        for p in sorted((p for p in modes if p['kind']=='cross_exchange'and tuple(p['face'])==f),key=lambda p:(p['block']=='I',p['row'],p['column'])):
            loc=rho[p['id']];far=new();k=(p['column']-(p['block']=='I'))%2
            ch.append(dict(ids=(far,loc)if side else(loc,far),k=(k,k),ref=(-1)**t));active.append(len(ch)-1)
        for i,k in zip(active[::2],active[1::2]):
            x,y=ch[i],ch[k];xa,xb=x['ids'];ya,yb=y['ids']
            qa=(-1)**(t*(1^x['k'][0]^y['k'][0]));qb=(-1)**(t*(1^x['k'][1]^y['k'][1]))
            ca,cb=edge(xa,ya,qa),edge(yb,xb,qb)
            localcaps.append(cb if side else ca);ext.append(ca if side else cb)
            gates.append((xb,ya,-qa*x['ref']))
        survivor=active[-1]if len(active)%2 else None
        if survivor is not None:
            x=ch[survivor];carrier=ch[0]['ids'];pair=x['ids'];theta=[(-1)**(t*(x['k'][z]^z))for z in(0,1)]
            replace[pair[side]]=carrier[side];phase[pair[side]]=theta[side]
            far=new();q=(-1)**((seed+j)%2)
            ext.append(edge(pair[1-side],far,q));target.append(edge(carrier[1-side],far,q*theta[1-side]))
            if survivor:gates.extend([(pair[0],carrier[0],theta[0]),(pair[1],carrier[1],theta[1])])
        else:target.append(ch[0]['ids'])
        target.extend(edge(*c['ids'],c['ref'])for c in ch[1:])
    final=list(row['dimers']['out']);assert set(localcaps)<=set(final)
    core=[e for e in final if e not in set(localcaps)]
    target.extend(edge(replace.get(a,a),replace.get(b,b),phase.get(a,1)*phase.get(b,1))for a,b in core)
    ini=list(row['dimers']['in'])+ext;sewn=final+ext
    assert nextid==2*len(sewn)
    before=loops(ini,sewn,nextid)['parity_change'];assert before==row['count']['parity_change']
    cur=sewn
    for g in gates:cur=step(cur,*g)
    assert set(cur)==set(target)
    assert loops(sewn,cur,nextid)['parity_change']==0
    assert loops(ini,cur,nextid)['parity_change']==before
    # Replay every chronological contact with its EXISTING point direction,
    # including current occupants and arbitrary initially occupied point modes.
    for occupation,prime in product((0,1),repeat=2):
        joint=ini+[edge(nextid,nextid+1,(-1)**(occupation^prime)),(nextid+2,nextid+3)]
        for event in row['contacts']:
            x,z=event['before']['AB'],event['before']['BC']
            nxt=signed_contact_edges(joint,x,z,1,nextid)
            assert loops(joint,nxt,nextid+4)['parity_change']==0
            joint=nxt;stats['contact_steps']+=1
        expected=list(row['dimers']['after_contacts'])+ext+[edge(nextid,nextid+1,(-1)**(occupation^prime^(len(row['contacts'])%2))),(nextid+2,nextid+3)]
        assert set(joint)==set(expected)
        out=cur+[edge(nextid,nextid+1,(-1)**(occupation^prime^before)),(nextid+2,nextid+3)]
        assert loops(ini+[edge(nextid,nextid+1,(-1)**occupation),edge(nextid+2,nextid+3,(-1)**prime)],out,nextid+4)['parity_change']==0
        stats['full_point_occupation_cases']+=1
    # The output uses exactly the N2 rectangular index, including cross blocks.
    # Contact motion has already happened; this enumeration applies no gate.
    central=[rho[p['id']]for p in modes if p['kind']in('intrinsic','projective','cross_intrinsic')]
    W=w[0,1,2]^(s[0,1]*s[1,2]);nr=A[0,1,2]+B[0,1,2];nc=A[2,3,4]+B[2,3,4]
    assert len(central)==(nr+W)*nc and len(set(central))==len(central)
    assert all(replace.get(i,i)==i for i in central)
    stats['central_output_modes']+=len(central)
    bad=cur.copy();bad[0]=bad[0][::-1]
    assert loops(sewn,bad,nextid)['parity_change']==1;stats['negative_controls']+=1
    return before

def run():
    st=time.monotonic();stats['face_inventory_cases']=face_verify()
    for bg in('zero','w','s','both'):
        for seed in range(128):
            d=generate(5,bg,40000+seed)
            if seed%2:
                for nk,mk in(('n2','n3'),('n2prime','n3prime')):
                    old=d[nk];d[nk]={f:-x for f,x in old.items()}
                    d[mk]={f:x^(d['s1'][f[:2]]*(old[f[1:]]%2))for f,x in d[mk].items()}
                stats['signed_input_cases']+=1
            r=change_P(d);close(r,d,seed);stats['graphs']+=1
    stats['symmetry_group_cases']=group_tests();stats['joint_contact_operator_cases']=len(operator_tests())
    stats['seconds']=round(time.monotonic()-st,3);stats['status']='PASS'
    Path(__file__).with_suffix('.json').write_text(json.dumps(stats,indent=2)+'\n');print(json.dumps(stats,indent=2))
if __name__=='__main__':run()

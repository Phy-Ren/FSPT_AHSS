from geometric4 import *
from check_cleanup import step,edge,stats
from data4 import generate,prepare
from itertools import product
import json
cases=0
for N,s_face,t,checked in product(range(-32,33),range(2),range(2),range(2)):
    r=s_face*abs(N//2);n=2+2*r;gamma=(0,1);induced=[(2+2*j,3+2*j)for j in range(r)]
    before=([(0,n),(1,n+1)]if checked else[gamma])+induced;current=before;eta=(-1)**t;target=[]
    for j in range(0,r-1,2):
        xa,xb=induced[j];ya,yb=induced[j+1];current=step(current,xb,ya,eta)
        target.extend([edge(xa,ya,eta),edge(yb,xb,eta)])
    if r%2:
        pa,pb=induced[-1]
        if checked:
            current=step(step(current,0,pa,1),1,pb,1);target.extend([gamma,(pa,n),(pb,n+1)])
        else:
            current=step(current,1,pa,eta);target.extend([edge(0,pa,eta),edge(pb,1,eta)])
    else:target.extend([(0,n),(1,n+1)]if checked else[gamma])
    assert set(current)==set(target)and not loops(before,target,2*len(before))['parity_change']
    assert checked^(r%2)==checked^(s_face*((N//2)%2));cases+=1
padding=0
for bg in('zero','w','s','both'):
    for seed in range(16):
        data=generate(6,bg,66000+seed);d=Input(2,data['n2'],data['n3'],data['omega2'],data['s1'])
        base=change_F(d,True)['count']['parity_change']
        for k in(1,2,3):assert change_F(d,True,extra_padding=k)['count']['parity_change']==base;padding+=1
result=dict(status='PASS',native_inverse_reset_cases=cases,even_reset_steps=stats['quarter_turns'],padding_invariance_graphs=padding)
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))

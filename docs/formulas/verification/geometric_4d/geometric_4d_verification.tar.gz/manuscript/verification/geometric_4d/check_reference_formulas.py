"""Independent evaluation of the two displayed reference polynomials.

This is a mathematical transcription check, not a TeX parser. Source/export
checksums separately bind the displayed files to this version of the test.
"""
from geometric4 import *
from certify_sectors import free
from comparison4 import A3_full
from prior_obstruction.algebra import B4_bits
from cup import op
from data4 import restrict
from hashlib import sha256
import json

a,h,b,k,m,v,w,s,t,names=free(5,'neither')
hn={f:h[f]+t[f[0]]*a[f] for f in a}
kn={f:k[f]+t[f[0]]*b[f] for f in b}
aa=op(a,2,a,2,1,5)
g=op(m,3,m,3,2,5)[0,1,2,3,4]
assert g==core_shift(m)
printed_B4=(g+s[0,2]*hn[0,1,2]*a[2,3,4]
    +s[0,1]*aa[1,2,3,4]*(a[1,2,4]+a[2,3,4])
    +s[0,1]*aa[0,1,3,4]*a[1,2,3]
    +s[0,2]*aa[0,1,2,4]*a[2,3,4])
assert printed_B4==B4_bits(a,hn,s)+core_shift(m)
for face in combinations(range(5),4):
    A,H,B,K,M,V,S=(restrict(x,face) for x in(a,hn,b,kn,m,v,s))
    E=op(A,2,B,2,1,4)
    MV={f:M[f]+V[f] for f in M}
    printed_B3=(op(M,3,V,3,3,4)[0,1,2,3]
        +op(E,3,MV,3,3,4)[0,1,2,3]
        +op(H,2,K,2,1,4)[0,1,2,3]
        +A[0,1,3]*K[1,2,3]+(1+S[0,1])*H[0,1,3]*B[1,2,3]
        +S[0,1]*A[0,1,3]*B[0,1,3]*(A[1,2,3]+B[1,2,3]))
    assert printed_B3==A3_full(A,H,B,K,M,V,S)
equations=ROOT.parents[1]/'equations/geometric_4d_20261009'
report=dict(status='PASS',free_bits=len(names),B4_residual_terms=0,
            B3_residual_terms=0,B3_faces=5,
            display_sha256={p.name:sha256(p.read_bytes()).hexdigest()
                            for p in sorted(equations.glob('*.tex'))})
assert len(report['display_sha256'])==2
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))

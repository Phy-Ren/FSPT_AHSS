"""Independent evaluation of the displayed parity obstruction O_5 and the stacking boundary B_3.

This is a mathematical transcription check, not a TeX parser. Source/export
checksums separately bind the displayed files to this version of the test.

1. The printed O_5 = O_5^gamma + O_5^{gamma psi} + O_5^psi of Eqs. (pip_physical_O5_gamma)--
   (pip_physical_O5_pure) equals, as an exact Boolean polynomial on <012345>, the frozen
   network count `counted_bits` plus the inversion parity `core_shift` of the chain ends on the
   six 4-simplices, i.e. the complete directed F-move count.
2. The printed three-cochain B_3 of the stacking count (without the term n_3 cup_3 n'_3, which
   is part of the stacking twister) plus n_3 cup_3 n'_3 equals the frozen `A3_full`.
"""
from geometric4 import *
from certify_sectors import free
from comparison4 import A3_full
from prior_obstruction.algebra import counted_bits, plus
from cup import cup, op, dc
from data4 import restrict
from hashlib import sha256
import json

# ---- 1. the parity obstruction on <012345>
a, h, b, k, m, v, w, s, t, names = free(6, 'neither')
hn = {f: h[f] + t[f[0]] * a[f] for f in a}
nv = 6
top = tuple(range(nv))
W = {f: w[f] + s[f[:2]] * s[f[1:]] for f in w}
dm = dc(m, 3, nv)
O5g = cup(m, 3, m, 3, 1) + cup(s, 1, op(m, 3, m, 3, 2, nv), 4) + cup(w, 2, m, 3)
O5gp = cup(dm, 4, m, 3, 2) + cup(s, 1, op(m, 3, dm, 4, 3, nv), 4)
aa, Wa, a1a, W1W = op(a, 2, a, 2, 0, nv), op(W, 2, a, 2, 0, nv), op(a, 2, a, 2, 1, nv), op(W, 2, W, 2, 1, nv)
zeta = lambda x, y: x[0, 1, 2] * x[0, 2, 3] * y[2, 3, 5] * y[3, 4, 5]
O5p = (zeta(a, a) + cup(hn, 2, a1a, 3) + cup(s, 1, op(hn, 2, a, 2, 0, nv), 4)
       + zeta(W, a) + cup(plus(W1W, op(s, 1, W, 2, 0, nv)), 3, hn, 2)
       + cup(plus(op(W1W, 3, s, 1, 1, nv), op(s, 1, op(s, 1, W, 2, 1, nv), 2, 0, nv)), 3, a, 2)
       + cup(aa, 4, Wa, 4, 3) + cup(s, 1, op(aa, 4, Wa, 4, 4, nv), 4))
printed_O5 = (O5g + O5gp + O5p) % 2
native = plus(m, op(s, 1, hn, 2, 0, nv))
count = (counted_bits(a, hn, native, w, s, 2)
         + sum(core_shift(restrict(m, c)) for c in combinations(top, 5))) % 2
assert printed_O5 == count
o5_bits = len(names)

# ---- 2. the stacking boundary on the five tetrahedra of <01234>
a, h, b, k, m, v, w, s, t, names = free(5, 'neither')
hn = {f: h[f] + t[f[0]] * a[f] for f in a}
kn = {f: k[f] + t[f[0]] * b[f] for f in b}
for face in combinations(range(5), 4):
    A, H, B, K, M, V, S = (restrict(x, face) for x in (a, hn, b, kn, m, v, s))
    E = op(A, 2, B, 2, 1, 4)
    MV = {f: M[f] + V[f] for f in M}
    printed_B3 = (op(E, 3, MV, 3, 3, 4)[0, 1, 2, 3]
                  + op(H, 2, K, 2, 1, 4)[0, 1, 2, 3]
                  + A[0, 1, 3] * K[1, 2, 3] + (1 + S[0, 1]) * H[0, 1, 3] * B[1, 2, 3]
                  + S[0, 1] * A[0, 1, 3] * B[0, 1, 3] * (A[1, 2, 3] + B[1, 2, 3]))
    assert printed_B3 + op(M, 3, V, 3, 3, 4)[0, 1, 2, 3] == A3_full(A, H, B, K, M, V, S)

equations = ROOT.parents[1] / 'equations/reference_4d_20261008'
displays = ('four-dimensional--3-complex-fermion-obstruction--8.tex',
            'four-dimensional--3-complex-fermion-obstruction--9.tex')
report = dict(status='PASS', O5_free_bits=o5_bits, O5_residual_terms=0,
              B3_free_bits=len(names), B3_residual_terms=0, B3_faces=5,
              display_sha256={p: sha256((equations / p).read_bytes()).hexdigest() for p in displays})
Path(__file__).with_suffix('.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))

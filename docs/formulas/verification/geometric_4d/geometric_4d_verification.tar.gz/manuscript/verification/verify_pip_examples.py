"""Rebuild the current 4D examples and audit every printed dimer and label."""
from pathlib import Path
from collections import Counter
import sys,json,re
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'verification/geometric_4d'))
from geometric4 import change_F,word_parity,loops,local_pairs
from prior_obstruction.model import from_json
from kasteleyn import matrix,pfaffian_sign

def labels(g,side='in'):
    answer={}
    for m in g['modes']:
        if m['kind']=='ordinary':answer[m['id']]=r'\gamma_{'+''.join(map(str,m['face']))+','+m['port_type']+'}'
        elif m['kind']=='reset_effective':answer[m['id']]=r'\psi_{'+''.join(map(str,m['face']))+','+str(m['channel'])+','+m['geometric_end']+'}'
        elif m['kind']=='exterior_reference':answer[m['id']]=r'\chi_{\mathrm{ext}}'
    for state in (('out','in')if side=='in'else('in','out')):
        cells={}
        for p in g['placements'][state]:
            if p['source']in('intrinsic','projective'):cells.setdefault(tuple(p['cell']),[]).append(p)
        for c,es in cells.items():
            es.sort(key=lambda p:(p['source']=='projective',p['row'],p['column']))
            for r,p in enumerate(es,1):answer[p['id']]=r'\psi_{'+''.join(map(str,c))+','+str(r)+'}'
    return answer

def example(name,key,letter):
    obj=json.loads((ROOT/'verification'/f'geometric_4d_{name}_expected.json').read_text())
    inp=json.loads((ROOT/'verification'/f'pip_4d_{name}_input.json').read_text())
    fresh=change_F(from_json(inp),True);g=obj['network'];n=g['mode_count']
    for side in('in','out'):assert Counter(map(tuple,fresh['dimers'][side]))==Counter(map(tuple,g['dimers'][side]))
    assert fresh['count']==obj['loops']
    rev={v:k for k,v in labels(g).items()}
    tex=(ROOT/'figures/pip'/f'worked_{letter}.tex').read_text();nodes={}
    for node,label in re.findall(r'\\node\[[^\n]+\] at \(([^)]+)\) \{\$(\\(?:psi|gamma)_\{[^}]+\})\$\};',tex):nodes[node]=rev[label]
    drawn={side:[]for side in('in','out')}
    for side,u,v in re.findall(r'\\draw\[edge(in|out)\] \(([^)]+)\)(?:\s*--\s*|\s*to\[[^]]+\]\s*)\(([^)]+)\);',tex):
        if u in nodes and v in nodes:drawn[side].append((nodes[u],nodes[v]))
    common=set(map(tuple,g['dimers']['in']))&set(map(tuple,g['dimers']['out']))
    changing={side:[tuple(e)for e in g['dimers'][side]if tuple(e)not in common]for side in('in','out')}
    for side in('in','out'):assert Counter(drawn[side])==Counter(changing[side])
    app=(ROOT/'sections/app_pip_physical.tex').read_text()
    block=next(m.group()for m in re.finditer(r'\\begin\{figure\*\}.*?\\end\{figure\*\}',app,re.S)if f'worked_{letter}.pdf'in m.group())
    tab={side:[]for side in('in','out')}
    for line in block.splitlines():
        if r'\longrightarrow'not in line:continue
        for side,col in zip(('in','out'),line.split(' & ')):
            q=re.findall(r'\\(?:psi|gamma)_\{[^}]+\}',col);assert len(q)==2;tab[side].append(tuple(rev[v]for v in q))
    for side in('in','out'):assert Counter(tab[side])==Counter(changing[side])
    geometry_arrows=0
    for side in('in','out'):
        t=(ROOT/'figures/pip'/f'decoration_{key}_{side}.tex').read_text();rs={v:k for k,v in labels(g,side).items()};positions={};last=None
        for line in t.splitlines():
            match=re.search(r'\\fill\[[^]]+\] \(([^)]+)\) circle',line)
            if match:last=match.group(1)
            match=re.search(r'\{\$(\\(?:gamma|psi|chi)_\{.*\})\$\}',line)
            if match:positions[last]=rs[match.group(1)]
        assert set(positions.values())==set(range(n))
        edges=[(positions[a],positions[b])for a,b in re.findall(r'\\draw\[(?:actual|refedge)\] \(([^)]+)\) -- \(([^)]+)\);',t)]
        assert Counter(edges)==Counter(map(tuple,g['dimers'][side]));geometry_arrows+=len(edges)
    count=loops(g['dimers']['in'],g['dimers']['out'],n)['parity_change']
    pf={side:pfaffian_sign(matrix(g['dimers'][side]))for side in('in','out')}
    assert pf['in']*pf['out']==(-1)**count
    assert count==obj['comparison']['manuscript_source']^obj['comparison']['dB4']
    bad=[list(e)for e in g['dimers']['out']];bad[0].reverse()
    assert loops(g['dimers']['in'],bad,n)['parity_change']==count^1
    return dict(name=name,modes=n,geometry_arrows=geometry_arrows,changing_arrows=sum(map(len,changing.values())),parity_change=count,common_dimers=len(common),matrix_pfaffians=pf,negative_control_detected=True)

# An independent transcription of the five four-end configurations in the
# original manuscript Fig. 3, with slot positions from Eq. (ports).
expected={0:{(4,2),(3,1)},1:{(4,2),(0,3)},2:{(4,1),(0,3)},3:{(2,0),(4,1)},4:{(2,0),(3,1)}}
for gap,edges in expected.items():assert set(local_pairs({j:j for j in range(5)if j!=gap},[]))==edges
if __name__=='__main__':
    report=dict(status='PASS',original_four_end_configurations=5,cases=[example('intrinsic','intrinsic','D'),example('full_symmetry','twisted','E')])
    (ROOT/'verification/geometric_printed_examples.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

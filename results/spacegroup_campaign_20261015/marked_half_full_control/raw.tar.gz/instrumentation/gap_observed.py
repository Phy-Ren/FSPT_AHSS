#!/home/user/xyren/AllFSPT_insulator/runtime/bin/python3
"""External diagnostic wrapper; original generated driver remains untouched."""
import hashlib
import json
import os
from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()


def prepare(driver,observer,wrapper,plan):
    driver=Path(driver);observer=Path(observer);wrapper=Path(wrapper)
    original=driver.read_bytes()
    assert driver.name=='driver.g' and not driver.is_symlink()
    assert original.endswith(b'QUIT;\n') and original.count(b'\nQUIT;\n')==1
    observed=driver.with_name('observed_driver.g');proof=driver.with_name('driver_observation.json')
    assert not observed.exists() and not proof.exists()
    assert sha(observer)==plan['observerSHA256'] and sha(wrapper)==plan['wrapperSHA256']
    insertion=('Read('+json.dumps(str(observer))+');;\n').encode()
    changed=original[:-len(b'QUIT;\n')]+insertion+b'QUIT;\n'
    with observed.open('xb') as stream:stream.write(changed)
    record={'originalDriver':str(driver),'originalSHA256':sha(driver),'observedDriver':str(observed),'observedSHA256':sha(observed),
            'observer':str(observer),'observerSHA256':sha(observer),'wrapper':str(wrapper),'wrapperSHA256':sha(wrapper),
            'exactInsertionUTF8':insertion.decode(),'terminalQUITUnchanged':True,'originalBytesUnchanged':driver.read_bytes()==original,
            'solverSourcesModified':False,'originalArguments':sys.argv[1:],'executedArguments':sys.argv[1:-1]+[str(observed)],
            'underlyingLauncher':plan['gapLauncher'],'underlyingBinary':plan['gapBinary'],'diagnosticOnly':True}
    with proof.open('x') as stream:json.dump(record,stream,indent=2,sort_keys=True);stream.write('\n')
    return observed


def main():
    plan=json.loads((HERE/'plan.json').read_text())
    assert sys.argv[1:] and sys.argv[-1].endswith('/driver.g')
    driver=Path(sys.argv[-1]);allowed=[Path('/home/user/xyren/AllFSPT_insulator/runs')/s['tag']/plan['case']/'driver.g' for s in plan['roles'].values()]
    assert driver in allowed
    assert sha(Path(plan['gapBinary']))==plan['gapBinarySHA256'] and sha(Path(plan['gapLauncher']))==plan['gapLauncherSHA256']
    observed=prepare(driver,HERE/'observe_marked_hits.g',Path(__file__),plan)
    os.execv(plan['gapLauncher'],[plan['gapLauncher']]+sys.argv[1:-1]+[str(observed)])


if __name__=='__main__':main()

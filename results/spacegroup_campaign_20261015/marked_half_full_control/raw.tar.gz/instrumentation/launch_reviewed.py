#!/usr/bin/env python3
"""Prepared-only diagnostic pair: root must explicitly authorize execution."""
import concurrent.futures
import datetime
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
BASE = Path('/home/user/xyren/AllFSPT_insulator')
BINARY = Path('/home/user/xyren/software/gap-4.13.1-o2-20261015/gap')
GAP = BINARY.parent / 'gap-o2'
PYTHON = BASE / 'runtime/bin/python3'
CASE = 'spacegroup_141_spin_half'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text())
utc = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()


def write_new(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')


def process(pid):
    p = Path('/proc') / str(pid)
    assert p.stat().st_uid == os.getuid()
    stat = (p / 'stat').read_text().rsplit(')', 1)[1].split()
    return {'pid': pid, 'startTicks': stat[19], 'state': stat[0],
            'argv': [x.decode() for x in (p / 'cmdline').read_bytes().split(b'\0') if x],
            'rssKiB': int((p / 'statm').read_text().split()[1]) * os.sysconf('SC_PAGE_SIZE') // 1024,
            'executable': os.readlink(str(p / 'exe'))}


def capacity(plan):
    memory = {s.split(':')[0]: int(s.split()[1]) for s in Path('/proc/meminfo').read_text().splitlines() if len(s.split()) >= 2}
    inventory, unreadable = [], []
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():
            continue
        try:
            if p.stat().st_uid != os.getuid():
                continue
            try:
                executable = os.readlink(str(p / 'exe'))
            except PermissionError:
                comm = (p / 'comm').read_text().strip()
                assert comm == 'sshd', ('Unknown unreadable own executable', int(p.name), comm)
                unreadable.append({'pid': int(p.name), 'comm': comm})
                continue
            if executable != str(BINARY):
                continue
            observed = process(int(p.name))
        except (FileNotFoundError, ProcessLookupError):
            continue
        driver = observed['argv'][-1]
        allowed = dict(plan['knownExistingDrivers'])
        allowed.update({str(BASE/'runs'/spec['tag']/CASE/'observed_driver.g'):16 for spec in plan['roles'].values()})
        assert driver in allowed, ('Unexpected existing GAP', observed)
        cap = allowed[driver]
        assert observed['argv'][observed['argv'].index('-K') + 1] == str(cap) + 'g'
        observed['configuredCapGiB'] = cap
        inventory.append(observed)
    assert len({p['argv'][-1] for p in inventory}) == len(inventory)
    # Reserve the two admitted 32g jobs even if they finish between observations.
    configured = sum(plan['knownExistingDrivers'].values()) + 32
    rss = sum(p['rssKiB'] for p in inventory)
    non_gap = max(0, memory['MemTotal'] - memory['MemFree'] - rss)
    load = list(os.getloadavg())
    assert load[0] < 4 and memory['MemFree'] > 64 * 1024**2, (load, memory)
    assert configured * 1024**2 + non_gap + 8 * 1024**2 < memory['MemTotal']
    return {'utc': utc(), 'host': socket.gethostname(), 'loadAverage': load,
            'memoryKiB': memory, 'existingGAPProcesses': inventory,
            'unreadableOwnNonGAPProcesses': unreadable,
            'reservedExistingCapsGiB': sum(plan['knownExistingDrivers'].values()),
            'additionalCapsGiB': 32, 'allConfiguredCapsGiB': configured,
            'nonGAPUsedUpperBoundKiB': non_gap, 'nonGAPHeadroomGiB': 8,
            'configuredCapBudgetFits': True}


def source_check(spec, common):
    source = Path(spec['snapshot'])
    assert sha(HERE/(spec['role']+'_worker_preflight.g')) == spec['workerPreflightSHA256']
    actual = {}
    for directory, suffixes in [('gap', {'.g'}), ('insulator', {'.py', '.json', '.cpp', '.h'}), ('scripts', {'.py'})]:
        for p in (source / directory).rglob('*'):
            if p.is_file() and p.suffix in suffixes:
                actual[str(p.relative_to(source))] = sha(p)
    assert actual == spec['source']['files']
    assert hashlib.sha256(json.dumps(actual, sort_keys=True, separators=(',', ':')).encode()).hexdigest() == spec['source']['sha256']
    assert sha(source / 'insulator_catalog/generated' / (CASE + '.json')) == common['inputSHA256']
    assert sha(source / 'insulator/_compiled/u1_dag_vm.so') == common['librarySHA256']
    for name, digest in spec['snapshotFiles'].items():
        assert sha(source / name) == digest, name
    return source


def main():
    assert sys.argv[1:] == ['--execute-after-root-review']
    assert socket.gethostname().split('.')[0] == 'n08'
    assert Path(sys.executable).resolve() == PYTHON.resolve() and sys.version_info >= (3, 8)
    plan = read(HERE / 'plan.json')
    assert plan['candidateFrozen'] is True and plan['candidatePeerReviewPassed'] is True
    assert plan['diagnosticOnly'] is True and plan['selectedForCatalogue'] is False
    assert plan['baseCommit'] == 'd3b2dcc6fe9f4ecda3e957d74edae2012ac46198'
    assert sha(BINARY) == plan['gapBinarySHA256'] and sha(GAP) == plan['gapLauncherSHA256']
    assert sha(HERE/'gap_observed.py') == plan['wrapperSHA256']
    assert sha(HERE/'observe_marked_hits.g') == plan['observerSHA256']
    admission = BASE / 'runs/sg141-marked-half-pair-admission-20261015.json'
    assert not admission.exists()
    states = {}
    for role, spec in plan['roles'].items():
        output = BASE / 'runs' / spec['tag']
        assert not list((BASE / 'runs').glob(spec['tag'] + '*'))
        source = source_check(spec, plan)
        env = dict(os.environ, LC_ALL='C', LANG='C', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
                   U1_DAG_MODE='auto', U1_DAG_LIBRARY=str(source / 'insulator/_compiled/u1_dag_vm.so'), PYTHONDONTWRITEBYTECODE='1')
        env['PATH'] = str(BASE / 'runtime/bin') + ':' + env['PATH']
        ping = subprocess.run([str(GAP), '-q', '-b', '--quitonbreak', str(HERE / (role + '_worker_preflight.g'))],
                              env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True, timeout=30)
        assert ping.returncode == 0 and 'U1_WORKER_PREFLIGHT_PYTHON ' + str(PYTHON) in ping.stdout
        assert 'U1_WORKER_PREFLIGHT_PING_PASS' in ping.stdout
        states[role] = (source, output, env, {'returncode': ping.returncode, 'stdout': ping.stdout, 'stderr': ping.stderr})
    a, b = [spec['source']['files'] for spec in plan['roles'].values()]
    changed = sorted(n for n in set(a) | set(b) if a.get(n) != b.get(n))
    assert changed == ['gap/backend_half_phase.g', 'gap/classification.g']
    resources = capacity(plan)
    write_new(admission, {'utc': utc(), 'resources': resources, 'planSHA256': sha(HERE / 'plan.json'),
                         'launcherSHA256': sha(Path(__file__)), 'exactRuntimeDifferences': changed,
                         'workerPings': {k: v[3] for k, v in states.items()},
                         'existingRunsModified': False, 'signalsSent': False})

    def run_one(role):
        source, output, env, ping = states[role]
        command = [str(PYTHON), str(source / 'scripts/classify.py'), '--family', 'spacegroup', '--case', CASE,
                   '--output', str(output), '--gap', str(HERE/'gap_observed.py'), '--jobs', '1', '--memory', '16g', '--timeout', '2400',
                   '--charge-primary', 'native', '--phase-class', 'cycles', '--closed-charge-source', 'certified',
                   '--vacuum-reduction', 'canonical']
        timed = ['/usr/bin/time', '-v', '-o', str(output) + '-resources.txt'] + command
        start = time.monotonic()
        with Path(str(output) + '-runner.stdout.log').open('x') as out, Path(str(output) + '-runner.stderr.log').open('x') as err:
            child = subprocess.Popen(timed, cwd=source, env=env, stdin=subprocess.DEVNULL, stdout=out, stderr=err, start_new_session=True)
            launch = {'schema': 'u1-marked-half-benchmark-v1', 'role': role, 'tag': plan['roles'][role]['tag'],
                      'command': command, 'timedCommand': timed, 'timeProcess': process(child.pid), 'launchUTC': utc(),
                      'source': plan['roles'][role]['source'], 'inputSHA256': plan['inputSHA256'],
                      'sourceSnapshot': str(source), 'librarySHA256': plan['librarySHA256'],
                      'gapBinarySHA256': sha(BINARY), 'gapLauncherSHA256': sha(GAP),
                      'pythonExecutableSHA256': sha(PYTHON), 'pythonVersion': sys.version,
                      'environment': {k: env[k] for k in ['PATH', 'LC_ALL', 'LANG', 'OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'U1_DAG_MODE', 'U1_DAG_LIBRARY', 'PYTHONDONTWRITEBYTECODE']},
                      'workerPreflight': ping, 'admissionRecord': str(admission), 'admissionSHA256': sha(admission),
                      'planSHA256': sha(HERE / 'plan.json'), 'diagnosticOnly': True, 'selectedForCatalogue': False}
            write_new(Path(str(output) + '-launch.json'), launch)
            print(json.dumps({'role': role, 'timePID': child.pid, 'run': str(output)}), flush=True)
            observed_driver = str(output/CASE/'observed_driver.g')
            actual = None
            for unused in range(300):
                for pp in Path('/proc').iterdir():
                    if not pp.name.isdigit():
                        continue
                    try:
                        if pp.stat().st_uid != os.getuid():
                            continue
                        args = [x.decode() for x in (pp/'cmdline').read_bytes().split(b'\0') if x]
                        if args and args[-1] == observed_driver and os.readlink(str(pp/'exe')) == str(BINARY):
                            actual = process(int(pp.name)); break
                    except (FileNotFoundError, ProcessLookupError, PermissionError):
                        continue
                if actual is not None:
                    break
                if child.poll() is not None:
                    raise RuntimeError('Diagnostic ended before exact executed-driver observation')
                time.sleep(.1)
            assert actual is not None, 'Actual GAP identity not observed; leave launched run untouched'
            write_new(Path(str(output)+'-process-observation.json'),
                      {'utc':utc(), 'actualGAP':actual, 'driverObservationSHA256':sha(output/CASE/'driver_observation.json'),
                       'originalDriverSHA256':sha(output/CASE/'driver.g'), 'executedDriverSHA256':sha(output/CASE/'observed_driver.g'),
                       'actualExecutableSHA256':sha(BINARY), 'signalsSent':False})
            code = child.wait()
        finish = dict(launch, exitCode=code, elapsedSeconds=time.monotonic() - start, finishedUTC=utc())
        write_new(Path(str(output) + '-finished.json'), finish)
        print(json.dumps({'role': role, 'exitCode': code, 'elapsedSeconds': finish['elapsedSeconds']}), flush=True)
        return code

    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        codes = list(pool.map(run_one, ['baseline', 'candidate']))
    return 0 if all(x == 0 for x in codes) else 1


if __name__ == '__main__':
    raise SystemExit(main())

# Diagnostic observation only: no context, result or source mutation.
(function()
  local ctx,hits,bound,complete;
  hits:=0;bound:=false;complete:=false;
  if IsBoundGlobal("c") then
    ctx:=ValueGlobal("c");
    if IsRecord(ctx) and IsBound(ctx.markedHalfDoubleHits) then
      hits:=ctx.markedHalfDoubleHits;bound:=true;
      if not IsInt(hits) or hits<0 then Error("Invalid marked-double observation");fi;
    fi;
  fi;
  if IsBoundGlobal("result") and IsRecord(ValueGlobal("result")) then
    complete:=IsBound(ValueGlobal("result").nativeChainIdentitiesVerified)
      and ValueGlobal("result").nativeChainIdentitiesVerified=true;
  fi;
  Print("U1_MARKED_HALF_OBSERVATION hits=",hits," counterBound=",bound,
        " completedCertificate=",complete,"\n");
end)();

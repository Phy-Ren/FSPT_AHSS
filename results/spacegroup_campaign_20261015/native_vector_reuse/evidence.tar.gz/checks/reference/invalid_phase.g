OnBreak:=function() Where(20);QUIT_GAP(1);end;;
U1_ROOT:="/home/xingyu/AllFSPT_reviews/duplicate_native_reuse_20261015/reference";;
U1_FORMULA_PYTHON:="/usr/bin/python3";;
Read(Concatenation(U1_ROOT,"/gap/load.g"));;
SaveAudit:=function(data) local f;f:=OutputTextFile("/home/xingyu/AllFSPT_reviews/duplicate_native_reuse_20261015/checks/reference/invalid_phase.json",false);SetPrintFormattingStatus(f,false);WriteLine(f,U1JSON(data));CloseStream(f);end;;

c:=U1CyclicContext(2,0,0,0);;one:=Identity(c.G);;
bad:=function(g,h,j)if one in [g,h,j] then return 0;fi;return 1/3;end;;
U1ReduceVacuum(c,2,rec(sheet:=U1Zero,charge:=U1Zero,phase:=bad));;QUIT_GAP(0);

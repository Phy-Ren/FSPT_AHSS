OnBreak:=function() Where(20);QUIT_GAP(1);end;;
U1_ROOT:="/home/xingyu/AllFSPT_reviews/duplicate_native_reuse_20261015/reference";;
U1_FORMULA_PYTHON:="/usr/bin/python3";;
Read(Concatenation(U1_ROOT,"/gap/load.g"));;
SaveAudit:=function(data) local f;f:=OutputTextFile("/home/xingyu/AllFSPT_reviews/duplicate_native_reuse_20261015/checks/reference/classifications.json",false);SetPrintFormattingStatus(f,false);WriteLine(f,U1JSON(data));CloseStream(f);end;;

BindGlobal("AuditOriginalNative",U1Native);;
AuditCounts:=rec(native:=0,nonzeroNative:=0,reductions:=0,chargeReductions:=0);;
MakeReadWriteGlobal("U1Native");;
U1Native:=function(c,k,coeff,f)
 AuditCounts.native:=AuditCounts.native+1;
 if f<>U1Zero then AuditCounts.nonzeroNative:=AuditCounts.nonzeroNative+1;fi;
 return AuditOriginalNative(c,k,coeff,f);
end;;MakeReadOnlyGlobal("U1Native");;
BindGlobal("AuditOriginalReduce",U1ReduceVacuum);;
MakeReadWriteGlobal("U1ReduceVacuum");;
U1ReduceVacuum:=function(c,d,a)
 AuditCounts.reductions:=AuditCounts.reductions+1;
 return AuditOriginalReduce(c,d,a);
end;;MakeReadOnlyGlobal("U1ReduceVacuum");;
BindGlobal("AuditOriginalClassify",U1Classify);;
MakeReadWriteGlobal("U1Classify");;
U1Classify:=function(args...)
 local result;
 result:=CallFuncList(AuditOriginalClassify,args);
 AuditCounts.chargeReductions:=AuditCounts.chargeReductions+
   Number(result.witnesses,w->w.kind in ["CI-root","incoming-charge-gauge","incoming-CI-gauge"]);
 return result;
end;;MakeReadOnlyGlobal("U1Classify");;
AuditReset:=function()
 AuditCounts:=rec(native:=0,nonzeroNative:=0,reductions:=0,chargeReductions:=0);
end;;

rows:=[];;
for spec in [[2,0,0,0,2],[3,0,0,0,2],[4,0,0,0,2],
             [2,0,0,0,3],[2,0,1,1/2,3],[2,1,0,1/2,3],[2,1,1,0,3]] do
 c:=U1CyclicContext(spec[1],spec[2],spec[3],spec[4]);;AuditReset();;
 result:=U1Classify(c,spec[5]);;
 Add(rows,rec(name:=String(spec),result:=result,counts:=ShallowCopy(AuditCounts)));;
od;
c:=U1CyclicContext(2,0,0,1/2);;AuditReset();;
result:=U1Classify(c,2,rec(uniformIQH:=true));;
Add(rows,rec(name:="uniform-C2-half-extension",result:=result,counts:=ShallowCopy(AuditCounts)));;
data:=rec(multiplication:=[[0,1,2,3],[1,0,3,2],[2,3,0,1],[3,2,1,0]],identity_index:=0,
 s:=[0,1,0,1],rho:=[0,0,1,1],
 omega:=[["0","0","0","0"],["0","1/2","0","1/2"],["0","0","0","0"],["0","1/2","0","1/2"]]);;
c:=U1FiniteContext(data,6);;AuditReset();;result:=U1Classify(c,3);;
Add(rows,rec(name:="V4-independent-signs",result:=result,counts:=ShallowCopy(AuditCounts)));;
Read(Concatenation(U1_ROOT,"/insulator_catalog/generated/spacegroup_004_spinless.g"));;
c:=U1AffineContext(U1_INPUT,6);;AuditReset();;result:=U1Classify(c,3);;
Add(rows,rec(name:="SG4-spinless-full-affine",result:=result,counts:=ShallowCopy(AuditCounts)));;
SaveAudit(rows);;QUIT_GAP(0);

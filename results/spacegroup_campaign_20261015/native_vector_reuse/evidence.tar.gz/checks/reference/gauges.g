OnBreak:=function() Where(20);QUIT_GAP(1);end;;
U1_ROOT:="/home/xingyu/AllFSPT_reviews/duplicate_native_reuse_20261015/reference";;
U1_FORMULA_PYTHON:="/usr/bin/python3";;
Read(Concatenation(U1_ROOT,"/gap/load.g"));;
SaveAudit:=function(data) local f;f:=OutputTextFile("/home/xingyu/AllFSPT_reviews/duplicate_native_reuse_20261015/checks/reference/gauges.json",false);SetPrintFormattingStatus(f,false);WriteLine(f,U1JSON(data));CloseStream(f);end;;

BindGlobal("AuditOriginalNative",U1Native);;
AuditCounts:=rec(native:=0,nonzeroNative:=0,reductions:=0,chargeReductions:=0);;
MakeReadWriteGlobal("U1Native");;
U1Native:=function(c,k,coeff,f)
 AuditCounts.native:=AuditCounts.native+1;
 if f<>U1Zero then AuditCounts.nonzeroNative:=AuditCounts.nonzeroNative+1;fi;
 return AuditOriginalNative(c,k,coeff,f);
end;;MakeReadOnlyGlobal("U1Native");;
BindGlobal("AuditOriginalReduce",U1ReduceVacuum);;
MakeReadWriteGlobal("U1ReduceVacuum");;
U1ReduceVacuum:=function(c,d,a)
 AuditCounts.reductions:=AuditCounts.reductions+1;
 return AuditOriginalReduce(c,d,a);
end;;MakeReadOnlyGlobal("U1ReduceVacuum");;
BindGlobal("AuditOriginalClassify",U1Classify);;
MakeReadWriteGlobal("U1Classify");;
U1Classify:=function(args...)
 local result;
 result:=CallFuncList(AuditOriginalClassify,args);
 AuditCounts.chargeReductions:=AuditCounts.chargeReductions+
   Number(result.witnesses,w->w.kind in ["CI-root","incoming-charge-gauge","incoming-CI-gauge"]);
 return result;
end;;MakeReadOnlyGlobal("U1Classify");;
AuditReset:=function()
 AuditCounts:=rec(native:=0,nonzeroNative:=0,reductions:=0,chargeReductions:=0);
end;;

rows:=[];;
for spec in [[0,0],[0,1],[1,0],[1,1]] do
 data:=rec(multiplication:=[[0,1,2,3],[1,0,3,2],[2,3,0,1],[3,2,1,0]],identity_index:=0,
 s:=List([0,1,0,1],x->spec[1]*x),rho:=List([0,0,1,1],x->spec[2]*x),
 omega:=[["0","0","0","0"],["0","1/2","0","1/2"],["0","0","0","0"],["0","1/2","0","1/2"]]);;
 c:=U1FiniteContext(data,6);;one:=Identity(c.G);;els:=Filtered(Elements(c.G),g->g<>one);;
 for d in [2,3] do
  if d=2 then
   u:=U1Zero;;v:=function(g)if g=one then return 0;fi;return 2*c.elementIndex(g)-7;end;;
  else
   if spec[1]=1 then u:=function()return -3;end;else u:=U1Zero;fi;
   v:=function(g,h)if g=one or h=one then return 0;fi;return 2*c.elementIndex(g)-3*c.elementIndex(h)+1;end;;
  fi;
  a:=U1Gauge(c,d,U1Vacuum(),u,v);;
  for mode in ["canonical","reference"] do
   c.vacuumReductionMode:=mode;;AuditReset();;
   phase:=U1ReduceVacuum(c,d,a);;
   Add(rows,rec(signs:=spec,dimension:=d,mode:=mode,
    values:=List(Tuples(els,d+1),xs->CallFuncList(phase,xs)),
    witness:=c.reductionWitnesses[Length(c.reductionWitnesses)],counts:=ShallowCopy(AuditCounts)));
  od;
 od;
od;
SaveAudit(rows);;QUIT_GAP(0);

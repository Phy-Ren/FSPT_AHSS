"""Read-only reference/candidate controls for adjacent checked-vector reuse."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import unittest

BASE = Path(__file__).resolve().parent
RESULTS = BASE / 'checks'

COUNTERS = r'''
BindGlobal("AuditOriginalNative",U1Native);;
AuditCounts:=rec(native:=0,nonzeroNative:=0,reductions:=0,chargeReductions:=0);;
MakeReadWriteGlobal("U1Native");;
U1Native:=function(c,k,coeff,f)
 AuditCounts.native:=AuditCounts.native+1;
 if f<>U1Zero then AuditCounts.nonzeroNative:=AuditCounts.nonzeroNative+1;fi;
 return AuditOriginalNative(c,k,coeff,f);
end;;MakeReadOnlyGlobal("U1Native");;
BindGlobal("AuditOriginalReduce",U1ReduceVacuum);;
MakeReadWriteGlobal("U1ReduceVacuum");;
U1ReduceVacuum:=function(c,d,a)
 AuditCounts.reductions:=AuditCounts.reductions+1;
 return AuditOriginalReduce(c,d,a);
end;;MakeReadOnlyGlobal("U1ReduceVacuum");;
BindGlobal("AuditOriginalClassify",U1Classify);;
MakeReadWriteGlobal("U1Classify");;
U1Classify:=function(args...)
 local result;
 result:=CallFuncList(AuditOriginalClassify,args);
 AuditCounts.chargeReductions:=AuditCounts.chargeReductions+
   Number(result.witnesses,w->w.kind in ["CI-root","incoming-charge-gauge","incoming-CI-gauge"]);
 return result;
end;;MakeReadOnlyGlobal("U1Classify");;
AuditReset:=function()
 AuditCounts:=rec(native:=0,nonzeroNative:=0,reductions:=0,chargeReductions:=0);
end;;
'''

CLASSIFICATIONS = COUNTERS + r'''
rows:=[];;
for spec in [[2,0,0,0,2],[3,0,0,0,2],[4,0,0,0,2],
             [2,0,0,0,3],[2,0,1,1/2,3],[2,1,0,1/2,3],[2,1,1,0,3]] do
 c:=U1CyclicContext(spec[1],spec[2],spec[3],spec[4]);;AuditReset();;
 result:=U1Classify(c,spec[5]);;
 Add(rows,rec(name:=String(spec),result:=result,counts:=ShallowCopy(AuditCounts)));;
od;
c:=U1CyclicContext(2,0,0,1/2);;AuditReset();;
result:=U1Classify(c,2,rec(uniformIQH:=true));;
Add(rows,rec(name:="uniform-C2-half-extension",result:=result,counts:=ShallowCopy(AuditCounts)));;
data:=rec(multiplication:=[[0,1,2,3],[1,0,3,2],[2,3,0,1],[3,2,1,0]],identity_index:=0,
 s:=[0,1,0,1],rho:=[0,0,1,1],
 omega:=[["0","0","0","0"],["0","1/2","0","1/2"],["0","0","0","0"],["0","1/2","0","1/2"]]);;
c:=U1FiniteContext(data,6);;AuditReset();;result:=U1Classify(c,3);;
Add(rows,rec(name:="V4-independent-signs",result:=result,counts:=ShallowCopy(AuditCounts)));;
Read(Concatenation(U1_ROOT,"/insulator_catalog/generated/spacegroup_004_spinless.g"));;
c:=U1AffineContext(U1_INPUT,6);;AuditReset();;result:=U1Classify(c,3);;
Add(rows,rec(name:="SG4-spinless-full-affine",result:=result,counts:=ShallowCopy(AuditCounts)));;
SaveAudit(rows);;QUIT_GAP(0);
'''

GAUGES = COUNTERS + r'''
rows:=[];;
for spec in [[0,0],[0,1],[1,0],[1,1]] do
 data:=rec(multiplication:=[[0,1,2,3],[1,0,3,2],[2,3,0,1],[3,2,1,0]],identity_index:=0,
 s:=List([0,1,0,1],x->spec[1]*x),rho:=List([0,0,1,1],x->spec[2]*x),
 omega:=[["0","0","0","0"],["0","1/2","0","1/2"],["0","0","0","0"],["0","1/2","0","1/2"]]);;
 c:=U1FiniteContext(data,6);;one:=Identity(c.G);;els:=Filtered(Elements(c.G),g->g<>one);;
 for d in [2,3] do
  if d=2 then
   u:=U1Zero;;v:=function(g)if g=one then return 0;fi;return 2*c.elementIndex(g)-7;end;;
  else
   if spec[1]=1 then u:=function()return -3;end;else u:=U1Zero;fi;
   v:=function(g,h)if g=one or h=one then return 0;fi;return 2*c.elementIndex(g)-3*c.elementIndex(h)+1;end;;
  fi;
  a:=U1Gauge(c,d,U1Vacuum(),u,v);;
  for mode in ["canonical","reference"] do
   c.vacuumReductionMode:=mode;;AuditReset();;
   phase:=U1ReduceVacuum(c,d,a);;
   Add(rows,rec(signs:=spec,dimension:=d,mode:=mode,
    values:=List(Tuples(els,d+1),xs->CallFuncList(phase,xs)),
    witness:=c.reductionWitnesses[Length(c.reductionWitnesses)],counts:=ShallowCopy(AuditCounts)));
  od;
 od;
od;
SaveAudit(rows);;QUIT_GAP(0);
'''


def run_gap(tree, label, program, timeout=120, expect_failure=False):
    folder = RESULTS / tree
    folder.mkdir(parents=True, exist_ok=True)
    output = folder / (label + '.json')
    if output.exists():
        output.unlink()
    path = folder / (label + '.g')
    path.write_text(
        'OnBreak:=function() Where(20);QUIT_GAP(1);end;;\n'
        'U1_ROOT:=' + json.dumps(str(BASE / tree)) + ';;\n'
        'U1_FORMULA_PYTHON:=' + json.dumps(os.path.abspath(sys.executable)) + ';;\n'
        'Read(Concatenation(U1_ROOT,"/gap/load.g"));;\n'
        'SaveAudit:=function(data) local f;f:=OutputTextFile(' + json.dumps(str(output)) + ',false);'
        'SetPrintFormattingStatus(f,false);WriteLine(f,U1JSON(data));CloseStream(f);end;;\n'
        + program)
    # Both trees use the exact integer-DAG Python evaluator, without a native VM.
    env = dict(os.environ, U1_DAG_MODE='python')
    run = subprocess.run(['gap', '-q', '-b', '--quitonbreak', str(path)],
                         capture_output=True, timeout=timeout, env=env)
    (folder / (label + '.stdout')).write_bytes(run.stdout)
    (folder / (label + '.stderr')).write_bytes(run.stderr)
    (folder / (label + '.process.json')).write_text(json.dumps({
        'command': run.args, 'returncode': run.returncode,
        'interpreter': os.path.abspath(sys.executable), 'U1_DAG_MODE': 'python'}, indent=2) + '\n')
    if expect_failure:
        if run.returncode == 0:
            raise AssertionError('Invalid completed state unexpectedly passed')
        return (run.stdout + run.stderr).decode()
    if run.returncode:
        raise AssertionError((run.stdout + run.stderr).decode())
    return json.loads(output.read_bytes())


def without_resolution_timings(value):
    if isinstance(value, dict):
        return {k: without_resolution_timings(v) for k, v in value.items()
                if k != 'resolutionBuildTimings'}
    if isinstance(value, list):
        return [without_resolution_timings(v) for v in value]
    return value


@unittest.skipUnless(shutil.which('gap'), 'GAP/HAP required')
class DuplicateNativeReuseTests(unittest.TestCase):
    def test_full_classifications_and_exact_transfer_counts(self):
        reference = run_gap('reference', 'classifications', CLASSIFICATIONS)
        candidate = run_gap('candidate', 'classifications', CLASSIFICATIONS)
        self.assertEqual(len(reference), 10)
        savings = []
        for old, new in zip(reference, candidate):
            self.assertEqual(old['name'], new['name'])
            # Includes all gauges, roots, primitives, chain/completion counts,
            # filling, final and filtration groups, and even worker/cache stats.
            self.assertEqual(without_resolution_timings(old['result']),
                             without_resolution_timings(new['result']), old['name'])
            a, b = old['counts'], new['counts']
            self.assertEqual(a['reductions'], b['reductions'])
            self.assertEqual(a['chargeReductions'], b['chargeReductions'])
            expected = a['reductions'] + a['chargeReductions']
            self.assertEqual(a['native'] - b['native'], expected, old['name'])
            self.assertGreater(expected, 0)
            self.assertLess(b['nonzeroNative'], a['nonzeroNative'])
            savings.append({'case': old['name'], 'referenceCalls': a['native'],
                            'candidateCalls': b['native'], 'exactCallsRemoved': expected,
                            'nonzeroCallsRemoved': a['nonzeroNative']-b['nonzeroNative']})
        self.assertEqual(reference[0]['result']['torsion'], [4])
        self.assertEqual(reference[0]['result']['generators'][1]['nativePhase'], ['1/4'])
        self.assertEqual(reference[6]['result']['torsion'], [8])
        self.assertTrue(any(w['kind'] == 'CI-root' and w['chargeCoordinates'] == [1]
                            for w in reference[6]['result']['witnesses']))
        self.assertEqual(reference[7]['result']['generators'][-1]['nativePhase'], ['1/16'])
        (RESULTS/'classification_comparison.json').write_text(json.dumps({
            'passed': True, 'caseCount': len(savings), 'ignoredResultFields': ['resolutionBuildTimings'],
            'savings': savings, 'wallTimeSpeedupClaimed': False}, indent=2) + '\n')

    def test_signed_negative_gauges_all_phase_values_and_witnesses(self):
        reference = run_gap('reference', 'gauges', GAUGES)
        candidate = run_gap('candidate', 'gauges', GAUGES)
        self.assertEqual(len(reference), 16)
        count = 0
        for old, new in zip(reference, candidate):
            self.assertEqual({k:v for k,v in old.items() if k != 'counts'},
                             {k:v for k,v in new.items() if k != 'counts'})
            self.assertEqual(old['counts']['native']-new['counts']['native'], 1)
            count += len(old['values'])
        self.assertEqual(count, 864)
        (RESULTS/'gauge_comparison.json').write_text(json.dumps({
            'passed': True, 'rows': 16, 'exactPhaseValues': count,
            'independentSignChoices': 4, 'canonicalAndReferenceModes': True,
            'identicalFullGaugeWitnesses': True}, indent=2) + '\n')

    def test_invalid_completed_phase_still_rejected(self):
        program = r'''
c:=U1CyclicContext(2,0,0,0);;one:=Identity(c.G);;
bad:=function(g,h,j)if one in [g,h,j] then return 0;fi;return 1/3;end;;
U1ReduceVacuum(c,2,rec(sheet:=U1Zero,charge:=U1Zero,phase:=bad));;QUIT_GAP(0);
'''
        for tree in ['reference', 'candidate']:
            result = run_gap(tree, 'invalid_phase', program, expect_failure=True)
            self.assertIn('Completed phase does not solve its native source', result)


if __name__ == '__main__':
    unittest.main(verbosity=2)

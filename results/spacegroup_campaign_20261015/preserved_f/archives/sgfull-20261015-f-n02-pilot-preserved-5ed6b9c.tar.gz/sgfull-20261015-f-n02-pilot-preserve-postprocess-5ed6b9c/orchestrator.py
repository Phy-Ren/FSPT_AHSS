#!/usr/bin/env python3
"""Offline F preservation. Requires an explicitly supplied completed stop report."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

BASE = Path('/home/user/xyren/AllFSPT_insulator')
SOURCE = BASE / 'snapshots/f-preserve-5ed6b9c'
SOURCE_MANIFEST = SOURCE / 'postprocessor_source.json'
SOURCE_MANIFEST_SHA = 'f652add26ed8520f4ee925b4da9ca5c007e4c48f72c33bbaf39075ce8fae4b10'
COMMIT = '5ed6b9c5e1acead350424aff7073b0c83d4d09e6'
PYTHON = str(BASE / 'runtime/bin/python3')


def now():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def write(path, data):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')
    temporary.replace(path)


def verify_source():
    if sha(SOURCE_MANIFEST) != SOURCE_MANIFEST_SHA:
        raise RuntimeError('Frozen postprocessor source manifest differs')
    source = json.loads(SOURCE_MANIFEST.read_text())
    if source['sourceCommit'] != COMMIT:
        raise RuntimeError('Unexpected postprocessor commit')
    for name, expected in source['filesSHA256'].items():
        if sha(SOURCE / name) != expected:
            raise RuntimeError('Frozen postprocessor source changed: ' + name)
    return source


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('node', choices=('n02', 'n03'))
    parser.add_argument('--stop-report', type=Path)
    parser.add_argument('--check-source', action='store_true')
    args = parser.parse_args()
    source = verify_source()
    if args.check_source:
        print(json.dumps(dict(ready=True, node=args.node, sourceCommit=COMMIT,
                              sourceManifestSHA256=SOURCE_MANIFEST_SHA,
                              filesVerified=len(source['filesSHA256']), pythonVersion=sys.version.split()[0])), flush=True)
        return
    if args.stop_report is None:
        parser.error('--stop-report must be supplied after the campaign is stopped')
    tag = 'sgfull-20261015-f-' + args.node + '-pilot'
    original = BASE / 'runs' / tag
    report_path = args.stop_report.resolve(strict=True)
    stop = report_path.parent
    if stop.parent != BASE / 'runs' or report_path.name != 'cancellation.json':
        raise RuntimeError('Stop report must be a separate cancellation.json directory under runs')
    report = json.loads(report_path.read_text())
    if report.get('originalCampaignRoot') != str(original):
        raise RuntimeError('Stop report belongs to another campaign')
    if report.get('sourceSnapshotPath') != str(BASE / 'snapshots/sgfull-20261015-f'):
        raise RuntimeError('Stop report belongs to another source snapshot')
    if not all(report.get(key) is True for key in
               ('allOwnedProcessesStopped', 'sourceSnapshotVerified', 'formulaRuntimeVerified')):
        raise RuntimeError('Stop/source/runtime verification is not complete')

    preserved = BASE / 'runs' / (tag + '-preserved')
    e8 = BASE / 'runs' / (tag + '-preserved-e8')
    accepted = BASE / 'runs' / (tag + '-preserved-accepted')
    logs = BASE / 'runs' / (tag + '-preserve-postprocess-5ed6b9c')
    logs.mkdir(exist_ok=False)
    shutil.copyfile(__file__, logs / 'orchestrator.py')
    shutil.copyfile(SOURCE_MANIFEST, logs / 'postprocessor_source.json')
    metadata = dict(node=args.node, startedUTC=now(), status='starting', commands=[],
                    sourceCommit=COMMIT, postprocessorSource=str(SOURCE), sourceFilesSHA256=source['filesSHA256'],
                    sourceArchiveSHA256=source['sourceArchiveSHA256'], sourceManifestSHA256=SOURCE_MANIFEST_SHA,
                    orchestratorSHA256=sha(Path(__file__)), original=str(original), preserved=str(preserved),
                    e8=str(e8), stopReportPath=str(report_path), stopReportSHA256=sha(report_path))
    write(logs / 'status.json', metadata)
    try:
        def run(stage, command):
            row = dict(stage=stage, command=command, startedUTC=now())
            metadata['status'] = stage
            metadata['commands'].append(row)
            write(logs / 'status.json', metadata)
            began = time.monotonic()
            with (logs / (stage + '.stdout.log')).open('wb') as out, (logs / (stage + '.stderr.log')).open('wb') as err:
                result = subprocess.run(command, cwd=str(SOURCE), stdout=out, stderr=err)
            row.update(exitCode=result.returncode, finishedUTC=now(), elapsedSeconds=time.monotonic() - began)
            write(logs / 'status.json', metadata)
            if result.returncode:
                raise RuntimeError(stage + ' failed; inspect saved command logs')

        run('preservation', [PYTHON, str(SOURCE / 'scripts/recover_paired_campaign.py'),
                            '--campaign', str(original), '--stop-report', str(report_path), '--output', str(preserved)])
        ledger = json.loads((preserved / 'recovery.json').read_text())
        for name in ('preservedCases', 'recoveredCases', 'ordinaryCompleteCases', 'retryCases'):
            metadata[name] = ledger[name]
        metadata['retryReasons'] = json.loads((preserved / 'retry.json').read_text())
        metadata['preservationCompleteUTC'] = now()
        write(logs / 'status.json', metadata)
        write(logs / 'preserved_selection.json', ledger['preservedCases'])
        print(json.dumps(dict(node=args.node, preserved=ledger['preservedCases'], retry=ledger['retryCases'],
                              recovered=ledger['recoveredCases'], selection=str(logs / 'preserved_selection.json'))), flush=True)
        if ledger['preservedCases']:
            run('e8', [PYTHON, str(SOURCE / 'scripts/extend_e8_3p1.py'), '--ci-root', str(preserved),
                       '--allow-recovered', '--output', str(e8)])
            run('acceptance', [PYTHON, str(SOURCE / 'scripts/collect_expansion.py'), '--ci-root', str(preserved),
                              '--e8-root', str(e8), '--allow-recovered', '--output', str(accepted)])
        else:
            metadata['e8Skipped'] = 'No certified completed cases'
        verify_source()
        if sha(report_path) != metadata['stopReportSHA256']:
            raise RuntimeError('Stop report changed during offline preservation')
        archive = BASE / 'archives' / (tag + '-preserved-5ed6b9c.tar.gz')
        archive.parent.mkdir(exist_ok=True)
        if archive.exists():
            raise RuntimeError('Refusing to overwrite archive')
        names = [preserved.name, stop.name, logs.name]
        if e8.exists():
            names += [e8.name, accepted.name]
        metadata['status'] = 'archiving'
        write(logs / 'status.json', metadata)
        command = ['tar', '-C', str(BASE / 'runs'), '-czf', str(archive)] + names
        result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if result.returncode:
            raise RuntimeError('Archive failed: ' + result.stderr.decode(errors='replace'))
        metadata['archive'] = dict(path=str(archive), sha256=sha(archive), bytes=archive.stat().st_size,
                                   command=command, exitCode=result.returncode)
        metadata.update(status='complete', finishedUTC=now())
        write(logs / 'status.json', metadata)
        write(archive.with_suffix(archive.suffix + '.json'), metadata)
        print(json.dumps(dict(node=args.node, status='complete', archive=metadata['archive'])), flush=True)
    except Exception as error:
        metadata.update(status='failed', error=type(error).__name__ + ': ' + str(error), finishedUTC=now())
        write(logs / 'status.json', metadata)
        raise


if __name__ == '__main__':
    main()

"""Launch only the approved four-case H tail control, on n08, once."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time

BASE = Path('/home/user/xyren/AllFSPT_insulator')
TAG = 'sgfull-20261015-h-tail-n08'
SOURCE_TAG = 'sgfull-20261015-h'
SOURCE = BASE / 'snapshots' / SOURCE_TAG
OUTPUT = BASE / 'runs' / TAG
EXPECTED = BASE / 'snapshots/u1_h_tail_expected_20261015.json'
CASES = ['spacegroup_%03d_%s' % (n, s) for n in (226, 230) for s in ('spin_half', 'spinless')]
PYTHON = BASE / 'runtime/bin/python3'
GAP = Path('/home/user/xyren/software/gap-4.13.1-o2-20261015/gap-o2')
BINARY = GAP.parent / 'gap'
FINALIZER = BASE / 'snapshots/u1_finalize_campaign_20261015.py'
LAUNCH = BASE / 'runs' / (TAG + '-launch.json')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


assert socket.gethostname().split('.')[0] == 'n08'
assert not any((BASE / 'runs' / (TAG + suffix)).exists() for suffix in
               ('', '.log', '-launch.json', '-finalizer-launch.json', '-finalizer.log', '-finalization.json', '-e8', '-accepted'))
expected = json.loads(EXPECTED.read_text())
assert expected['sourceCommit'] == 'ea44c1f55314ddd66587cf452bbaae9331f3a1db'
source = expected['source']
assert hashlib.sha256(json.dumps(source['files'], sort_keys=True, separators=(',', ':')).encode()).hexdigest() == source['sha256']
for name, value in source['files'].items():
    assert sha(SOURCE / name) == value, name
for case in CASES:
    assert sha(SOURCE / 'insulator_catalog/generated' / (case + '.json')) == expected['inputSHA256'][case]
assert sha(SOURCE / 'insulator/_compiled/u1_dag_vm.so') == expected['formulaRuntime']['librarySHA256']
assert sha(BINARY) == expected['gapBinarySHA256']
assert sha(FINALIZER) == expected['finalizerSHA256']
archive = BASE / 'snapshots' / (SOURCE_TAG + '.tar.gz')
assert sha(archive) == expected['archiveSHA256']
mem = {line.split(':')[0]: int(line.split()[1]) for line in Path('/proc/meminfo').read_text().splitlines() if len(line.split()) >= 2}
available = mem.get('MemAvailable', mem.get('MemFree', 0) + mem.get('Buffers', 0) + mem.get('Cached', 0) + mem.get('SReclaimable', 0) - mem.get('Shmem', 0))
resources = {'sampleUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
             'host': socket.gethostname(), 'logicalCPUs': os.cpu_count(), 'loadAverage': list(os.getloadavg()),
             'memoryKiB': {k: mem.get(k) for k in ('MemTotal', 'MemAvailable', 'MemFree', 'Buffers', 'Cached', 'SReclaimable', 'Shmem')},
             'availableEstimateGiB': available / 1024**2,
             'availableEstimateMethod': 'MemAvailable, or MemFree+Buffers+Cached+SReclaimable-Shmem when unavailable',
             'additionalGAPMemoryCapGiB': 16, 'additionalConcurrentGeometryJobs': 2}
assert available > 24 * 1024**2, resources
assert resources['loadAverage'][0] + 2 < resources['logicalCPUs'], resources
command = [str(PYTHON), str(SOURCE / 'scripts/classify.py'), '--family', 'spacegroup', '--output', str(OUTPUT),
           '--gap', str(GAP), '--pair-spins', '--jobs', '2', '--memory', '8g', '--timeout', '14400',
           '--largest-first', '--charge-primary', 'native', '--phase-class', 'cycles',
           '--closed-charge-source', 'certified', '--vacuum-reduction', 'canonical']
for case in CASES:
    command += ['--case', case]
environment = dict(os.environ, LC_ALL='C', LANG='C', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', U1_DAG_MODE='auto')
environment['PATH'] = str(BASE / 'runtime/bin') + ':' + environment['PATH']
report = {'schema': 'u1-h-tail-launch-v1', 'state': 'prepared', 'node': 'n08', 'tag': TAG,
          'sourceTag': SOURCE_TAG, 'sourceCommit': expected['sourceCommit'], 'source': source,
          'snapshotSHA256': expected['archiveSHA256'], 'expectedSHA256': sha(EXPECTED),
          'launcherSHA256': sha(Path(__file__)), 'command': command, 'output': str(OUTPUT),
          'log': str(BASE / 'runs' / (TAG + '.log')), 'cases': CASES, 'caseCount': 4, 'geometryJobs': 2,
          'memoryPerJob': '8g', 'timeoutSecondsPerCase': 14400, 'batchTimeoutSecondsPerGeometry': 28800,
          'timeoutEnforcement': 'Shared pair budget; individual cases are not killed separately',
          'sourceVerifiedBeforeLaunch': True, 'inputSHA256': expected['inputSHA256'],
          'formulaRuntime': expected['formulaRuntime'], 'formulaRuntimeVerifiedBeforeLaunch': True,
          'gapLauncherSHA256': sha(GAP), 'gapBinarySHA256': sha(BINARY),
          'finalizerSHA256': sha(FINALIZER), 'resourcePreflight': resources,
          'recordedEnvironment': {key: environment[key] for key in ('LC_ALL', 'LANG', 'OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'U1_DAG_MODE', 'PATH')},
          'role': 'Additional exact four-case control; primary full460 partition remains unchanged until reviewed',
          'comparisonLimit': 'No speed ratio inferred across different resolutions, nodes or background load.'}
with LAUNCH.open('x') as handle:
    json.dump(report, handle, indent=2, sort_keys=True)
with (BASE / 'runs' / (TAG + '.log')).open('x') as log:
    runner = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, env=environment, cwd=SOURCE,
                              stdin=subprocess.DEVNULL, start_new_session=True)
report.update(state='launched', pid=runner.pid, startedUTC=datetime.datetime.now(datetime.timezone.utc).isoformat())
write(LAUNCH, report)
for unused in range(100):
    if all((OUTPUT / name).is_file() for name in ('selection.json', 'source.json', 'formula_runtime.json')):
        break
    if runner.poll() is not None:
        raise RuntimeError('New runner exited before writing campaign metadata: ' + str(runner.returncode))
    time.sleep(0.2)
else:
    raise RuntimeError('New runner metadata not ready; runner left untouched for inspection')
assert set(json.loads((OUTPUT / 'selection.json').read_text())) == set(CASES)
assert json.loads((OUTPUT / 'source.json').read_text()) == source
assert json.loads((OUTPUT / 'formula_runtime.json').read_text()) == expected['formulaRuntime']
final_command = [str(PYTHON), str(FINALIZER), '--tag', TAG, '--runner-pid', str(runner.pid), '--node', 'n08', '--source-tag', SOURCE_TAG]
with (BASE / 'runs' / (TAG + '-finalizer.log')).open('x') as log:
    finalizer = subprocess.Popen(final_command, stdout=log, stderr=subprocess.STDOUT, env=environment,
                                 stdin=subprocess.DEVNULL, start_new_session=True)
final_report = {'pid': finalizer.pid, 'command': final_command, 'runnerPID': runner.pid,
                'finalizerSHA256': sha(FINALIZER), 'sourceTag': SOURCE_TAG, 'node': 'n08'}
with (BASE / 'runs' / (TAG + '-finalizer-launch.json')).open('x') as handle:
    json.dump(final_report, handle, indent=2, sort_keys=True)
report.update(finalizerPID=finalizer.pid, campaignMetadataVerified=True)
write(LAUNCH, report)
print(json.dumps({'state': 'launched', 'runnerPID': runner.pid, 'finalizerPID': finalizer.pid,
                  'launchMetadata': str(LAUNCH), 'output': str(OUTPUT), 'resourcePreflight': resources}, sort_keys=True))

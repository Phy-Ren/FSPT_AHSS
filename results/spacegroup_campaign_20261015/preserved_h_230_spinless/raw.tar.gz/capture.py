#!/usr/bin/env python3
"""Read-only byte capture of one ordinary completed case from an active parent."""
import hashlib,io,json,subprocess,tarfile
from pathlib import Path
BASE=Path(__file__).resolve().parent
REMOTE=r'''
import datetime,hashlib,io,json,sys,tarfile
from pathlib import Path
root=Path('/home/user/xyren/AllFSPT_insulator/runs/sgfull-20261015-h-tail-spinless-n08')
case='spacegroup_230_spinless'
paths=['source.json','selection.json','formula_runtime.json']+[case+'/'+n for n in ['input.json','driver.g','run.json','native.json','result.json','stdout.log','stderr.log']]
def load():return {n:(root/n).read_bytes() for n in paths}
files=load();source=json.loads(files['source.json']);runtime=json.loads(files['formula_runtime.json']);run=json.loads(files[case+'/run.json'])
assert source['sha256']=='80e0a57b1ac611b348d748da2becbfe64d4aa17f196df9ffae3addea3e22940b'
assert hashlib.sha256(json.dumps(source['files'],sort_keys=True,separators=(',',':')).encode()).hexdigest()==source['sha256']
snapshot=Path('/home/user/xyren/AllFSPT_insulator/snapshots/sgfull-20261015-h')
for n,h in source['files'].items():assert hashlib.sha256((snapshot/n).read_bytes()).hexdigest()==h,n
assert runtime['librarySHA256']=='0c026ca103e9ba8b674c006d6042ca23bfe526ca62b4e96b3c1b79c4d318dec2'
assert hashlib.sha256(Path(runtime['libraryPath']).read_bytes()).hexdigest()==runtime['librarySHA256']
assert run['status']=='complete' and type(run['exitCode']) is int and run['exitCode']==0
assert files==load(),'Selected complete case changed across capture'
metadata={'remoteParent':str(root),'captureUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceSnapshot':str(snapshot),'sourceFilesVerified':len(source['files']),'sourceSHA256':source['sha256'],'formulaRuntimeVerified':True,'formulaVMSHA256':runtime['librarySHA256'],'originalSelection':json.loads(files['selection.json']),'selectedCases':[case],'originalParentCompleteClaimed':False,'twoReadsEqual':True,'files':{n:{'sha256':hashlib.sha256(d).hexdigest(),'bytes':len(d)} for n,d in files.items()},'readOnlyCapture':True}
with tarfile.open(fileobj=sys.stdout.buffer,mode='w|gz') as tar:
 for n,d in sorted(files.items()):
  info=tarfile.TarInfo('original/'+n);info.size=len(d);tar.addfile(info,io.BytesIO(d))
 d=(json.dumps(metadata,indent=2,sort_keys=True)+'\n').encode();info=tarfile.TarInfo('capture.json');info.size=len(d);tar.addfile(info,io.BytesIO(d))
'''
p=subprocess.run(['ssh','-o','ControlMaster=no','-o','ProxyCommand=false','cuhk-cluster3','bash -s'],input=("python3 - <<'CAPTURE_PY'\n"+REMOTE+"\nCAPTURE_PY\n").encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
(BASE/'capture.stderr.log').write_bytes(p.stderr)
archive=BASE/'original_capture.tar.gz';assert not archive.exists();archive.write_bytes(p.stdout)
files={}
with tarfile.open(fileobj=io.BytesIO(p.stdout),mode='r:gz') as tar:
 for member in tar.getmembers():
  name=Path(member.name);assert member.isfile() and not name.is_absolute() and '..' not in name.parts and member.name not in files
  files[member.name]=tar.extractfile(member).read()
meta=json.loads(files['capture.json']);assert set(files)=={'capture.json'}|{'original/'+n for n in meta['files']}
for n,v in meta['files'].items():assert hashlib.sha256(files['original/'+n]).hexdigest()==v['sha256'] and len(files['original/'+n])==v['bytes']
for n,d in files.items():p=BASE/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(d)
(BASE/'download.json').write_text(json.dumps({'archiveSHA256':hashlib.sha256(archive.read_bytes()).hexdigest(),'remoteAndLocalMemberHashesVerified':True,'originalFiles':len(meta['files']),'originalParentCompleteClaimed':False},indent=2,sort_keys=True)+'\n')
print(json.dumps({'path':str(BASE),'sourceFilesVerified':meta['sourceFilesVerified'],'originalFiles':len(meta['files']),'originalParentCompleteClaimed':False},sort_keys=True))

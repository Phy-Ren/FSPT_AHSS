#!/usr/bin/env python3
"""Stage an exact ordinary singleton view; never modify or certify its full parent."""
from pathlib import Path
import hashlib,json,shutil,sys
BASE=Path(__file__).resolve().parent
HELPER=Path('/home/xingyu/AllFSPT_reviews/spacegroup_full_catalogue_20261015/accelerated_gate/preservation-helper-c26f3de')
CHECKER=HELPER/'scripts/recover_paired_campaign.py'
assert hashlib.sha256(CHECKER.read_bytes()).hexdigest()=='d99e0914f901c29adeb0f418cdae4b4df3895143f5c439bc8b0d07e5839e8388'
sys.dont_write_bytecode=True;sys.path.insert(0,str(HELPER))
from scripts.recover_paired_campaign import _inspect_case
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_bytes())
original=BASE/'original';capture=read(BASE/'capture.json');case='spacegroup_230_spinless'
for n,v in capture['files'].items():assert sha(original/n)==v['sha256']
source=read(original/'source.json');selection=read(original/'selection.json')
assert selection==['spacegroup_226_spinless',case]
binding={'sourceSnapshotPath':capture['sourceSnapshot'],'originalCampaignRoot':capture['remoteParent']}
item=_inspect_case(lambda n:(original/n).read_bytes(),binding,{},source,selection,case)
assert item['kind']=='ordinary_complete' and item['pair']==[case]
view=BASE/'ci_view';view.mkdir(exist_ok=False)
for n in ['source.json','formula_runtime.json']:shutil.copyfile(original/n,view/n)
shutil.copytree(original/case,view/case)
(view/'selection.json').write_text(json.dumps([case],indent=2)+'\n')
proof={'schema':'u1-ordinary-complete-singleton-view-v1','state':'staged_unselected','originalParent':capture['remoteParent'],'originalParentCompleteClaimed':False,'noStopOrRecoveryClaim':True,'ordinaryExitZeroRequired':True,'originalSelection':selection,'originalSelectionSHA256':sha(original/'selection.json'),'viewSelection':[case],'viewSelectionSHA256':sha(view/'selection.json'),'sourceSHA256':source['sha256'],'formulaRuntimeSHA256':sha(original/'formula_runtime.json'),'copiedFilesSHA256':{n:sha(view/n) for n in capture['files'] if n!='selection.json'},'excludedCases':[n for n in selection if n!=case],'sourceSnapshot':capture['sourceSnapshot'],'captureSHA256':sha(BASE/'capture.json'),'originalArchiveSHA256':sha(BASE/'original_capture.tar.gz'),'ordinaryInspectorSHA256':sha(CHECKER),'ordinaryInspectorBinding':binding,'scientificChecks':item['checks'],'scope':'Exact original standalone ordinary case bytes in a new subset view. The live original parent is not edited or accepted.'}
(view/'subset_provenance.json').write_text(json.dumps(proof,indent=2,sort_keys=True)+'\n')
for n,h in proof['copiedFilesSHA256'].items():assert sha(view/n)==h==sha(original/n)
print(json.dumps({'staged':str(view),'ordinaryCase':case,'originalParentCompleteClaimed':False,'sourceSHA256':source['sha256']},sort_keys=True))

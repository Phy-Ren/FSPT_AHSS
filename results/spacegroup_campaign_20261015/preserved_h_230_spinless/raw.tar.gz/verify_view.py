#!/usr/bin/env python3
"""Verify a staged ordinary singleton, without accepting its original full parent."""
import argparse,hashlib,json,subprocess,sys
from pathlib import Path
BASE=Path(__file__).resolve().parent
REPO=Path('/home/xingyu/FSPT_AHSS_insulator')
HELPER=Path('/home/xingyu/AllFSPT_reviews/spacegroup_full_catalogue_20261015/accelerated_gate/preservation-helper-c26f3de')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_bytes())
manifest=read(BASE/'manifest.json')['filesSHA256']
assert set(manifest)=={str(p.relative_to(BASE)) for p in BASE.rglob('*') if p.is_file() and p.name!='manifest.json' and '__pycache__' not in p.parts}
for name,expected in manifest.items():assert sha(BASE/name)==expected,name
helper_manifest=read(BASE/'helper_manifest.json')
for name,expected in helper_manifest['files'].items():assert sha(HELPER/name)==expected['sha256'],name
sys.dont_write_bytecode=True;sys.path.insert(0,str(HELPER))
from scripts.recover_paired_campaign import _inspect_case
from scripts.collect_expansion import load_campaign
original=BASE/'original';view=BASE/'ci_view';e8=BASE/'e8_view'
capture=read(BASE/'capture.json');proof=read(view/'subset_provenance.json');case='spacegroup_230_spinless'
assert capture['sourceFilesVerified']==60 and capture['formulaRuntimeVerified'] is True
assert capture['twoReadsEqual'] is True and capture['originalParentCompleteClaimed'] is False
assert proof['state']=='staged_unselected' and proof['noStopOrRecoveryClaim'] is True
assert proof['originalParentCompleteClaimed'] is False
for name,expected in capture['files'].items():assert sha(original/name)==expected['sha256']
assert sha(BASE/'original_capture.tar.gz')==proof['originalArchiveSHA256']
assert sha(original/'selection.json')==proof['originalSelectionSHA256']
assert read(original/'selection.json')==proof['originalSelection']==['spacegroup_226_spinless',case]
assert read(view/'selection.json')==proof['viewSelection']==[case]
assert sha(view/'selection.json')==proof['viewSelectionSHA256']
for name,expected in proof['copiedFilesSHA256'].items():assert sha(view/name)==sha(original/name)==expected
source=read(view/'source.json')
assert source['sha256']==proof['sourceSHA256']==capture['sourceSHA256']=='80e0a57b1ac611b348d748da2becbfe64d4aa17f196df9ffae3addea3e22940b'
for metadata,commit in [(source,'ea44c1f55314ddd66587cf452bbaae9331f3a1db'),(read(e8/'source.json'),'c07c6e5d4a69d79c9c2aeb0739ae1e189029f824')]:
 assert hashlib.sha256(json.dumps(metadata['files'],sort_keys=True,separators=(',',':')).encode()).hexdigest()==metadata['sha256']
 for name,expected in metadata['files'].items():assert hashlib.sha256(subprocess.check_output(['git','show',commit+':'+name],cwd=REPO)).hexdigest()==expected
assert (view/case/'input.json').read_bytes()==subprocess.check_output(['git','show','ea44c1f:insulator_catalog/generated/'+case+'.json'],cwd=REPO)
assert sha(HELPER/'scripts/recover_paired_campaign.py')==proof['ordinaryInspectorSHA256']
item=_inspect_case(lambda n:(original/n).read_bytes(),proof['ordinaryInspectorBinding'],{},source,proof['originalSelection'],case)
assert item['kind']=='ordinary_complete' and item['checks']==proof['scientificChecks']
ci_records,ci_checks,_=load_campaign(view,'ci');e8_records,e8_checks,_=load_campaign(e8,'e8')
assert set(ci_records)==set(e8_records)=={case}
assert (e8/case/'ci_result.json').read_bytes()==(view/case/'result.json').read_bytes()
accepted=BASE/'staged_accepted';collection=read(accepted/'collection.json')
assert collection['accepted'] is True and len(collection['collections'])==1
row=collection['collections'][0];assert (row['family'],row['count'])==('spacegroup',1)
for name,expected in row['filesSHA256'].items():assert sha(accepted/row['path']/name)==expected
assert read(accepted/row['path']/'ci_results.json')==[ci_records[case]['record']]
assert read(accepted/row['path']/'results.json')==[e8_records[case]['record']]
assert read(accepted/row['path']/'validation.json')['completeResultCount']==1
print(json.dumps({'verified':True,'ordinarySingleton':case,'originalParentCompleteClaimed':False,'sourceFilesCheckedAgainstGit':65,'exactOriginalCaseBytes':True,'newSelectionHasExplicitParentSubsetProvenance':True,'stagedCollectorAccepted':True,'selectedForPublication':False,'scientificChecks':item['checks']},indent=2,sort_keys=True))

# Prepared ordinary SG230 spinless view; not selected for publication

`ci_view/` is a new singleton view of the already ordinary-complete SG230
spinless case from the still-incomplete two-case H parent. Its original
`run.json`, `result.json`, `native.json`, input, driver and both logs are
copied byte for byte. The source and formula-runtime manifests are also
unchanged. Only the new view's selection file names the one selected case.
The original remote selection, results and acceptance records are untouched.

`ci_view/subset_provenance.json` records the complete original two-case
selection and its hash, the new singleton selection and hash, every copied
file hash, excluded SG226 spinless, original remote root, exact source path,
capture hash and scientific checks. It explicitly disclaims original-parent
completion and any stop or recovered-completion claim.

The read-only capture verified all 60 frozen H source files and the actual
native VM, then required two identical reads of the ten retained files.
`original_capture.tar.gz`, `capture.json` and `download.json` preserve the
raw acquisition evidence. The original completed case is independently
rechecked using the c26 helper's ordinary singleton branch: exact integer
exit zero, run/result/native identity, driver/input/output bindings, saved
completion and chain certificates, independent Smith factors and primitive
filling checks. This branch needs no stop attestation; none is manufactured.
All pinned helper files are checked before execution.

`e8_view/` and `staged_accepted/` are local review outputs from the unchanged
frozen c07 E8 stage and collector. The E8 parent copy is byte-identical to
the original CI result. `verify_view.py` additionally checks all 65 CI/E8
source hashes against Git and the input against the frozen catalogue.
These local checks passed; no CI classification was rerun. They do not
select this alternative into the public catalogue or certify the original
two-case parent. `physicalClassificationCertified` remains false.

`alternate460_manifest.unselected.json` replaces only the planned two-case
spinless parent with this staged SG230 singleton and the eventual complete
unchanged-H SG226 shadow singleton. It also reflects acceptance of the
already completed two-case high-memory spin-half parent. Exact coverage is
460 distinct catalogue IDs, with no duplicates or omissions. The SG226
shadow is still pending; this is a plan, not a completed 460-case result.
The original full manifest is pinned in `alternate460_validation.json`.

Root review must approve this view and separately verify the shadow's full
ordinary CI/E8/download evidence before choosing this alternative. If the
original two-case parent completes first, its existing full-parent path can
still be used instead. No jobs were launched, stopped or changed here.

Recheck the staged view with:

```sh
python3 /home/xingyu/AllFSPT_reviews/spacegroup_230_spinless_singleton_20261015/verify_view.py
```

The verifier uses the pinned external c26 helper snapshot and this Git
checkout; their paths are explicit at the top of the script. It performs
read-only validation and does not regenerate accepted outputs.

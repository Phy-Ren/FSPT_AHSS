#!/usr/bin/env python3
"""Real LOCAL synthetic processes only; every validation invocation is non-signaling."""
import ctypes, hashlib, importlib.util, json, os, shutil, signal, socket, subprocess, sys, tempfile, time
from pathlib import Path
HERE=Path(__file__).resolve().parent
HELPER=HERE/'stop_owned_u1_campaign.py'
spec=importlib.util.spec_from_file_location('stop',HELPER);stop=importlib.util.module_from_spec(spec);spec.loader.exec_module(stop)
ctypes.CDLL(None).prctl(36,1,0,0,0)
work=Path(tempfile.mkdtemp(prefix='local-',dir=HERE));snapshot=work/'snapshot';(snapshot/'scripts').mkdir(parents=True)
root=work/'campaign';root.mkdir();ready=work/'ready';ready.mkdir()
cases=['spacegroup_019_spin_half','spacegroup_019_spinless','spacegroup_226_spin_half']
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def hashes(p):return {str(q.relative_to(p)):sha(q) for q in sorted(p.rglob('*')) if q.is_file()}
(snapshot/'scripts/fake_gap.py').write_text('''import json,os,subprocess,sys,time
from pathlib import Path
w=subprocess.Popen([sys.executable,'-c','import time;time.sleep(1000)'])
p=Path(sys.argv[-1]);(Path(os.environ['LOCAL_READY'])/p.parent.name).write_text(json.dumps({'gap':os.getpid(),'worker':w.pid,'runner':os.getppid()}))
while True:time.sleep(1)
''')
(snapshot/'scripts/classify.py').write_text('''import argparse,os,subprocess,sys,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--output');p.add_argument('--ready');a=p.parse_args()
snapshot=Path(__file__).resolve().parents[1]
for case in ['spacegroup_019_spin_half','spacegroup_226_spin_half']:
 subprocess.Popen([sys.executable,str(snapshot/'scripts/fake_gap.py'),str(Path(a.output)/case/'driver.g')],env=dict(os.environ,LOCAL_READY=a.ready),start_new_session=True)
while True:time.sleep(1)
''')
source={'files':hashes(snapshot)};source['sha256']=hashlib.sha256(json.dumps(source['files'],sort_keys=True,separators=(',',':')).encode()).hexdigest()
write(root/'source.json',source);write(root/'selection.json',cases)
for i,case in enumerate(cases):
 d=root/case;d.mkdir();data={'id':case,'dimension':3,'test':[-1,True,False,'rational 1/2']};write(d/'input.json',data)
 command=[sys.executable,str(snapshot/'scripts/fake_gap.py'),str(root/(cases[0] if i<2 else case)/'driver.g')]
 run=dict(id=case,status='running',command=command,sourceSHA256=source['sha256'],inputSHA256=sha(d/'input.json'),host=socket.gethostname())
 if i<2:run.update(pairedSpins=True,batchCaseIDs=cases[:2])
 write(d/'run.json',run)
 driver='U1_ROOT:='+json.dumps(str(snapshot))+';;\nU1_INPUT:='+stop.gap_literal(data)+';;\n'
 driver+='output:=OutputTextFile('+json.dumps(str(d/'native.json'))+',false);;\nCloseStream(output);;\n'
 (d/'driver.g').write_text(driver)
wrapper=work/'invoke.py';wrapper.write_text('''import importlib.util,json,sys
from pathlib import Path
helper,trace=sys.argv[1:3];sys.argv=[helper]+sys.argv[3:]
s=importlib.util.spec_from_file_location('stop',helper);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
def forbidden(pid,sig):
 with open(trace,'a') as f:f.write(json.dumps({'pid':pid,'signal':int(sig)})+'\\n')
 raise AssertionError('A preflight test attempted a signal')
m.os.kill=forbidden;m.os.killpg=forbidden
m.main()
''')
sentinel=subprocess.Popen([sys.executable,'-c','import time;time.sleep(1000)'],start_new_session=True)
runner=subprocess.Popen([sys.executable,str(snapshot/'scripts/classify.py'),'--output',str(root),'--ready',str(ready)],start_new_session=True)
owned={};tests=[]
def alive():
 for row in list(owned.values())+[stop.process(sentinel.pid)]:
  current=stop.process(row['pid']);assert stop.same_identity(row,current) and current['state'] not in ('T','t','Z')
def rejects(name,run_change=None,driver_change=None,input_change=None,runner_pid=None):
 d=root/cases[2];saved={n:(d/n).read_bytes() for n in ['run.json','driver.g','input.json']}
 try:
  if run_change:
   r=json.loads(saved['run.json']);run_change(r);write(d/'run.json',r)
  if driver_change:(d/'driver.g').write_text(driver_change(saved['driver.g'].decode()))
  if input_change:(d/'input.json').write_bytes(input_change(saved['input.json']))
  trace=work/(name+'.signals.jsonl');trace.write_text('');out=work/(name+'-output')
  command=[sys.executable,str(wrapper),str(HELPER),str(trace),'--root',str(root),'--snapshot',str(snapshot),'--runner-pid',str(runner_pid or runner.pid),'--output',str(out),'--replacement','LOCAL-SYNTHETIC-ONLY']
  p=subprocess.run(command,text=True,capture_output=True,timeout=15)
  (work/(name+'.stdout.log')).write_text(p.stdout);(work/(name+'.stderr.log')).write_text(p.stderr)
  assert p.returncode!=0 and trace.read_text()=='' and not out.exists(),(name,p.returncode,p.stderr)
  alive();tests.append(dict(name=name,rejected=True,signalsAttempted=0,ownedAndSentinelAlive=True))
 finally:
  for n,b in saved.items():(d/n).write_bytes(b)
try:
 deadline=time.monotonic()+5
 while len(list(ready.iterdir()))<2 and time.monotonic()<deadline:time.sleep(.02)
 ids=[json.loads(p.read_text()) for p in ready.iterdir()];assert len(ids)==2
 owned={pid:stop.process(pid) for row in ids for pid in row.values()}
 before=hashes(root);write(work/'raw_before.json',before)
 rows=stop.scan_owned(os.getuid());captured,gaps,batches=stop.validate_tree(rows,stop.process(runner.pid),root,source,cases)
 assert set(captured)==set(owned) and len(gaps)==2 and len(batches)==1 and batches[0]['caseIDs']==cases[:2]
 assert all(b['gapPID']!=json.loads((ready/cases[2]).read_text())['gap'] for b in batches)
 tests.append(dict(name='mixed_pair_singleton_tree',accepted=True,ownedProcesses=len(captured),gapProcesses=2,pairedBatches=1,signalsAttempted=0))
 rejects('wrong_runner',runner_pid=sentinel.pid)
 rejects('wrong_command',run_change=lambda r:r['command'].insert(1,'--wrong'))
 rejects('wrong_source',run_change=lambda r:r.update(sourceSHA256='0'*64))
 rejects('wrong_host',run_change=lambda r:r.update(host='another-host'))
 rejects('wrong_case_id',run_change=lambda r:r.update(id=cases[0]))
 rejects('false_pair_with_batch',run_change=lambda r:r.update(pairedSpins=False,batchCaseIDs=[cases[2],cases[1]]))
 rejects('nonboolean_pair',run_change=lambda r:r.update(pairedSpins=1))
 rejects('unknown_batch_field',run_change=lambda r:r.update(batchUnexpected='bad'))
 rejects('wrong_input_hash',run_change=lambda r:r.update(inputSHA256='f'*64))
 rejects('changed_input',input_change=lambda b:b+b' ')
 rejects('wrong_driver_root',driver_change=lambda s:s.replace(str(snapshot),str(work/'other')))
 rejects('wrong_embedded_input',driver_change=lambda s:s.replace('dimension:=3','dimension:=4'))
 rejects('duplicated_input',driver_change=lambda s:s+'U1_INPUT:=rec();;\n')
 rejects('wrong_output',driver_change=lambda s:s.replace(str(root/cases[2]/'native.json'),str(root/cases[0]/'native.json')))
 rejects('paired_marker',driver_change=lambda s:s+'Print("U1_PAIR_CASE_DONE ");;\n')
 # Identity/topology failures are read-only; the production main checks these
 # on its captured /proc rows before any freeze.
 singleton=json.loads((ready/cases[2]).read_text())['gap']
 for name,mutate in [
  ('missing_argv',lambda r:r[singleton].update(argv=[])),
  ('wrong_pgid',lambda r:r[singleton].update(pgid=runner.pid)),
  ('missing_executable',lambda r:r[singleton].pop('executableSHA256')),
  ('changed_runner_start',lambda r:r[runner.pid].update(startTicks=r[runner.pid]['startTicks']+1))]:
  altered=json.loads(json.dumps(rows));altered={int(k):v for k,v in altered.items()};mutate(altered)
  try:stop.validate_tree(altered,stop.process(runner.pid),root,source,cases)
  except RuntimeError:pass
  else:raise AssertionError('Accepted '+name)
  alive();tests.append(dict(name=name,rejected=True,signalsAttempted=0,ownedAndSentinelAlive=True))
 # Existing incomplete-singleton recovery prohibition is independently tested
 # by repo tests; this helper creates no fake batch for it.
 assert hashes(root)==before
 write(work/'raw_after.json',hashes(root));write(work/'captured_tree.json',dict(processes=list(captured.values()),gaps=gaps,batches=batches,sentinel=stop.process(sentinel.pid)))
 result=dict(status='PASS',localOnly=True,clusterContact=False,helperSHA256=sha(HELPER),testScriptSHA256=sha(Path(__file__)),tests=tests,
             noValidationSignalsAttempted=True,rawCampaignUnchanged=True,unrelatedSentinelAlive=True,workdir=str(work))
 write(work/'result.json',result);write(HERE/'result.json',result);print(json.dumps(result,indent=2))
finally:
 # Authorized cleanup applies only to this test's exact synthetic identities.
 for row in owned.values():
  if row and stop.same_identity(row,stop.process(row['pid'])):
   try:os.kill(row['pid'],signal.SIGKILL)
   except ProcessLookupError:pass
 for p in [runner,sentinel]:
  if p.poll() is None:p.kill()
  p.wait(timeout=5)
 time.sleep(.05)
 while True:
  try:
   pid,_=os.waitpid(-1,os.WNOHANG)
   if not pid:break
  except ChildProcessError:break

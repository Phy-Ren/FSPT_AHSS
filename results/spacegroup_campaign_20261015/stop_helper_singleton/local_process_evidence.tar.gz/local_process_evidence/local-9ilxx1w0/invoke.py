import importlib.util,json,sys
from pathlib import Path
helper,trace=sys.argv[1:3];sys.argv=[helper]+sys.argv[3:]
s=importlib.util.spec_from_file_location('stop',helper);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
def forbidden(pid,sig):
 with open(trace,'a') as f:f.write(json.dumps({'pid':pid,'signal':int(sig)})+'\n')
 raise AssertionError('A preflight test attempted a signal')
m.os.kill=forbidden;m.os.killpg=forbidden
m.main()

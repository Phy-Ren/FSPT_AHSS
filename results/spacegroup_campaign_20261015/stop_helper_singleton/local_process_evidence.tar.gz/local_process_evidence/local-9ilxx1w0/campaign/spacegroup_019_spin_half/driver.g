U1_ROOT:="/home/xingyu/AllFSPT_reviews/stop_helper_singleton_20261015/local-9ilxx1w0/snapshot";;
U1_INPUT:=rec(id:="spacegroup_019_spin_half",dimension:=3,test:=[-1,true,false,"rational 1/2"]);;
output:=OutputTextFile("/home/xingyu/AllFSPT_reviews/stop_helper_singleton_20261015/local-9ilxx1w0/campaign/spacegroup_019_spin_half/native.json",false);;
CloseStream(output);;

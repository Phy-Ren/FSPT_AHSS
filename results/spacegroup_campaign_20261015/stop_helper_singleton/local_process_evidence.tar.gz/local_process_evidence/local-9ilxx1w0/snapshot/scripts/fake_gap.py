import json,os,subprocess,sys,time
from pathlib import Path
w=subprocess.Popen([sys.executable,'-c','import time;time.sleep(1000)'])
p=Path(sys.argv[-1]);(Path(os.environ['LOCAL_READY'])/p.parent.name).write_text(json.dumps({'gap':os.getpid(),'worker':w.pid,'runner':os.getppid()}))
while True:time.sleep(1)

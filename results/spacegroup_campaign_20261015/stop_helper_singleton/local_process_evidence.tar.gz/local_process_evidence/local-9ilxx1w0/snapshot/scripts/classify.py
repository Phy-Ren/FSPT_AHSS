import argparse,os,subprocess,sys,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--output');p.add_argument('--ready');a=p.parse_args()
snapshot=Path(__file__).resolve().parents[1]
for case in ['spacegroup_019_spin_half','spacegroup_226_spin_half']:
 subprocess.Popen([sys.executable,str(snapshot/'scripts/fake_gap.py'),str(Path(a.output)/case/'driver.g')],env=dict(os.environ,LOCAL_READY=a.ready),start_new_session=True)
while True:time.sleep(1)

# Future singleton-capable campaign stop preflight

Date: 2026-10-15 UTC. This is an isolated future helper candidate. No cluster connection, process signal, deployment, or frozen-source modification was made by these tests.

`stop_owned_u1_campaign.py` adds ordinary singleton GAP children to the existing exact process-tree preflight. Their saved command must match the active argv suffix; driver path, source hash and host remain pinned. The new branch additionally checks singleton metadata, exact raw input hash, embedded GAP input, immutable source root and one own native output with a close statement. Misleading paired/batch metadata is rejected.

Both singleton and paired children are captured as owned GAP processes; only actual two-case batches enter the `batches` recovery evidence. This does not make an incomplete singleton recoverable. Offline recovery still requires an original complete exit0 result for a singleton. The existing freeze/rescan, PID/start/UID checks, scheduling-stop rollback and termination logic are unchanged.

The candidate is a separate copy of the original helper, with `change.patch` preserving the exact diff. SHA256: `574ee600775d6daa858cb6b20f97bb60843c126669a576daa82b4723dd467871`. Root and benchmarks reviewed the design; benchmarks' independent read-only code review found no blocker. Deployment requires a new immutable helper snapshot and root authorization.

Reproduce the bounded local test:

```bash
PYTHONDONTWRITEBYTECODE=1 python3 test_singleton_preflight.py
```

`result.json` records20 checks. A real synthetic Python runner launches one paired and one singleton process group, each with a worker; an unrelated sentinel remains outside that tree. The accepted read-only preflight captures exactly the two groups and exactly one paired batch. Nineteen negative checks cover runner identity, launch argv, source, host, case ID, paired-field contamination, input hash/bytes, driver source/input/output, duplicate input, marker, missing argv/executable, PGID and PID start time. Every negative command rejects before any scheduling or termination signal and before creating stop-output evidence. Raw signal traces are empty; all synthetic processes and the sentinel remain live during validation. Campaign file hashes agree before and after.

Only the test's own exact synthetic identities are terminated during final cleanup. This is separate from validation and never contacts a cluster. A successful production termination path was deliberately not rerun: it is unchanged and has the existing independently archived local test. The new candidate does not imply authorization to stop any current G/H job.

import argparse,json,os,subprocess,sys
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--output');p.add_argument('--finish');p.add_argument('--ready');a=p.parse_args()
snapshot=Path(__file__).resolve().parents[1];root=Path(a.output)
children=[]
for case in ['spacegroup_019_spin_half','spacegroup_226_spin_half']:
 children.append(subprocess.Popen([sys.executable,str(snapshot/'scripts/fake_gap.py'),str(root/case/'driver.g')],env=dict(os.environ,LOCAL_FINISH=a.finish,LOCAL_READY=a.ready),start_new_session=True))
for child in children:child.wait()
for case in ['spacegroup_019_spin_half','spacegroup_019_spinless','spacegroup_226_spin_half']:
 d=root/case;r=json.loads((d/'run.json').read_text());r.update(status='failed',exitCode=1)
 if case!='spacegroup_226_spin_half':r['batchExitCode']=1
 if case=='spacegroup_019_spin_half':
  r.update(status='complete',exitCode=0)
  (d/'result.json').write_text(json.dumps(dict(input=json.loads((d/'input.json').read_text()),classification=json.loads((d/'native.json').read_text()),run=r),indent=2,sort_keys=True)+'\n')
 (d/'run.json').write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
(root/'summary.json').write_text(json.dumps({'failed':True,'exitCode':1})+'\n')
sys.exit(1)

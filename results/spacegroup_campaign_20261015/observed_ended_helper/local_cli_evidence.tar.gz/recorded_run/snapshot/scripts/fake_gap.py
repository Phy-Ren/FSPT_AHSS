import json,os,subprocess,sys,time
from pathlib import Path
snapshot=Path(__file__).resolve().parents[1];driver=Path(sys.argv[-1]);finish=os.environ['LOCAL_FINISH']
w=subprocess.Popen([sys.executable,str(snapshot/'scripts/formula_worker.py'),finish])
(Path(os.environ['LOCAL_READY'])/driver.parent.name).write_text(json.dumps({'gap':os.getpid(),'worker':w.pid,'runner':os.getppid()}))
w.wait();sys.exit(1)

import sys,time
from pathlib import Path
while not Path(sys.argv[1]).is_file():time.sleep(.02)

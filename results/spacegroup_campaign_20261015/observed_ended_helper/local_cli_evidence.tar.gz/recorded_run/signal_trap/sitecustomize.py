import json,os
from pathlib import Path
def forbidden(pid,sig):
 with open(os.environ['SIGNAL_TRACE'],'a') as f:f.write(json.dumps({'pid':pid,'signal':int(sig)})+'\n')
 raise AssertionError('Attestation CLI attempted a signal')
os.kill=forbidden;os.killpg=forbidden

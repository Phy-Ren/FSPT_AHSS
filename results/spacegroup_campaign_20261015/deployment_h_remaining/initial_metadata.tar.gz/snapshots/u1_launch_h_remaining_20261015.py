"""One-shot, authorized frozen-H standalone replacements; never stop old jobs."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time

BASE = Path('/home/user/xyren/AllFSPT_insulator')
SOURCE_TAG = 'sgfull-20261015-h'
SOURCE = BASE / 'snapshots' / SOURCE_TAG
EXPECTED = BASE / 'snapshots/u1_h_tail_expected_20261015.json'
PLAN = BASE / 'snapshots/u1_h_remaining_plan_20261015.json'
PYTHON = BASE / 'runtime/bin/python3'
GAP = Path('/home/user/xyren/software/gap-4.13.1-o2-20261015/gap-o2')
FINALIZER = BASE / 'snapshots/u1_finalize_campaign_20261015.py'
GROOTS = [BASE / 'runs' / ('sgfull-20261015-g-' + n) for n in ('n02','n03','n08')]
TAIL = {'spacegroup_%03d_%s' % (n,s) for n in (226,230) for s in ('spinless','spin_half')}
COVERAGE = [('D', 'sgfull-20261015-d-'+n+'-preserved') for n in ('n02','n03','n08')] + [
    ('E','sgfull-20261015-e-smoke'), ('F','sgfull-20261015-f-n02-pilot'),
    ('F','sgfull-20261015-f-n03-pilot'), ('F-preserved','sgfull-20261015-f-n02-pilot-preserved'),
    ('F-preserved','sgfull-20261015-f-n03-pilot-preserved'),
    ('G','sgfull-20261015-g-n02'), ('G','sgfull-20261015-g-n03'), ('G','sgfull-20261015-g-n08'),
    ('H','sgfull-20261015-h-n08'), ('H-tail','sgfull-20261015-h-tail-n08')]
sys.path.insert(0,str(SOURCE))
from scripts.recover_paired_campaign import parse, scientific_checks


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_new(path,value):
    with path.open('x') as stream:
        json.dump(value,stream,indent=2,sort_keys=True)
        stream.write('\n')


def inspect_case(root,case):
    """A valid, fully parsed native is availability evidence, not acceptance."""
    directory=root/case
    record={'root':str(root),'id':case,'sampleUTC':now(),'nativeAvailable':False,
            'ordinaryCompleteValidated':False}
    try:
        native_raw=(directory/'native.json').read_bytes()
        native=parse(native_raw)
        input_raw=(directory/'input.json').read_bytes()
        data=parse(input_raw)
        if data['id'] != case or input_raw != (SOURCE/'insulator_catalog/generated'/(case+'.json')).read_bytes():
            raise ValueError('Input does not match exact frozen-H catalogue bytes')
        record['scientificChecks']=scientific_checks(native,data)
        record['nativeSHA256']=hashlib.sha256(native_raw).hexdigest()
        record['inputSHA256']=hashlib.sha256(input_raw).hexdigest()
        if (directory/'native.json').read_bytes()!=native_raw:
            raise ValueError('Native bytes changed while verifying availability')
        record['nativeAvailable']=True
        try:
            run_raw=(directory/'run.json').read_bytes();run=parse(run_raw)
            result_raw=(directory/'result.json').read_bytes();result=parse(result_raw)
            source=parse((root/'source.json').read_bytes())
            assert run['status']=='complete' and run['exitCode']==0
            assert result['run']==run and result['input']==data and result['classification']==native
            assert run['inputSHA256']==record['inputSHA256'] and run['sourceSHA256']==source['sha256']
            assert run['id']==case
            record.update(ordinaryCompleteValidated=True,resultSHA256=hashlib.sha256(result_raw).hexdigest(),
                          runSHA256=hashlib.sha256(run_raw).hexdigest())
        except (OSError,ValueError,KeyError,AssertionError) as error:
            record['ordinaryResultNote']=type(error).__name__+': '+str(error)
    except (OSError,ValueError,KeyError,AssertionError,TypeError) as error:
        record['availabilityNote']=type(error).__name__+': '+str(error)
    return record


def known_availability(case,first):
    roots=[first]+[BASE/'runs'/tag for _,tag in COVERAGE if BASE/'runs'/tag != first]
    observations=[]
    for root in roots:
        if root==first or (root/case/'native.json').exists():
            item=inspect_case(root,case);observations.append(item)
            if item['nativeAvailable']:
                return True,observations
    return False,observations


def prepare():
    assert not PLAN.exists()
    expected=parse(EXPECTED.read_bytes())
    assert expected['sourceCommit']=='ea44c1f55314ddd66587cf452bbaae9331f3a1db'
    selections={str(root):parse((root/'selection.json').read_bytes()) for root in GROOTS}
    all_ids=[case for selected in selections.values() for case in selected]
    assert len(all_ids)==201 and len(set(all_ids))==201
    observations=[];candidates=[];parent={}
    for root,selected in selections.items():
        for case in selected:
            parent[case]=root
            available,seen=known_availability(case,Path(root))
            observations.extend(seen)
            if not available and case not in TAIL:
                candidates.append(case)
    candidates.sort(key=lambda case:(-len(parse((SOURCE/'insulator_catalog/generated'/(case+'.json')).read_bytes())['multiplication']),case))
    assignments={'n02':candidates[::2],'n03':candidates[1::2]}
    coverage=[];case_map={}
    for family,tag in COVERAGE:
        root=BASE/'runs'/tag
        selected=parse((root/'selection.json').read_bytes())
        coverage.append({'family':family,'root':str(root),'selection':selected,
                         'selectionSHA256':sha(root/'selection.json')})
        for case in selected:
            case_map.setdefault(case,[]).append({'family':family,'root':str(root)})
    universe={'spacegroup_%03d_%s'%(n,s) for n in range(1,231) for s in ('spinless','spin_half')}
    assert set(case_map)==universe
    record={'schema':'u1-h-remaining-plan-v1','preparedUTC':now(),'sourceTag':SOURCE_TAG,
            'expectedSHA256':sha(EXPECTED),'expected':expected,'GSelections':selections,
            'GSelectionSHA256':{root:sha(Path(root)/'selection.json') for root in selections},
            'parentGRoot':parent,'availabilityObservations':observations,'excludedTailCases':sorted(TAIL),
            'candidateCases':candidates,'assignments':assignments,'candidateCount':len(candidates),
            'candidateInputSHA256':{case:sha(SOURCE/'insulator_catalog/generated'/(case+'.json')) for case in candidates},
            'coverageParents':coverage,'fullCoverageMap':case_map,'uniqueCoverageCount':len(case_map),
            'availabilityScope':'Parsed native + saved native completion, chain, root-vector, Smith and filling checks; NOT acceptance or recovery.',
            'role':'Additional H replacements; all original G/H tasks remain untouched; final acceptance is separate.'}
    write_new(PLAN,record)
    print(json.dumps({'plan':str(PLAN),'sha256':sha(PLAN),'candidateCount':len(candidates),
                      'assignments':assignments,'uniqueCoverageCount':len(case_map)},sort_keys=True))


def launch(node,plan_hash):
    assert node in ('n02','n03') and socket.gethostname().split('.')[0]==node
    assert sha(PLAN)==plan_hash
    plan=parse(PLAN.read_bytes());expected=plan['expected'];source=expected['source']
    tag='sgfull-20261015-h-remaining-'+node
    output=BASE/'runs'/tag;launch_path=BASE/'runs'/(tag+'-launch.json')
    assert not any((BASE/'runs'/(tag+suffix)).exists() for suffix in
                  ('','.log','-launch.json','-finalizer-launch.json','-finalizer.log','-finalization.json','-e8','-accepted'))
    assert sha(EXPECTED)==plan['expectedSHA256']
    assert hashlib.sha256(json.dumps(source['files'],sort_keys=True,separators=(',',':')).encode()).hexdigest()==source['sha256']
    for name,value in source['files'].items():
        assert sha(SOURCE/name)==value,name
    assert sha(SOURCE/'insulator/_compiled/u1_dag_vm.so')==expected['formulaRuntime']['librarySHA256']
    assert sha(GAP.parent/'gap')==expected['gapBinarySHA256']
    assert sha(FINALIZER)==expected['finalizerSHA256']
    assert sha(BASE/'snapshots'/(SOURCE_TAG+'.tar.gz'))==expected['archiveSHA256']
    for case in plan['assignments'][node]:
        assert sha(SOURCE/'insulator_catalog/generated'/(case+'.json'))==plan['candidateInputSHA256'][case]
    mem={line.split(':')[0]:int(line.split()[1]) for line in Path('/proc/meminfo').read_text().splitlines() if len(line.split())>=2}
    available=mem.get('MemAvailable',mem.get('MemFree',0)+mem.get('Buffers',0)+mem.get('Cached',0)+mem.get('SReclaimable',0)-mem.get('Shmem',0))
    resources={'sampleUTC':now(),'host':socket.gethostname(),'logicalCPUs':os.cpu_count(),
               'loadAverage':list(os.getloadavg()),'memoryKiB':{k:mem.get(k) for k in
               ('MemTotal','MemAvailable','MemFree','Buffers','Cached','SReclaimable','Shmem')},
               'availableEstimateGiB':available/1024**2,
               'availableEstimateMethod':'MemAvailable or MemFree+Buffers+Cached+SReclaimable-Shmem'}
    cases=[];last_checks=[]
    for case in plan['assignments'][node]:
        assert case not in TAIL and case in plan['GSelections'][plan['parentGRoot'][case]]
        present,seen=known_availability(case,Path(plan['parentGRoot'][case]))
        last_checks.append({'id':case,'excludedAvailable':present,'observations':seen})
        if not present:
            cases.append(case)
    if not cases:
        write_new(launch_path,{'schema':'u1-h-remaining-launch-v1','state':'no-work-after-final-check',
                             'planSHA256':plan_hash,'node':node,'finalAvailabilityChecks':last_checks,
                             'resourcePreflight':resources})
        print(json.dumps({'state':'no-work-after-final-check','launchMetadata':str(launch_path)}));return
    jobs=min(12,len(cases))
    assert available>(jobs*12+32)*1024**2,resources
    assert resources['loadAverage'][0]+jobs<resources['logicalCPUs'],resources
    resources.update(additionalConcurrentJobs=jobs,additionalGAPMemoryCapGiB=jobs*12)
    command=[str(PYTHON),str(SOURCE/'scripts/classify.py'),'--family','spacegroup','--output',str(output),
             '--gap',str(GAP),'--jobs',str(jobs),'--memory','12g','--timeout','14400','--largest-first',
             '--charge-primary','native','--phase-class','cycles','--closed-charge-source','certified',
             '--vacuum-reduction','canonical']
    for case in cases:
        command+=['--case',case]
    env=dict(os.environ,LC_ALL='C',LANG='C',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',U1_DAG_MODE='auto')
    env['PATH']=str(BASE/'runtime/bin')+':'+env['PATH']
    report={'schema':'u1-h-remaining-launch-v1','state':'prepared','tag':tag,'node':node,
            'sourceTag':SOURCE_TAG,'sourceCommit':expected['sourceCommit'],'source':source,
            'snapshotSHA256':expected['archiveSHA256'],'planPath':str(PLAN),'planSHA256':plan_hash,
            'expectedSHA256':sha(EXPECTED),'launcherSHA256':sha(Path(__file__)),
            'command':command,'output':str(output),'log':str(BASE/'runs'/(tag+'.log')),
            'proposedCases':plan['assignments'][node],'cases':cases,'caseCount':len(cases),
            'finalAvailabilityChecks':last_checks,'excludedTailCases':sorted(TAIL),
            'jobs':jobs,'paired':False,'memoryPerJob':'12g','timeoutSecondsPerCase':14400,
            'sourceVerifiedBeforeLaunch':True,
            'inputSHA256':{case:plan['candidateInputSHA256'][case] for case in cases},
            'formulaRuntime':expected['formulaRuntime'],'formulaRuntimeVerifiedBeforeLaunch':True,
            'gapLauncherSHA256':sha(GAP),'gapBinarySHA256':sha(GAP.parent/'gap'),
            'finalizerSHA256':sha(FINALIZER),'resourcePreflight':resources,
            'recordedEnvironment':{k:env[k] for k in ('LC_ALL','LANG','OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','U1_DAG_MODE','PATH')},
            'role':plan['role'],'availabilityScope':plan['availabilityScope']}
    write_new(launch_path,report)
    with (BASE/'runs'/(tag+'.log')).open('x') as log:
        runner=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,env=env,cwd=SOURCE,
                                stdin=subprocess.DEVNULL,start_new_session=True)
    report.update(state='launched',pid=runner.pid,startedUTC=now())
    launch_path.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    for unused in range(100):
        if all((output/name).is_file() for name in ('selection.json','source.json','formula_runtime.json')):
            break
        if runner.poll() is not None:
            raise RuntimeError('New runner exited before metadata: '+str(runner.returncode))
        time.sleep(.2)
    else:
        raise RuntimeError('New runner metadata not ready; runner left untouched')
    assert set(parse((output/'selection.json').read_bytes()))==set(cases)
    assert parse((output/'source.json').read_bytes())==source
    assert parse((output/'formula_runtime.json').read_bytes())==expected['formulaRuntime']
    final_command=[str(PYTHON),str(FINALIZER),'--tag',tag,'--runner-pid',str(runner.pid),'--node',node,'--source-tag',SOURCE_TAG]
    with (BASE/'runs'/(tag+'-finalizer.log')).open('x') as log:
        finalizer=subprocess.Popen(final_command,stdout=log,stderr=subprocess.STDOUT,env=env,
                                   stdin=subprocess.DEVNULL,start_new_session=True)
    write_new(BASE/'runs'/(tag+'-finalizer-launch.json'),{'pid':finalizer.pid,'command':final_command,
              'runnerPID':runner.pid,'finalizerSHA256':sha(FINALIZER),'sourceTag':SOURCE_TAG,'node':node})
    report.update(finalizerPID=finalizer.pid,campaignMetadataVerified=True)
    launch_path.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'state':'launched','node':node,'runnerPID':runner.pid,'finalizerPID':finalizer.pid,
                      'launchMetadata':str(launch_path),'cases':cases,'output':str(output),
                      'resourcePreflight':resources},sort_keys=True))


if __name__=='__main__':
    if sys.argv[1:] == ['prepare']:
        prepare()
    elif len(sys.argv)==4 and sys.argv[1]=='launch':
        launch(sys.argv[2],sys.argv[3])
    else:
        raise SystemExit('Use prepare, or launch NODE PLAN_SHA256')

#!/usr/bin/env python3
"""Bounded read-only logs and process-counter samples; no signals or tracing."""
import datetime
import json
import subprocess
from pathlib import Path

NODE = r'''
import datetime,json,os,time
from pathlib import Path
targets=TARGETS
base=Path('/home/user/xyren/AllFSPT_insulator/runs')
def processes():
 rows={}; hz=float(os.sysconf('SC_CLK_TCK')); up=float(Path('/proc/uptime').read_text().split()[0])
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   if p.stat().st_uid != os.getuid():continue
   args=[a.decode('utf8','replace') for a in (p/'cmdline').read_bytes().split(b'\0') if a]
   st=(p/'stat').read_text().split(') ',1)[1].split()
   fields={x.split(':',1)[0]:x.split(':',1)[1].strip() for x in (p/'status').read_text().splitlines() if ':' in x}
   io={x.split(':',1)[0]:int(x.split(':',1)[1]) for x in (p/'io').read_text().splitlines() if ':' in x}
   rows[int(p.name)]={'pid':int(p.name),'ppid':int(st[1]),'state':st[0],'startTicks':int(st[19]),'cpuSeconds':(int(st[11])+int(st[12]))/hz,'elapsedSeconds':up-int(st[19])/hz,'rssKiB':int(fields.get('VmRSS','0 kB').split()[0]),'args':args,'io':io}
  except (OSError,ValueError,IndexError):pass
 return time.monotonic(),rows
def tail(path):
 if not path.exists():return {'present':False}
 st=path.stat()
 with path.open('rb') as f:
  f.seek(max(0,st.st_size-8192)); data=f.read(8192)
 return {'present':True,'bytes':st.st_size,'mtimeNs':st.st_mtime_ns,'lastBytes':data.decode('utf8','replace')}
t0,before=processes();time.sleep(2);t1,after=processes();dt=t1-t0
out=[]
for tag,cid in targets:
 case=base/tag/cid;run=json.loads((case/'run.json').read_text())
 driver=str(case/'driver.g')
 gaps=[r for r in after.values() if r['args'] and r['args'][-1]==driver and 'gap-4.13.1-o2' in r['args'][0]]
 procs=[]
 for gap in gaps:
  gap['kind']='GAP';procs.append(gap)
  for r in after.values():
   if r['ppid']==gap['pid'] and any(x.endswith('/scripts/formula_worker.py') for x in r['args']):r['kind']='formulaWorker';procs.append(r)
 for r in procs:
  b=before.get(r['pid'])
  if b and b['startTicks']==r['startTicks']:
   r['sampleCPUPercent']=100*(r['cpuSeconds']-b['cpuSeconds'])/dt
   r['sampleIODeltas']={k:r['io'][k]-b['io'].get(k,0) for k in r['io']}
 out.append({'tag':tag,'id':cid,'run':run,'stdout':tail(case/'stdout.log'),'stderr':tail(case/'stderr.log'),'nativeBytes':(case/'native.json').stat().st_size if (case/'native.json').exists() else 0,'processes':procs})
print(json.dumps({'sampleUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sampleSeconds':dt,'cases':out},sort_keys=True))
'''

TARGETS = {'n08': [('sgfull-20261015-h-tail-spinless-n08', 'spacegroup_226_spinless')]}
REMOTE = r'''
import concurrent.futures,json,subprocess
node_code=NODE_CODE
targets=TARGET_MAP
def run(node):
 code=node_code.replace('TARGETS',repr(targets[node]))
 p=subprocess.run(['ssh','-o','BatchMode=yes','-o','ControlMaster=no','-o','ControlPath=/home/user/xyren/.ssh/cm-%r@%h:%p',node,'env LC_ALL=C LANG=C python3 -'],input=code.encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 if p.returncode:return {'node':node,'exitCode':p.returncode,'error':p.stderr.decode()}
 data=json.loads(p.stdout.decode());data['node']=node;return data
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:print(json.dumps(list(pool.map(run,sorted(targets))),sort_keys=True))
'''.replace('NODE_CODE', repr(NODE)).replace('TARGET_MAP', repr(TARGETS))
p = subprocess.run(['ssh', '-o', 'ControlMaster=no', '-o', 'ProxyCommand=false', 'cuhk-cluster3', 'bash -s'], input="python3 - <<'PROGRESS_PY'\n"+REMOTE+"\nPROGRESS_PY\n", text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
rows = json.loads(p.stdout)
stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
path = Path(__file__).resolve().parent / ('last_226_progress_'+stamp+'.json')
path.write_text(json.dumps(rows, indent=2, sort_keys=True)+'\n')
print(json.dumps({'path':str(path),'nodes':rows},indent=2,sort_keys=True))

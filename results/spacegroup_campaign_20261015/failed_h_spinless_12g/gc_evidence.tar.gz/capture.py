#!/usr/bin/env python3
"""Read and hash completed remote perf artifacts; no samples or process actions."""
import hashlib,io,json,subprocess,tarfile
from pathlib import Path
BASE=Path(__file__).resolve().parent
REMOTE=r'''
import datetime,hashlib,io,json,sys,tarfile
from pathlib import Path
root=Path('/home/user/xyren/AllFSPT_insulator/runs/sg226-spinless-readonly-perf-20261015T1839')
def load():
 files={}
 for p in sorted(root.rglob('*')):
  assert not p.is_symlink(),str(p)
  if p.is_file():files[str(p.relative_to(root))]=p.read_bytes()
 return files
files=load();assert files and files==load(),'Remote evidence changed across reads'
metadata={'remoteRoot':str(root),'captureUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'twoReadsEqual':True,'files':{name:{'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)} for name,data in files.items()},'readOnlyCapture':True,'newSamples':False,'signalsSent':False}
with tarfile.open(fileobj=sys.stdout.buffer,mode='w|gz') as tar:
 for name,data in sorted(files.items()):
  info=tarfile.TarInfo('raw/'+name);info.size=len(data);tar.addfile(info,io.BytesIO(data))
 data=(json.dumps(metadata,indent=2,sort_keys=True)+'\n').encode();info=tarfile.TarInfo('capture.json');info.size=len(data);tar.addfile(info,io.BytesIO(data))
'''
command=['ssh','-o','ControlMaster=no','-o','ProxyCommand=false','cuhk-cluster3','bash -s']
p=subprocess.run(command,input=("python3 - <<'CAPTURE_PY'\n"+REMOTE+"\nCAPTURE_PY\n").encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
(BASE/'capture.stderr.log').write_bytes(p.stderr)
archive=BASE/'raw.tar.gz';assert not archive.exists();archive.write_bytes(p.stdout)
files={}
with tarfile.open(fileobj=io.BytesIO(p.stdout),mode='r:gz') as tar:
 for item in tar.getmembers():
  path=Path(item.name)
  assert item.isfile() and not path.is_absolute() and '..' not in path.parts and item.name not in files
  files[item.name]=tar.extractfile(item).read()
metadata=json.loads(files['capture.json']);assert set(files)=={'capture.json'}|{'raw/'+x for x in metadata['files']}
for name,expected in metadata['files'].items():
 data=files['raw/'+name];assert len(data)==expected['bytes'] and hashlib.sha256(data).hexdigest()==expected['sha256']
for name,data in files.items():
 out=BASE/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data)
proof={'archiveSHA256':hashlib.sha256(p.stdout).hexdigest(),'archiveBytes':len(p.stdout),'remoteFileCount':len(metadata['files']),'allRemoteAndLocalMemberHashesAgree':True,'command':command,'noNewSamplesOrSignals':True}
(BASE/'download.json').write_text(json.dumps(proof,indent=2,sort_keys=True)+'\n')
print(json.dumps(proof,sort_keys=True))

#!/usr/bin/env python3
"""Offline byte and process-identity checks; no remote access or sampling."""
import hashlib
import io
import json
from pathlib import Path
import tarfile

BASE = Path(__file__).resolve().parent
sha = lambda value: hashlib.sha256(value).hexdigest()
read = lambda name: json.loads((BASE / name).read_bytes())
manifest = read('manifest.json')['filesSHA256']
assert set(manifest) == {str(p.relative_to(BASE)) for p in BASE.rglob('*')
                         if p.is_file() and p.name != 'manifest.json'}
for name, expected in manifest.items():
    assert sha((BASE / name).read_bytes()) == expected, name
archive = (BASE / 'raw.tar.gz').read_bytes()
assert sha(archive) == read('download.json')['archiveSHA256']
with tarfile.open(fileobj=io.BytesIO(archive), mode='r:gz') as tar:
    members = {}
    for item in tar.getmembers():
        assert item.isfile() and item.name not in members
        assert not Path(item.name).is_absolute() and '..' not in Path(item.name).parts
        members[item.name] = tar.extractfile(item).read()
metadata = read('capture.json')
assert members['capture.json'] == (BASE / 'capture.json').read_bytes()
assert set(members) == {'capture.json'} | {'raw/' + n for n in metadata['files']}
for name, expected in metadata['files'].items():
    data = members['raw/' + name]
    assert data == (BASE / 'raw' / name).read_bytes()
    assert len(data) == expected['bytes'] and sha(data) == expected['sha256']
paths = ['last_226_progress_20261015T183422Z.json', 'last_226_tensecond_20261015T183740Z.json']
rows = [read('monitoring/' + name)[0]['cases'][0] for name in paths]
g0, w0 = rows[0]['processes']
g1, w1 = rows[1]['processes']
assert (g0['pid'], g0['startTicks']) == (g1['pid'], g1['startTicks']) == (11603, 2689930714)
assert (w0['pid'], w0['startTicks']) == (w1['pid'], w1['startTicks'])
assert g0['rssKiB'] == g1['rssKiB'] == 12599444
assert g0['io'] == g1['io'] and w0['io'] == w1['io']
assert w0['cpuSeconds'] == w1['cpuSeconds']
link = read('linkage.json')
assert round(g1['cpuSeconds'] - g0['cpuSeconds'], 3) == link['gapCPUIncreaseSeconds']
assert all(row['run']['sourceSHA256'] == link['sourceSHA256'] for row in rows)
perf = read('raw/observation.json')
assert perf['targetPID'] == g1['pid'] and int(perf['targetStartTicks']) == g1['startTicks']
assert perf['targetCommand'] == g1['args'] == g0['args']
assert perf['command'][-2:] == ['sleep', '5'] and perf['exitCode'] == 0
assert "Samples: 244" in (BASE / 'raw/report.txt').read_text()
print(json.dumps({'verified': True, 'remoteFiles': len(metadata['files']),
                  'sameExactProcessIdentity': True, 'newSamplesTaken': False,
                  'sourceVerificationScope': link['sourceHashBasis']}, sort_keys=True))

# SG226 spinless: bounded GC observation and separate monitoring

This read-only capture preserves all six original files from
`/runs/sg226-spinless-readonly-perf-20261015T1839/`, including the 24,900-byte
`perf.data`, reports, stderr warnings and exact PID/start/argv observation.
The acquisition read every remote file twice, required identical bytes, and
independently verified every local member against its remote SHA256.
The compressed acquisition archive SHA256 is
`6b795544649f70a86185eca9be8517b3194042f08fcd96ce66cd188128595d73`;
the original `perf.data` SHA256 is
`6ba1cbb8ab9d8ce1c5b7dec9cc9591582493f251ae59a52828269270260e557a`.

The original diagnostic sampled user CPU for five seconds at 49 Hz, targeting
GAP PID11603/startTicks2689930714. Its 244 samples are reported as 91.80%
`CollectBags`, 6.15% `MarkArrayOfBags`, and the remainder in three GC marking
functions. This directly identifies garbage collection within that short
profile window. Percentages describe sampled user CPU, not the entire run's
wall time. Kernel-symbol restriction warnings are retained unchanged.

Separately, copied read-only monitoring records at 18:34:53.584865 and
18:38:11.765293 UTC show the same PID/start/argv, identical 12,599,444 KiB GAP
RSS at both endpoints, 198.30 additional GAP CPU seconds, and unchanged GAP
and worker pipe counters. The worker's CPU counter also remains unchanged.
The latter record includes a ten-second two-endpoint observation. These
longer observations establish no formula IPC over that interval; they do not
independently identify its internal instructions. Do not extend the direct
five-second GC attribution to every second of the longer interval.

`linkage.json` binds the exact process identity across both kinds of evidence
and records the original formal run's H source SHA256. The perf observation
itself records `sourceUnchanged: true`; this acquisition did not launch a new
source verification. The original 12g job was neither changed nor stopped.
This evidence supports review of a larger-workspace alternative but does
not prove the original job cannot eventually complete.

No new sampling, tracing, classification or process signals occurred during
this capture. It changes no accepted-case count or physical claim.

# 2+1D: the complete four-data endpoint

The ordered fields are `(e_0,n_0,n_2,nu_3)`. Responses are normalized as
`sigma_xy=n_0`, `c_minus=n_0+8e_0`. The common charge blocks and cochain
conventions are defined in [the four-data reference](OPERATIONS.md).
This file concerns only 2+1D.

<a id="obstructions-2d"></a>

## Obstruction functions

```math
d_s e_0=d_s n_0=0,\qquad
d_\rho n_2=-d_{\rho+s}\omega_R\cup n_0,
```
```math
d_s\nu_3=\widehat O_4
 =\widehat O^c_4(n_2)+\frac{n_0}{2}\mathcal P_{\rho+s}(\omega_R),
\qquad \mathcal P_\chi(x)=x\cup x+x\cup_1d_\chi x.
```

Use the unshifted extension lift at this endpoint. The E8 coordinate has
no extra group-cochain source in the neutral tensor convention; its
gravitational response remains in `c_minus`. For actual group cochains,
nontrivial `s` forces both uniform integers to vanish. When `s=0`, the
uniform integers are constants, but a proposed `n_0` still needs charge
and phase completions.

The local interface enforces this group-cochain domain. A vertex-dependent
parallel signed zero-cochain on a contractible simplex does not permit a
nonzero uniform response with nontrivial `s`. Closure of that artificial
local zero-cochain alone is insufficient; nonzero `e_0,n_0` require the
trivial chirality character.

The integer source represents `d3`. After charge completion, the terminal
source represents `d4` in its permitted quotient. On closed charge it
restricts to `d2`. The open charge source is explicitly

```math
\widehat O^c_4(n_2)=\omega_R n_2+\tfrac12
 [\bar n_2\cup\bar n_2+\bar n_2\cup_1d\bar n_2].
```

<a id="stacking-2d"></a>

## Stacking twisters

For completed inputs the three lower coordinates add. The phase is

```math
\Nu_3=\nu_3+\nu'_3+\widehat E_3,
```
```math
\boxed{\widehat E_3=\tfrac12
 [\bar n_2\cup_1\bar n'_2+d\bar n_2\cup_2\bar n'_2]
 +\tfrac14 n_0n'_0\,\overline{d_{\rho+s}\omega_R}.}
```

The last overbar means the canonical binary lift of the entire connecting
cochain, not an arbitrary integral representative. This quarter-valued
term cancels the open-charge polarization residual. Uniform E8 adds
independently in the selected coordinates.

These are the fixed v0.7 endpoint formulas with E8 first. Their universal
physical nonzero-IQH product-coordinate comparison remains unproved;
this is separate from the fact that the displayed multiplication is fixed.

<a id="gauges-2d"></a>

## Gauges and incoming phases

There is no degree-minus-one gauge for either uniform integer. For
`u_1 in C1(G,Z_rho)` and `lambda_2 in C2(G,R/Z_s)`,

```math
e_0^g=e_0,\quad n_0^g=n_0,\quad n_2^g=n_2+d_\rho u_1,
\qquad
\nu_3^g=\nu_3+\widehat G^c_3(u_1;n_2)+d_s\lambda_2.
```

The full charge gauge is given in the common reference. For closed `u_1`,
its Steenrod term vanishes by instability and the incoming phase class is
`[omega_R cup u_1]`. It is included before extracting root relations.
A zero raw self-twister does not imply a trivial square: the completed
root's initial phase and its charge-removal gauge also contribute.

## Background representative transport

This supplies the endpoint transport absent from the earlier runtime.
For integral `z_2` or real `alpha_1`, both of sign `rho+s`, use

```math
\omega_R'=\omega_R+z_2,\quad n'_2=n_2-z_2\cup n_0,
\qquad\text{or}\qquad
\omega_R'=\omega_R+d_{\rho+s}\alpha_1,\quad n'_2=n_2.
```

Both uniform coordinates remain unchanged. Let the height `eta` on `I`
equal zero and one at its endpoints. For a lift change set

```math
\omega_R^I=\omega_R+\eta z_2,\qquad
n_2^I=n_2-(\eta z_2)\cup n_0.
```

For a section change set

```math
\omega_R^I=\omega_R+d_{\rho+s}(\eta\alpha_1),\qquad n_2^I=n_2.
```

The specified phase correction is

```math
T_3=\mathcal I_1\widehat O_4(\omega_R^I;n_0,n_2^I),\qquad
\nu'_3=\nu_3+T_3.
```

`I1` is the parameter-first signed prism sum: exactly four source
evaluations on a base three-simplex, not an unspecified primitive.
The cylinder solves the lower equation because `d_s n_0=0`; in particular
`d_rho((eta z_2) cup n_0)=d_(rho+s)(eta z_2) cup n_0`.
For a section change use `d^2=0`. Source closure and signed Stokes yield
`d_s T_3=Ohat_4(new)-Ohat_4(old)`. Applying the natural source/product
identity on the parameter product gives compatibility with stacking up
to the induced phase coboundary. `background_change` implements this rule.

## Uniform responses and physical comparison

Both uniform responses `e_0,n_0` belong to the current four-data state.
A fixed nonzero response fiber is not a group. When comparing different
response restrictions, state the restriction explicitly; never identify
a fixed fiber with the group containing all allowed uniform responses.

The [uniform-response proof](../e8/research/general_groups/uniform_abstract_group_2p1.md)
is an auxiliary existence check. Abstract splitting does not replace the
explicit differentials, twister, or physical nonzero-IQH comparison.
No new global E8-inclusive table is asserted by this local specification.

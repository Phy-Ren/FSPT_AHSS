#!/bin/bash
export LC_ALL=C
export LANG=C
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export PATH=/home/user/xyren/AllFSPT_insulator/runtime/bin:$PATH
cd /home/user/xyren/AllFSPT_insulator/snapshots/f572a98
python3 scripts/classify.py  --case point2_02_spinless --case point2_02_spin_half --case point2_04_spinless --case point2_04_spin_half --case point2_05_spinless --case point2_05_spin_half --case point2_06_spinless --case point2_06_spin_half --case point2_09_spinless --case point2_09_spin_half --case point2_10_spinless --case point2_10_spin_half --case wallpaper_04_spinless --case wallpaper_04_spin_half --case wallpaper_08_spinless --case wallpaper_08_spin_half --case wallpaper_10_spinless --case wallpaper_10_spin_half --case wallpaper_12_spinless --case wallpaper_12_spin_half --case wallpaper_17_spinless --case wallpaper_17_spin_half  --jobs 6 --timeout 7200 --memory 8g --gap /home/user/xyren/software/gap-4.13.1/gap --output /home/user/xyren/AllFSPT_insulator/runs/f572a98-special2-n0-zero

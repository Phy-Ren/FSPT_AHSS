#!/bin/bash
export LC_ALL=C
export LANG=C
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export PATH=/home/user/xyren/AllFSPT_insulator/runtime/bin:$PATH
cd /home/user/xyren/AllFSPT_insulator/snapshots/f572a98
python3 scripts/classify.py --family point3 --spin spinless --jobs 12 --timeout 7200 --memory 8g --gap /home/user/xyren/software/gap-4.13.1/gap --output /home/user/xyren/AllFSPT_insulator/runs/f572a98-point3-spinless

#!/usr/bin/env python3
"""Build the current insulator catalogue from accepted calculations and references.

One row is one exact crystalline input and response sector. Reference values
never enter a calculation. Historical inputs and outputs are read-only.
"""
from __future__ import annotations

import argparse
from collections import Counter
from copy import deepcopy
import csv
import hashlib
import json
import os
from pathlib import Path

from build_foundation_tables import group_text, signature
from summarize_results import uniform_multiplicity

ROOT = Path(__file__).resolve().parents[1]
SPINS = {"spinless": "Spinless", "spin_half": "Spin-1/2"}
ZERO = {"torsion": [], "freeRank": 0}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return json.dumps(value, ensure_ascii=False, indent=2) + "\n"


class Catalogue:
    def __init__(self, output):
        self.output = output
        self.inputs, self.files, self.index = {}, {}, []
        saved_path = "results/two_dimensional_20261013/results.json"
        fresh_path = "results/four_data_campaign_20261015/results.json"
        e8_path = "results/four_data_campaign_20261015/e8_results.json"
        self.records = {}
        for position, record in enumerate(self.load(saved_path)):
            case = record["input"]["id"]
            assert record["input"]["dimension"] == 2
            self.records[case, "n0_all"] = self.entry(record, record["classification"], saved_path, position)
            self.records[case, "n0_zero"] = self.entry(
                record, record["classification"]["relativeUniformIQH0"], saved_path,
                position, "classification.relativeUniformIQH0")
        for position, record in enumerate(self.load(fresh_path)):
            if record["input"]["dimension"] != 2:
                continue
            sector = "n0_all" if record["run"]["uniformIQHRequested"] else "n0_zero"
            self.records[record["input"]["id"], sector] = self.entry(
                record, record["classification"], fresh_path, position)
        for position, record in enumerate(self.load(e8_path)):
            assert record["input"]["dimension"] == 3
            assert record["classification"]["neutralE8Included"] is True
            self.records[record["input"]["id"], "four_data"] = self.entry(
                record, record["classification"], e8_path, position)

    def load(self, name):
        data = (ROOT / name).read_bytes()
        self.inputs[name] = digest(data)
        return json.loads(data)

    def entry(self, record, classification, path, position, selector="classification"):
        assert record["run"]["status"] == "complete"
        return {"input": record["input"], "classification": classification,
                "provenance": {"path": path, "array_index": position, "selector": selector,
                               "source_sha256": record["run"]["sourceSHA256"],
                               "input_sha256": record["run"]["inputSHA256"],
                               "started_utc": record["run"].get("startedUTC"),
                               "record_sha256": digest(json.dumps(record, sort_keys=True, separators=(",", ":")).encode())}}

    def put(self, path, text):
        self.files[str(path)] = text

    @staticmethod
    def layer(classification, name):
        return signature({"torsion": classification["final" + name + "Orders"],
                          "freeRank": classification["final" + name + "FreeRank"]})

    @staticmethod
    def cell(group):
        return {"availability": "available", "comparison_status": "not_compared",
                "group": signature(group)}

    @staticmethod
    def reference(cell, actual):
        result = deepcopy(cell)
        if result["availability"] == "available" and "group" in result:
            result["comparison_status"] = "match" if signature(result["group"]) == signature(actual) else "mismatch"
        return result

    def table(self, dimension, spin, family, sector):
        label = SPINS[spin]
        stem = "wallpaper_groups" if family == "wallpaper" else "point_groups"
        if dimension == 2:
            template_path = f"results/foundation_review_20261014/2p1d/{spin}/e0_zero/{sector}/{stem}.json"
            destination = Path("2p1d") / spin / sector / stem
            response = "n0=0, e0=0" if sector == "n0_zero" else "all allowed n0, e0=0"
            scope = ("The uniform E8 response is fixed to e0=0. "
                     + ("The uniform IQH response is fixed to n0=0. " if sector == "n0_zero" else
                        "All symmetry-allowed uniform IQH responses are included. ")
                     + "The four data columns are final filtration groups after incoming identifications; their product need not be the final stacking group.")
            refs = (["Debray_relative", "R2_journal", "R2_arxiv"] if sector == "n0_zero" else
                    ["Debray_e0_zero", "R2_journal", "R2_arxiv"]) if family == "point2" else (
                    ["R2_journal", "R2_arxiv", "MCB_relative", "L2_charge", "L2_phase"] if sector == "n0_zero" else
                    ["R2_journal", "R2_arxiv", "MCB_e0_zero"])
        else:
            template_path = f"results/four_data_campaign_20261015/3p1d/{spin}/with_e8/{stem}.json"
            destination = Path("3p1d") / spin / stem
            response = "four-data model"
            scope = ("The selected E8 section is included through the independently computed H1(G,Z_s). "
                     "The four data columns are final filtration groups; stacking includes their extensions. "
                     "Identification of the computed CI kernel with the complete physical theory remains conditional. "
                     "Reference columns give full interacting classifications, including neutral E8 contributions.")
            refs = ["Debray", "NMLW", "R3_arxiv", "R3_journal"]
        template = self.load(template_path)
        p = dimension - 2
        columns = [{"key": key, "label": text} for key, text in (
            ("e", f"e{p} (E8)"), ("n", f"n{p} (CI)"),
            ("charge", f"n{p+2} (charge)"), ("phase", f"nu{p+3} (phase)"),
            ("stacking", "Final stacking"))]
        labels = {c["key"]: c["label"] for c in template["columns"]}
        columns += [{"key": key, "label": labels[key]} for key in refs]
        rows = []
        for old in template["rows"]:
            record = self.records[old["id"], sector]
            data, classification = record["input"], record["classification"]
            assert (data["dimension"], data["spin"], data["family"], data["name"]) == (dimension, spin, family, old["name"])
            ci = classification if dimension == 2 else classification["ciSector"]
            layers = {"e": ZERO if dimension == 2 else signature(classification["e8H1"]),
                      "n": ZERO if sector == "n0_zero" else self.layer(ci, "Sheet"),
                      "charge": self.layer(ci, "Charge"), "phase": self.layer(ci, "Phase")}
            cells = {key: self.cell(value) for key, value in layers.items()}
            cells["stacking"] = self.cell(classification)
            for key in refs:
                target = layers[key[3:]] if key in ("L2_charge", "L2_phase") else classification
                cells[key] = self.reference(old["cells"][key], target)
            row = {"id": data["id"], "name": data["name"], "hermann_mauguin": old["hermann_mauguin"],
                   "family": family, "physical_spin": spin, "spatial_dimension": dimension,
                   "spacetime_dimension": dimension + 1, "n0_scope": sector if dimension == 2 else "not_applicable",
                   "e0_scope": "e0_zero" if dimension == 2 else "not_applicable",
                   "e8_scope": "fixed_uniform_zero" if dimension == 2 else "selected_section_included",
                   "cells": cells, "provenance": deepcopy(record["provenance"])}
            if sector == "n0_all":
                row["uniform_iqh_image"] = uniform_multiplicity(classification)
            rows.append(row)
            self.index.append({**{k: deepcopy(v) for k, v in row.items() if k != "cells"},
                "table": str(destination.with_suffix(".json")),
                "stacking": signature(classification), "final_filtration": deepcopy(layers)})
        sources = {}
        for reference in refs:
            key = next(key for key in template["sources"]
                       if reference == key or reference.startswith(key + "_"))
            sources.setdefault(key, deepcopy(template["sources"][key]))
        table = {"title": f"{dimension}+1D {label} {family.replace('point2', 'point groups').replace('point3', 'point groups').replace('wallpaper', 'wallpaper groups')}: {response}",
                 "scope": scope, "spatial_dimension": dimension, "spacetime_dimension": dimension+1,
                 "physical_spin": spin, "family": family, "n0_scope": sector if dimension == 2 else "not_applicable",
                 "e0_scope": "e0_zero" if dimension == 2 else "not_applicable",
                 "e8_scope": "fixed_uniform_zero" if dimension == 2 else "selected_section_included",
                 "columns": columns, "sources": sources, "rows": rows}
        self.render(destination, table)

    def render(self, destination, table):
        keys = [c["key"] for c in table["columns"]]
        table["comparison_counts"] = {key: dict(Counter(row["cells"][key]["comparison_status"] for row in table["rows"])) for key in keys}
        table["availability_counts"] = {key: dict(Counter(row["cells"][key]["availability"] for row in table["rows"])) for key in keys}
        self.put(destination.with_suffix(".json"), encoded(table))
        headers = ["Group (HM)"] + [c["label"] for c in table["columns"]]
        def display(cell, markdown):
            if cell["availability"] != "available":
                return {"unverified": "UNVERIFIED", "not_applicable": "N/A", "not_computed": "NOT COMPUTED"}[cell["availability"]]
            mark = {"match": "✓", "mismatch": "×"}.get(cell["comparison_status"], "")
            prefix = (f"**{mark}** " if markdown else mark + " ") if mark else ""
            return prefix + group_text(cell["group"]) + (" †" if cell.get("proof_audit") else "")
        lines = ["# " + table["title"], "", table["scope"], "",
                 "**✓** same reported classification group; **×** different reported classification group. UNVERIFIED is not a match.", "",
                 "| " + " | ".join(headers) + " |", "| " + " | ".join(["---"]*len(headers)) + " |"]
        for row in table["rows"]:
            lines.append("| " + " | ".join([f"{row['name']} ({row['hermann_mauguin']})"] + [display(row["cells"][key], True) for key in keys]) + " |")
        audits = {cell["proof_audit"]["path"] for row in table["rows"] for cell in row["cells"].values() if cell.get("proof_audit")}
        for audit in sorted(audits):
            link = os.path.relpath(ROOT / audit, self.output / destination.parent)
            lines += ["", f"† Printed source values are preserved; see the [supporting-proof grading audit]({link})."]
        lines += ["", "Sources:", ""]
        for key, source in table["sources"].items():
            authors = source.get("authors", source.get("author", ""))
            if isinstance(authors, list):
                authors = ", ".join(authors)
            lines.append(f"- [{authors}, {source.get('version', source.get('year', ''))}]({source['url']}). "
                         + source.get("title", "") + ". " + source.get("location", "") + ". " + source.get("method", "") + ".")
        provenance = os.path.relpath(self.output / "PROVENANCE.md", self.output / destination.parent)
        lines += ["", f"[Calculation provenance and scope]({provenance}).", ""]
        self.put(destination.with_suffix(".md"), "\n".join(lines))
        import io
        stream = io.StringIO(newline="")
        writer = csv.writer(stream, lineterminator="\n")
        writer.writerow(["id", "physical_spin", "spatial_dimension", "n0_scope", "e0_scope", "e8_scope"] + headers)
        for row in table["rows"]:
            writer.writerow([row[k] for k in ("id", "physical_spin", "spatial_dimension", "n0_scope", "e0_scope", "e8_scope")]
                            + [f"{row['name']} ({row['hermann_mauguin']})"] + [display(row["cells"][key], False) for key in keys])
        self.put(destination.with_suffix(".csv"), stream.getvalue())

    def build(self):
        for spin in SPINS:
            for sector in ("n0_zero", "n0_all"):
                for family in ("point2", "wallpaper"):
                    self.table(2, spin, family, sector)
            self.table(3, spin, "point3", "four_data")
        assert len(self.index) == len(self.records) == 172
        assert len({(x["id"], x["n0_scope"]) for x in self.index}) == 172
        self.index.sort(key=lambda r: (r["spatial_dimension"], r["physical_spin"], r["n0_scope"], r["id"]))
        self.put("index.json", encoded(self.index))
        self.put("README.md", "# Computed U(1)^f insulator examples\n\n"
                 "The current catalogue contains 118 crystalline backgrounds: 54 in 2+1D and 64 in 3+1D. "
                 "Each 2+1D background has separate n0=0 and all-allowed-n0 tables, both with e0=0. "
                 "The 3+1D tables include the computed neutral E8 section.\n\n"
                 "- [2+1D: point groups and wallpaper groups](2p1d/README.md).\n"
                 "- [3+1D: point groups](3p1d/README.md).\n\n"
                 "Each row gives the four final data layers, final stacking group, and separately cited interacting references. "
                 "Physical spins and response sectors have separate files. **✓** marks the same reported group; **×** marks a different reported group.\n\n"
                 "[Calculation provenance and scope](PROVENANCE.md) · [Machine-readable example index](index.json).\n")
        for d in (2, 3):
            self.put(f"{d}p1d/README.md", f"# {d}+1D insulator examples\n\n"
                     + "\n".join(f"- [{label}]({spin}/README.md)." for spin, label in SPINS.items()) + "\n")
            for spin, label in SPINS.items():
                base = f"{d}p1d/{spin}"
                if d == 2:
                    self.put(base + "/README.md", f"# 2+1D {label}\n\nUniform E8 response: e0=0.\n\n"
                             "- [n0=0](n0_zero/README.md).\n- [All allowed n0](n0_all/README.md).\n")
                    for sector, scope in (("n0_zero", "n0=0"), ("n0_all", "all allowed n0")):
                        self.put(base + f"/{sector}/README.md", f"# 2+1D {label}: {scope}, e0=0\n\n"
                                 "- [Point groups](point_groups.md) · [CSV](point_groups.csv).\n"
                                 "- [Wallpaper groups](wallpaper_groups.md) · [CSV](wallpaper_groups.csv).\n")
                else:
                    self.put(base + "/README.md", f"# 3+1D {label}\n\n"
                             "- [Point groups, with E8 data](point_groups.md) · [CSV](point_groups.csv).\n")
        self.put("PROVENANCE.md", "# Calculation provenance and scope\n\n"
                 "The catalogue selects one accepted calculation per exact input and response sector. It uses the 64 completed E8-inclusive point-group records and 44 completed 2+1D records from the October 15 campaign. "
                 "The remaining 64 2+1D sector entries use the exhaustive October 13 campaign. For an entry without a separate n0=0 rerun, its value is the saved kernel of the actual IQH response homomorphism, not an inferred removal of a free factor. "
                 "Dates, input/source hashes, immutable record locations and exact selectors are retained in [index.json](index.json); consumed file hashes are in [manifest.json](manifest.json).\n\n"
                 "The final filtration columns are e_p, n_p, n_(p+2), nu_(p+3), with p=d−2. They already include the computed incoming identifications. Their direct product is not assumed to equal the final stacking group. "
                 "The 2+1D tables impose e0=0; the 3+1D tables include independently computed H1(G,Z_s) and the selected E8 section. The remaining identification of the CI model with the complete physical kernel is not certified by a matching abstract group. Intrinsic higher-response sectors are outside these tables.\n\n"
                 "Every literature version has its own column. The 3+1D columns use full interacting source groups, without removing E8 factors. The 2+1D references are restricted to the stated n0/e0 sector. Wang–Qi–Fang–Cheng–Gu columns are charge and phase filtration layers, not stacking groups. Unavailable source values remain UNVERIFIED; an inapplicable source is N/A. No free-band classification or band-generated subgroup is used as a complete interacting benchmark.\n\n"
                 "The [source ledger](../../docs/reference_ledger_20261014.md), [foundation review](../../docs/foundations/README.md), and immutable [October 15 campaign](../four_data_campaign_20261015/README.md) retain detailed calibration and validation evidence. "
                 "Printed Debray D2/D6 values remain unchanged, with their specific proof-grading audit linked in the tables. "
                 "Published tables are comparisons, never solver inputs.\n\n"
                 "Rebuild with `python3 scripts/build_current_tables.py`; verify deterministic output with `python3 scripts/build_current_tables.py --check`. Historical artifacts are read-only.\n")
        self.inputs["scripts/build_current_tables.py"] = digest(Path(__file__).read_bytes())
        self.put("manifest.json", encoded({"input_sha256": self.inputs,
                 "output_sha256": {name: digest(text.encode()) for name, text in sorted(self.files.items())},
                 "background_count": 118, "sector_entry_count": 172, "table_count": 10,
                 "single_dimension_spin_family_and_response_sector_per_table": True}))

    def save(self, check=False):
        for name, text in self.files.items():
            path = self.output / name
            if check:
                if not path.exists() or path.read_text() != text:
                    raise ValueError(f"Generated output differs: {path}")
            else:
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(text)
        print(f"{'Verified' if check else 'Built'} 10 tables, 172 sector entries, 118 backgrounds.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "results/current")
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    builder = Catalogue(args.output.resolve())
    builder.build()
    builder.save(args.check)


if __name__ == "__main__":
    main()

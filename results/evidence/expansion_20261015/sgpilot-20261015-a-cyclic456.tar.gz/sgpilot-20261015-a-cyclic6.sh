#!/bin/bash
set -e
export LC_ALL=C LANG=C OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export PATH=/home/user/xyren/AllFSPT_insulator/runtime/bin:$PATH
cd /home/user/xyren/AllFSPT_insulator/snapshots/sgpilot-20261015-a
exec python3 scripts/pilot_cyclic_4p1.py --order 6 --timeout 3600 --memory 8g --gap /home/user/xyren/software/gap-4.13.1/gap --output /home/user/xyren/AllFSPT_insulator/runs/sgpilot-20261015-a-cyclic6

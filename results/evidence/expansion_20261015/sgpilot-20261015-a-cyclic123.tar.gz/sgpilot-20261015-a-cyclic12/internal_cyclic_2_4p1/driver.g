U1_ROOT:="/home/user/xyren/AllFSPT_insulator/snapshots/sgpilot-20261015-a";;
Read(Concatenation(U1_ROOT,"/gap/load.g"));;
Read(Concatenation(U1_ROOT,"/formulas/examples/cyclic_4p1.g"));;
result:=U1CyclicFourData(2);;
out:=OutputTextFile("/home/user/xyren/AllFSPT_insulator/runs/sgpilot-20261015-a-cyclic12/internal_cyclic_2_4p1/native.json",false);;
SetPrintFormattingStatus(out,false);;WriteLine(out,U1JSON(result));;CloseStream(out);;QUIT_GAP(0);

"""Patch only an explicitly supplied isolated review source snapshot."""
from pathlib import Path
import sys

root = Path(sys.argv[1]).resolve()
if '/runs/abelian_half_phase_review_20261016/candidate' not in str(root):
    raise RuntimeError('This prototype must never patch a live or repository source tree')

def replace(name, before, after):
    path = root / name
    text = path.read_text()
    if text.count(before) != 1:
        raise RuntimeError('Unexpected frozen source in ' + name)
    path.write_text(text.replace(before, after))

replace('gap/charge_source.g',
        'if not d in [2,3] or Length(v)<>Dimension(c.R)(d) or not ForAll(v,IsInt) then\n    Error("Closed charge state requires an integer native vector in degree 2 or 3");fi;',
        'if not d in [2,3,4] or Length(v)<>Dimension(c.R)(d) or not ForAll(v,IsInt) then\n    Error("Closed charge state requires an integer native vector in degree 2, 3, or 4");fi;\n  if d=4 and (c.s<>U1Zero or c.rho<>U1Zero or c.omega<>U1Zero or c.vcd<>0) then\n    Error("The degree-four prototype requires exact unsigned trivial-background finite-group input");fi;')
replace('gap/abelian4p1.g',
        'incomingRows,expectedOrder,relationCheck,original,shifted,delta,ix,rootPairs,chargeMode;',
        'incomingRows,expectedOrder,relationCheck,original,shifted,delta,ix,rootPairs,chargeMode,completionMode;')
replace('gap/abelian4p1.g',
        'chargeMode:="bar";if Length(options)>0 then chargeMode:=options[1];fi;',
        'chargeMode:="bar";if Length(options)>0 then chargeMode:=options[1];fi;\n  completionMode:="certified";if Length(options)>1 then completionMode:=options[2];fi;\n  if not completionMode in ["reference","certified","compare"] then Error("Invalid closed-charge completion mode");fi;\n  c.closedChargeSourceMode:=completionMode;')
replace('gap/abelian4p1.g',
        'a:=rec(charge:=U1CochainCombination(chargeBasis,v));\n    completed:=U1SolveData(c,6,"U1s",U1ChargeSource(c,4,a.charge));',
        'if completionMode="reference" then\n      a:=rec(charge:=U1CochainCombination(chargeBasis,v));\n      completed:=U1SolveData(c,6,"U1s",U1ChargeSource(c,4,a.charge));\n    else\n      a:=U1CertifiedClosedChargeState(c,4,v*HQ.generators);\n      completed:=U1SolveCertifiedChargeData(c,4,a);\n    fi;')
replace('gap/abelian4p1.g',
        'chargePrimaryMode:=chargeMode,chargePrimaryCompared:=chargeMode="compare",',
        'chargePrimaryMode:=chargeMode,chargePrimaryCompared:=chargeMode="compare",closedChargeCompletionMode:=completionMode,')
replace('scripts/classify_abelian_4p1.py',
        'def launch(factors, output, source, gap, python, timeout, memory, charge_primary="bar"):',
        'def launch(factors, output, source, gap, python, timeout, memory, charge_primary="bar", closed_charge_source="certified"):')
replace('scripts/classify_abelian_4p1.py',
        "'result:=U1AbelianFourData(' + gap_literal(list(factors)) + ',' + gap_literal(charge_primary) + ');;\\n'",
        "'result:=U1AbelianFourData(' + gap_literal(list(factors)) + ',' + gap_literal(charge_primary) + ',' + gap_literal(closed_charge_source) + ');;\\n'")
replace('scripts/classify_abelian_4p1.py',
        "'timeoutSeconds': timeout, 'formulaRuntime': formula_runtime_manifest(), 'chargePrimaryMode': charge_primary}",
        "'timeoutSeconds': timeout, 'formulaRuntime': formula_runtime_manifest(), 'chargePrimaryMode': charge_primary, 'closedChargeCompletionMode': closed_charge_source}")
replace('scripts/classify_abelian_4p1.py',
        "parser.add_argument('--charge-primary', choices=('bar', 'native', 'compare'), default='bar')",
        "parser.add_argument('--charge-primary', choices=('bar', 'native', 'compare'), default='bar')\n    parser.add_argument('--closed-charge-source', choices=('reference', 'certified', 'compare'), default='certified')")
replace('scripts/classify_abelian_4p1.py',
        'args.timeout, args.memory, args.charge_primary) for f in factors]',
        'args.timeout, args.memory, args.charge_primary, args.closed_charge_source) for f in factors]')

U1_ROOT:="/home/user/xyren/AllFSPT_insulator/runs/abelian_half_phase_review_20261016/candidate";;
Read(Concatenation(U1_ROOT,"/gap/load.g"));;
Read(Concatenation(U1_ROOT,"/gap/abelian4p1.g"));;
rows:=[];;
for factors in [[2,2],[2,2,2]] do
  c:=U1AbelianFourContext(factors);;
  c.closedChargeSourceMode:="compare";;
  HQ:=U1Cohomology(c,4,"Zr");;
  vectors:=Concatenation(HQ.generators,List(HQ.generators,v->-3*v),
    List(HQ.generators,v->2*v),[Sum(HQ.generators)]);;
  elements:=Filtered(Elements(c.G),g->g<>Identity(c.G));;
  tuples:=List([0..63],j->List([0..5],k->elements[1+((j*(2*k+1)+k*k+1) mod Length(elements))]));;
  checks:=0;;
  for vector in vectors do
    state:=U1CertifiedClosedChargeState(c,4,vector);;
    if U1Native(c,4,"Zr",state.charge)<>vector then Error("The full integral charge vector changed");fi;
    source:=U1Source(c,4,state);;
    for tuple in tuples do
      value:=CallFuncList(source,tuple);;
      if not IsInt(2*value) then Error("A certified closed source is not half-valued");fi;
      checks:=checks+1;;
    od;
  od;
  Add(rows,rec(factors:=factors,integerChargeVectors:=Length(vectors),
    pointwiseReferenceComparisons:=checks,fullIntegerChargePreserved:=true));;
od;
out:=OutputTextFile("/home/user/xyren/AllFSPT_insulator/runs/abelian_half_phase_review_20261016/source_control.json",false);;
SetPrintFormattingStatus(out,false);;
WriteLine(out,U1JSON(rec(status:="PASS",scope:="Closed degree-four sources only; exact unsigned trivial background; negative, even and mixed native charge vectors",cases:=rows)));;
CloseStream(out);;
QUIT_GAP(0);

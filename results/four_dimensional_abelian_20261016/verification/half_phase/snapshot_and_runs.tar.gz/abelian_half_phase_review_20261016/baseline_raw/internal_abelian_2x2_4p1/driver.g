U1_ROOT:="/home/user/xyren/AllFSPT_insulator/runs/abelian_half_phase_review_20261016/baseline";;
U1_FORMULA_PYTHON:="/home/user/xyren/AllFSPT_insulator/runtime4p1-v015/bin/python3";;
Read(Concatenation(U1_ROOT,"/gap/load.g"));;
Read(Concatenation(U1_ROOT,"/gap/abelian4p1.g"));;
result:=U1AbelianFourData([2,2],"bar");;
out:=OutputTextFile("/home/user/xyren/AllFSPT_insulator/runs/abelian_half_phase_review_20261016/baseline_raw/internal_abelian_2x2_4p1/native.json",false);;
SetPrintFormattingStatus(out,false);;WriteLine(out,U1JSON(result));;CloseStream(out);;QUIT_GAP(0);
